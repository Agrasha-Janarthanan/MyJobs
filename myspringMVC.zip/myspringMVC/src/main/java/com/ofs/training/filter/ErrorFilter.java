package com.ofs.training.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;

import com.ofs.training.util.AppException;
import com.ofs.training.util.JsonUtil;

public class ErrorFilter implements Filter{

    @Override
    public void init(FilterConfig config) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        PrintWriter writer = response.getWriter();
        try {
            chain.doFilter(request, response);
            ((HttpServletResponse) response).setStatus(HttpStatus.SC_ACCEPTED); 
        } catch (Exception e) {
            if (e instanceof AppException) {
                ((HttpServletResponse) response).setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
                writer.write(JsonUtil.toJson(((AppException) e).getErrorCodes()));
            } else {
                writer.write(JsonUtil.toJson(e.getMessage()));
            }
        }
    }

    @Override
    public void destroy() {
    }
}
