package com.ofs.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ofs.training.model.Person;
import com.ofs.training.service.PersonService;
import com.ofs.training.util.BeanUtil;

@Controller
@RequestMapping(value = "/person")
public class PersonController {

    private PersonService personService;

    @Autowired(required = true)
    @Qualifier(value = "personService")
    public void setPersonService(PersonService personService) {
        this.personService = personService;
    }

    @RequestMapping(
                     value = "/read",
                     method = RequestMethod.GET,
                     produces = "application/json"
                   )
    @ResponseBody ResponseEntity<Person> read(@RequestParam("id") long id) {
        personService = BeanUtil.getBean(PersonService.class);
        Person perzon = personService.read(id);
        return new ResponseEntity<> (perzon,  HttpStatus.OK);
    }

    @RequestMapping(
                     value = "/readall",
                     method = RequestMethod.GET,
                     produces = "application/json"
                   )
    @ResponseBody ResponseEntity<List<Person>> readAll() {
        personService = BeanUtil.getBean(PersonService.class);
        List<Person> perzonz = personService.readAll();
        return new ResponseEntity<> (perzonz, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody ResponseEntity<Person> doPost(@RequestParam("id") long id,
                                                @RequestBody Person person) {
        personService = BeanUtil.getBean(PersonService.class);
        Person perzon = personService.updatePerson(person);
        return new ResponseEntity<> (perzon, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.DELETE)
    @ResponseBody ResponseEntity<Object> doDelete(@RequestParam("id") long id,
                                                  @RequestBody Person person) {
        personService = BeanUtil.getBean(PersonService.class);
        personService.deletePerson(id);
        return new ResponseEntity<> (HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.PUT)
    @ResponseBody ResponseEntity<Person> doPut(@RequestBody Person person) {
        personService = BeanUtil.getBean(PersonService.class);
        Person perzon = personService.createPerson(person);
        return new ResponseEntity<> (perzon, HttpStatus.OK);
    }
}
