package com.ofs.training.service;

import java.util.List;

import com.ofs.training.model.Address;

public interface AddressService {

	public Address createAddress(Address address);
	public Address updateAddress(Address address);
	public List<Address> readAll();
	public Address read(long id);
	public void deleteAddress(long id);
}
