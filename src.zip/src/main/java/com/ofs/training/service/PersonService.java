package com.ofs.training.service;

import java.util.List;

import com.ofs.training.model.Person;

public interface PersonService {

    public Person createPerson(Person person);
    public Person updatePerson(Person person);
    public List<Person> readAll();
    public Person read(long id);
    public void deletePerson(long id);
}
