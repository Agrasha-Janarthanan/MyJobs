package com.ofs.training.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.ofs.training.dao.PersonDAO;
import com.ofs.training.model.Person;

@Service
public class PersonServiceImpl implements PersonService{

    private PersonDAO personDAO;

    public void setPersonDAO(PersonDAO perzonDAO) {
        this.personDAO = perzonDAO;
    }

    @Override
    @Transactional
    public Person createPerson(Person person) {
        return this.personDAO.createPerson(person);
    }

    @Override
    @Transactional
    public Person updatePerson(Person person) {
        return this.personDAO.updatePerson(person);
    }

    @Override
    @Transactional
    public List<Person> readAll() {
        return this.personDAO.readAll();
    }

    @Override
    @Transactional
    public Person read(long id) {
        return this.personDAO.read(id);
    }

    @Override
    @Transactional
    public void deletePerson(long id) {
        this.personDAO.deletePerson(id);
    }

}
