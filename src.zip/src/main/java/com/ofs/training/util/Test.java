package com.ofs.training.util;

public class Test {

    public static void main(String[] args) {

        
    }
}
