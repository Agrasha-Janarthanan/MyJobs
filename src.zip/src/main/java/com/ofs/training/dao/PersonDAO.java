package com.ofs.training.dao;

import java.util.List;

import com.ofs.training.model.Person;

public interface PersonDAO {

    public Person createPerson(Person person);
    public Person updatePerson(Person person);
    public List<Person> readAll();
    public Person read(long Id);
    public void deletePerson(long id);
}
