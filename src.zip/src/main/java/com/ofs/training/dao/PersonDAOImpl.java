package com.ofs.training.dao;

import java.util.List;
import java.util.Objects;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ofs.training.model.Person;

@Repository
public class PersonDAOImpl implements PersonDAO{

    private static final Logger logger = LoggerFactory.getLogger(PersonDAOImpl.class);
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sezzionFactory) {
        this.sessionFactory = sezzionFactory;
    }

    @Override
    public Person createPerson(Person person) {
        Session session = this.sessionFactory.getCurrentSession();
        session.persist(person);
        logger.info("Person Created.Person Details = " + person);
        return person;
    }

    @Override
    public Person updatePerson(Person person) {
        Session session = this.sessionFactory.getCurrentSession();
        session.update(person);
        logger.info("Person Details Updated.Person Details = " + person);
        return person;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Person> readAll() {
        Session session = this.sessionFactory.getCurrentSession();
        List<Person> perzon = session.createQuery("From Person").list();
        for(Person personList : perzon) {
            logger.info("Persons : " + personList);
        }
        return perzon;
    }

    @Override
    public Person read(long id) {
        Session session = this.sessionFactory.getCurrentSession();
        Person person = (Person) session.load(Person.class, new Long(id));
        logger.info("Person Details = " + person);
        return person;
    }

    @Override
    public void deletePerson(long id) {
        Session session = this.sessionFactory.getCurrentSession();
        Person person = (Person) session.load(Person.class, new Long(id));
        if(! Objects.isNull(person)) {
            session.delete(person);
        }
        logger.info("Person Created.Person Details = " + person);
    }
}
