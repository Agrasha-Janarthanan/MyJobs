package com.ofs.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ofs.training.model.Address;
import com.ofs.training.service.AddressService;

@Controller
@RequestMapping(value = "/address")
public class AddressController {

	private AddressService addressService;

	@Autowired(required = true)
	@Qualifier(value = "addressService")	
	public void setAddressService(AddressService addressService) {
		this.addressService = addressService;
	}
	
   @RequestMapping(
					value = "/read",
					method = RequestMethod.GET,
					produces = "application/json"
             	  )
	@ResponseBody ResponseEntity<Address> read(@RequestParam("id") long id) {
	  addressService = BeanUtil.getBean(AddressService.class);
	  Address addreszz = addressService.read(id);
	  return new ResponseEntity<> (addreszz,  HttpStatus.OK);
	}
	
	@RequestMapping(
	               value = "/readall",
	               method = RequestMethod.GET,
	               produces = "application/json"
	             )
	@ResponseBody ResponseEntity<List<Address>> readAll() {
	  addressService = BeanUtil.getBean(AddressService.class);
	  List<Address> perzonz = addressService.readAll();
	  return new ResponseEntity<> (perzonz, HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.POST)
	@ResponseBody ResponseEntity<Address> doPost(@RequestParam("id") long id,
	                                             @RequestBody Address address) {
	  addressService = BeanUtil.getBean(AddressService.class);
	  Address addrezz = addressService.updateAddress(address);
	  return new ResponseEntity<> (addrezz, HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.DELETE)
	@ResponseBody ResponseEntity<Object> doDelete(@RequestParam("id") long id,
	                                            @RequestBody Address address) {
	  addressService = BeanUtil.getBean(AddressService.class);
	  addressService.deleteAddress(id);
	  return new ResponseEntity<> (HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.PUT)
	@ResponseBody ResponseEntity<Address> doPut(@RequestBody Address address) {
	  addressService = BeanUtil.getBean(AddressService.class);
	  Address addrezz = addressService.createAddress(address);
	  return new ResponseEntity<> (addrezz, HttpStatus.OK);
	}
}
