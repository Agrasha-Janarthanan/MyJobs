package com.ofs.training.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.ofs.training.dao.AddressDAO;
import com.ofs.training.model.Address;

@Service
public class AddressServiceImpl implements AddressService{

	private AddressDAO addressDAO;
	
	public void setAddressDAO(AddressDAO addressDAO) {
		this.addressDAO = addressDAO;
	}

	@Transactional
	public Address createAddress(Address address) {
		return this.addressDAO.createAddress(address);
	}

	@Transactional
	public Address updateAddress(Address address) {
		return this.addressDAO.updateAddress(address);
	}

	@Transactional
	public List<Address> readAll() {
		return this.addressDAO.readAll();
	}

	@Transactional
	public Address read(long id) {
		return this.addressDAO.read(id);
	}

	@Transactional
	public void deleteAddress(long id) {
		this.addressDAO.deleteAddress(id);
	}
}
