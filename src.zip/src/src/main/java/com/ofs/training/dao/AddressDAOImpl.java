package com.ofs.training.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ofs.training.model.Address;

public class AddressDAOImpl implements AddressDAO {

	private static final Logger logger = LoggerFactory.getLogger(AddressDAOImpl.class);
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public Address createAddress(Address address) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(address);
		logger.info("Address Created.Address Details = " + address);
		return address;
	}

	public Address updateAddress(Address address) {
		Session session = this.sessionFactory.getCurrentSession();
		session.update(address);
		logger.info("Address Updated.Address Details = " + address);
		return address;
	}

	public List<Address> readAll() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Address> addrezz = session.createQuery("From Address").list();
		for (Address addressList : addrezz) {
			logger.info("Address Details : " + addressList);
			
		}
		return addrezz;
	}

	public Address read(long id) {
		Session session = this.sessionFactory.getCurrentSession();
		Address address = session.load(Address.class, new Long(id));
		logger.info("Address Details = " + address);
		return address;
	}

	public void deleteAddress(long id) {
		Session session = this.sessionFactory.getCurrentSession();
		Address address = session.load(Address.class, new Long(id));
		if(null != address) {
			session.delete(address);
		}
		logger.info("Address Deleted.Address Details = " + address);
	}

}
