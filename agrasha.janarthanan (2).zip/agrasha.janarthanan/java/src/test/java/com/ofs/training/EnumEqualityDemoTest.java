package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.EnumEqualityDemo.Continent;

@Test
public class EnumEqualityDemoTest {

    EnumEqualityDemo enumDemo;

    @BeforeClass
    private void initialize() {
        
        enumDemo = new EnumEqualityDemo();
    }
    
    @Test(dataProvider = "testCheckValueEquality_positiveDP")
    private void testCheckValueEquality_positive(Continent continent, Continent westContinent, boolean expectedResult) {
        
        boolean actualResult = enumDemo.checkValueEquality(continent, westContinent);
        
        try {
            
            Assert.assertEquals(actualResult, expectedResult, "Given Inputs" + continent + "," + westContinent);
        } catch(Exception e) {
            Assert.fail("Unexpected result for input"
                        + continent
                        + ","
                        + westContinent
                        + "."
                        + "Expected result"
                        + expectedResult
                        + e
                    );
        }
    }

    @Test(dataProvider = "testCheckObjectEquality_positiveDP")
    private void testCheckObjectEquality_positive(Continent continent, Continent westContinent, boolean expectedResult) {
        
        boolean actualResult = enumDemo.checkObjectEquality(continent, westContinent);
        
        try {

            Assert.assertEquals(actualResult, expectedResult, "Given Inputs" + continent + "," + westContinent);
        } catch(Exception e){
            Assert.fail("Unexpected result for input"
                        + continent
                        + ","
                        + westContinent
                        + "."
                        + "Expected result"
                        + expectedResult
                        + e
                    );
        }   
    }
    
    @Test
    private void testCheckValueEquality_negative() {
        
        try {
            
            enumDemo.checkValueEquality(null, null);
            Assert.fail("Expected an exception");
        } catch(Exception e) {
            
            Assert.assertEquals(e.getMessage() , "No values found");
        }
    }
    
    @Test
    private void testCheckObjectEquality_negative() {
        
        try {
            
            enumDemo.checkObjectEquality(null, null);
            Assert.fail("Expected an exception");
        } catch(Exception e) {
            
            Assert.assertEquals(e.getMessage() , "No similar values found");
        }
    }
    
    @DataProvider
    private Object[][] testCheckValueEquality_positiveDP() {
        return new Object[][] {
                                { Continent.ASIA, Continent.ASIA, true },
                                { Continent.ASIA, Continent.AFRICA, false}
                              };
    }
    
    @DataProvider
    private Object[][] testCheckObjectEquality_positiveDP() {
        return new Object[][] {
                                { Continent.ASIA, Continent.ASIA, true },
                                { Continent.ASIA, Continent.AFRICA, false}
                              };
    }
    
    @AfterClass
    private void afterClass() {
        
    }
}
