package com.ofs.training;

public class DisplayResult {

    public String getReturnType(Object object) {

        if(object instanceof Integer) {

            return "int";
        } else if (object instanceof Character) {

            return "char";
        } else if (object instanceof Float) {

            return "float";
        } else if (object instanceof Double) {

            return "double";
        }
        return null;
    }

    public static void main(String[] args) {

        DisplayResult displayResult1 = new DisplayResult();
        Object result1 = 100/24;
        System.out.println(displayResult1.getReturnType(result));

        DisplayResult displayResult2 = new DisplayResult();
        Object result2 = 100.01/2.01;
        System.out.println(displayResult2.getReturnType(result2));

        DisplayResult displayResult3 = new DisplayResult();
        Object result3 = 'Z' / 2;
        System.out.println(displayResult3.getReturnType(result3));

        DisplayResult displayResult4 = new DisplayResult();
        Object result4 = 10.5 / 0.5;
        System.out.println(displayResult4.getReturnType(result4));

        DisplayResult displayResult5 = new DisplayResult();
        Object result5 = 12.4 % 5.5;
        System.out.println(displayResult5.getReturnType(result5));

        DisplayResult displayResult6 = new DisplayResult();
        Object result6 = 100 % 56;
        0ystem.out.println(displayresult6.getReturnType(result6));
    }
}
