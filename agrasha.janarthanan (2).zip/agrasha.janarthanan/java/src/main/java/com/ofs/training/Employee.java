package com.ofs.training;

public class Employee {

    static int id;
    String name;

    Employee(String name) {

        this.name = name;
        id++;
    }

     public String display() {

         return ("ID : " + id + " Name : " + name);
     }

    public static void main(String[] args) {

        Employee employee1 = new Employee ("Jai");
        System.out.println(employee1.display());
        System.out.println(employee1.toString());

        Employee employee2 = new Employee ("Viya");
        System.out.println(employee2.display());
        System.out.println(employee1.toString());

        Employee employee3 = new Employee ("Tamil");
        System.out.println(employee3.display());
        System.out.println(employee1.toString());

        Employee employee4 = new Employee ("Kayal");
        System.out.println(employee4.display());
        System.out.println(employee1.toString());

        Employee employee5 = new Employee ("Venba");
        System.out.println(employee5.display());
        System.out.println(employee1.toString());

        Employee employee6 = new Employee ("Riya");
        System.out.println(employee6.display());
        System.out.println(employee1.toString());

        Employee employee7 = new Employee ("Yalini");
        System.out.println(employee7.display());
        System.out.println(employee1.toString());

        Employee employee8 = new Employee ("Mughil");
        System.out.println(employee8.display());
        System.out.println(employee1.toString());

        Employee employee9 = new Employee ("Ayshu");
        System.out.println(employee9.display());
        System.out.println(employee1.toString());

        Employee employee10 = new Employee ("Surya");
        System.out.println(employee10.display());
        System.out.println(employee1.toString());
    }
}
