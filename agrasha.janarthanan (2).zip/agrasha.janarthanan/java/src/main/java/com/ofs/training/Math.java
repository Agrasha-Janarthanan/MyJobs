package com.ofs.training;

public class Math {

	private static final String ERR_DIVIDE_BY_ZERO = "Can not divide by zero";
	public int division(int dividend, int divisor) {
		
		if(divisor == 0) {
			
			throw new RuntimeException(ERR_DIVIDE_BY_ZERO);
		}
		return (dividend/divisor);
	}
}
