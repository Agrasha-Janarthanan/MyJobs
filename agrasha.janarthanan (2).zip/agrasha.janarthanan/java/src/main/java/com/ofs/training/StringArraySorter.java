package com.ofs.training;

import java.util.Arrays;

//class StringArraySorter {
public class StringArraySorter {

    // static void execute() {
    public static void main(String[] args) {

        String[] Cities = { "Madurai",
                          "Thanjavur",
                          "TRICHY",
                          "Karur",
                          "Erode",
                          "trichy",
                          "Salem" };

        // ArraySorter sortedCities = sortIgnoreCase(Cities);
        Arrays.sort(Cities, String.CASE_INSENSITIVE_ORDER);

        // Console console = getConsole().....;
        // console.print(sortedCities);
        for (int index = 0; index < Cities.length ; index++) {
            System.out.println(Cities[index]);
        }

        // ArraySorter evenIndexedString = evenIndexedString(Cities);
        // ArraySorter upperCaseString = toUpperCase(evenIndexedString);
        // console.print(upperCaseString);
        for (int position = 0; position < Cities.length ; position++) {
            if (position % 2 == 0) {
                System.out.println(Cities[position].toUpperCase());
            }
        }
    }
}
