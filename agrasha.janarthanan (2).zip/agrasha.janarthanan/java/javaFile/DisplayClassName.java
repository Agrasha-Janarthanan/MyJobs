class DisplayClassName {

    public static void main(String[] args) {

        int number = 8;
        char alphabet = 'A';
        float decimal = 1.5F;

        System.out.println(int.class.getName());
        System.out.println(char.class.getName());
        System.out.println(float.class.getName());
    }
}
