class Fibinocci {

        static int num1 = 0;
        static int num2 = 1;
        static int num3;

        public static void fibinFor() {

            int number1 = 0;
            int number2 = 1;
            int limit = 10;
            int result;

            System.out.println(number1);
            System.out.println(number2);

            for (int i = 2; i < limit; i++) {
                result = number1 + number2;
                System.out.println(result);
                number1 = number2;
                number2 = result;
            }
        }

        public static void fibinWhile() {

            int firstNum = 0;
            int secondNum = 1;
            int count = 13;
            int j = 0;
            int nextNum;

            System.out.println(firstNum);
            System.out.println(secondNum);

            while (j < count) {
                nextNum = firstNum + secondNum;
                System.out.println(nextNum);
                firstNum = secondNum;
                secondNum = nextNum;
                j++;
            }
        }

        public static void fibinRecursion(int bound) {

            if (bound > 0) {
                num3 = num1 + num2;
                System.out.println(num3);
                num1 = num2;
                num2 = num3;
                fibinRecursion(bound - 1);
            }
        }

        public static void main(String[] args) {

            System.out.println("Fibinocci Series using 'for' loop");
            fibinFor();

            System.out.println("Fibinocci Series using 'While' loop");
            fibinWhile();

            System.out.println("Fibinocci Series using Recursion");
            System.out.println(num1);
            System.out.println(num2);
            fibinRecursion(18);
        }
}
