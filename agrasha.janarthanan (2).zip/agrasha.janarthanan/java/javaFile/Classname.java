import java.util.Arrays;

class Classname {

    public static void main(String[] args) {

        int[] intArray = {1, 2, 3};
        String[] strArray = {"apple", "ball", "cat"};
        char[] charArray = {'a', 'b', 'c'};

        Class intOb = intArray.getClass();
        Class charObj = charArray.getClass();
        Class strObj = strArray.getClass();

        String intName = intOb.getName();
        String charName = charObj.getName();
        String strName = strObj.getName();

        System.out.println(intName);
        System.out.println(charName);
        System.out.println(strName);

        System.out.println(int.class.getName());
        System.out.println(char.class.getName());
    }
}
