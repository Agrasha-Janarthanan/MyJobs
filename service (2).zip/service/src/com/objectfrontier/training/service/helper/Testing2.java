package com.objectfrontier.training.service.helper;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.PersonService;

public class Testing2 {

    public static void main(String[] args) {
        Testing2 obj = new Testing2();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {
        ConnectionManager connectionManager = new ConnectionManager("jdbc:mysql://pc1620:3306/lokesh_rajendran",
                "mysqlCredentials.txt");
        connectionManager.getConnection();
//        AddressMySQLManager manager = new AddressMySQLManager(connectionManager);
//        log("%s", manager.search("517001"));
        PersonService service = new PersonService(connectionManager, new AddressService(connectionManager));
        service.searchPersonByAddress("517001");
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
