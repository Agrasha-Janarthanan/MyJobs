package com.objectfrontier.training.service.helper;

import java.util.List;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.PersonService;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;

public class Testing {

    public static void main(String[] args) throws IOException, SQLException {
        ConnectionManager connectionManager = new ConnectionManager("jdbc:mysql://pc1620:3306/lokesh_rajendran",
                "mysqlCredentials.txt");
        connectionManager.getConnection();
        PersonMySQLDBManager personDBManager = new PersonMySQLDBManager(connectionManager);
          PersonService personManager = new PersonService(connectionManager, new AddressService(connectionManager));
//        System.out.println(personManager.isPresent("email", "lokeshbalaji68@gmail.com"));
//        PersonService personService = new PersonService(connectionManager);
//        Address address = new Address("Boovanaa street", "chennai" , 600113);
//        Person person = new Person("lokeshupdate", "balaji", "lokebalaji682@gmail.com", address, LocalDate.parse("09-08-1996",
//                                                                               DateTimeFormatter.ofPattern("dd-MM-yyyy")));
//        System.out.println(person.getBirthDate());
//        person.setId(1);
//        AddressService addressService = new AddressService(connectionManager);
//        System.out.println(personManager.readAll(2, 1));
          Address address = new Address(null, null, 517001);
          address.setId(2000);
          Person person = new Person("Lokesh2",
                                     "Balaji",
                                     "lokeshbalaji268@gmail.com",
                                     address,
                                     null);
          person.setId(2000);
        try {
////            List<Address> addresses = addressService.readAll();
//            address.setId(1);
////            Address addrezz = addressService.delete(address);
            Person persan = personManager.update(person);
////            boolean check = personDBManager.isPresent("id", "email", "lokeshbalaji682@gmail.com", "id", Long.toString(2));
////            System.out.println(check);
        } catch (AppException e) {
            System.out.println(e.getMessage());
            Error[] errors = e.getAssociatedErrors();
            for (Error error : errors) {
                System.out.println(error);
            }
        }
//        try {
//            Person personDTO = personManager.update(person);
//            System.out.println(personDTO.getFirstName() + " " + personDTO.getLastName() + " " + personDTO.getId());
//        } catch (AppException e) {
//            Error[] errors = e.getAssociatedErrors();
//            for (Error error : errors) {
//                System.out.println(error.getErrorCode() + " : " + error.getMessage());
//            }
//        }
    }

}
