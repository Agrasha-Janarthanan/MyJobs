package com.objectfrontier.training.service.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.xml.crypto.Data;

import com.objectfrontier.training.service.DAO.AddressDAO;
import com.objectfrontier.training.service.entity.POJO.Address;

/**
 * @author Lokesh.
 * @since Oct 12, 2018
 */
public class AddressMySQLManager implements AddressDAO {

    ConnectionManager connectionManager;

    public AddressMySQLManager(ConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public List<Address> readAll() {
        String query = new StringBuilder().append("SELECT scv_address.id            ")
                                          .append("      ,scv_address.street        ")
                                          .append("      ,scv_address.city          ")
                                          .append("      ,scv_address.postal_code   ")
                                          .append("FROM scv_address                 ")
                                          .toString();

        ResultSetProcessor<List<Address>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Address> addresses = new ArrayList<>(resultSet.getFetchSize());

            while (resultSet.next()) {
                Address address = new Address(resultSet.getString("street"),
                                              resultSet.getString("city"),
                                              resultSet.getLong("postal_code"));
                address.setId(resultSet.getLong("id"));
                addresses.add(address);
            }
            return addresses;
        };

        try {
            return readAll.applyOn(query, null, connectionManager, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public List<Address> readAll(int limit, int offset) {
        String query = new StringBuilder().append("SELECT scv_address.id            ")
                                          .append("      ,scv_address.street        ")
                                          .append("      ,scv_address.city          ")
                                          .append("      ,scv_address.postal_code   ")
                                          .append("FROM scv_address LIMIT ? OFFSET ?")
                                          .toString();

        ResultSetProcessor<List<Address>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Address> addresses = new ArrayList<>(resultSet.getFetchSize());

            while (resultSet.next()) {
                Address address = new Address(resultSet.getString("street"),
                                              resultSet.getString("city"),
                                              resultSet.getLong("postal_code"));
                address.setId(resultSet.getLong("id"));
                addresses.add(address);
            }
            return addresses;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, limit);
            parameters.add(1, offset);
            return readAll.applyOn(query, parameters, connectionManager, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public Address read(long id) {
        String query = new StringBuilder().append("SELECT scv_address.id            ")
                                          .append("      ,scv_address.street        ")
                                          .append("      ,scv_address.city          ")
                                          .append("      ,scv_address.postal_code   ")
                                          .append("FROM scv_address WHERE id = ?    ")
                                          .toString();

        ResultSetProcessor<Address, ResultSet> read = (resultSet) -> {
            if (resultSet.next()) {
                Address address = new Address(resultSet.getString("street"),
                                              resultSet.getString("city"),
                                              resultSet.getLong("postal_code"));
                address.setId(resultSet.getLong("id"));
                return address;
            }
            return null;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, id);
            return read.applyOn(query, parameters, connectionManager, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public Address update(Address address) {
        String query = new StringBuilder().append("UPDATE scv_address                ")
                                          .append("SET scv_address.street = ?        ")
                                          .append("   ,scv_address.city = ?          ")
                                          .append("   ,scv_address.postal_code = ?   ")
                                          .append("WHERE scv_address.id = ?;         ")
                                          .toString();

        ResultSetProcessor<Integer, Integer> update = (updatedCount) -> {
            return updatedCount;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, address.getStreet());
            parameters.add(1, address.getCity());
            parameters.add(2, address.getPostalCode());
            parameters.add(3, address.getId());
            update.applyOn(query, parameters, connectionManager, true, 0);
            return address;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_UPDATE_ERROR, e);
        }
    }

    @Override
    public Address delete(Address address) {
        String query = new StringBuilder().append("DELETE FROM scv_address ")
                                          .append("WHERE scv_address.id = ?")
                                          .toString();

        ResultSetProcessor<Integer, Integer> delete = (deletedCount) -> {
            return deletedCount;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, address.getId());
            int deletedCount = delete.applyOn(query, parameters, connectionManager, true, 0);
            if (deletedCount == 1) {
                return address;
            }
            return null;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_DELETE_ERROR, e);
        }
    }

    @Override
    public Address create(Address address) {
        String insertAddressQuery = new StringBuilder().append("INSERT INTO scv_address (scv_address.street      ")
                                                       .append("                        ,scv_address.city        ")
                                                       .append("                        ,scv_address.postal_code)")
                                                       .append("VALUES (?, ?, ?)                                 ")
                                                       .toString();

        ResultSetProcessor<Long, ResultSet> insertAddress = (resultSet) -> {
            resultSet.next();
            return resultSet.getLong(1);
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, address.getStreet());
            parameters.add(1, address.getCity());
            parameters.add(2, address.getPostalCode());
            long addressId = insertAddress.applyOn(insertAddressQuery, parameters, connectionManager, true,
                    Statement.RETURN_GENERATED_KEYS);
            address.setId(addressId);
            return address;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_INSERT_ERROR, e);
        }
    }

    @Override
    public <V> boolean isPresent(String checkField, String conditionField, V value) {

        String getFieldQuery = MessageFormat.format("SELECT count({0}) FROM scv_address WHERE {1} = {2}",
                                                    checkField,
                                                    conditionField,
                                                    value);
        boolean result = true;

        ResultSetProcessor<Boolean, ResultSet> isPresent = (resultSet) -> {
            while (resultSet.next()) {
                if (resultSet.getInt(1) > 0) {
                    return Boolean.TRUE;
                }
            }
            return Boolean.FALSE;
        };

        try {
            result = isPresent.applyOn(getFieldQuery, null, connectionManager, false, 0).booleanValue();
        } catch (SQLException e) {
            new AppException(Error.SQL_READ_ERROR, e);
        }
        return result;
    }

//    @Override
//    public <V> boolean isPresent(String checkField, String conditionalField, V value, String neglectRowWithField,
//            String neglectRowWithValue) {
//
//        String getFieldQuery = MessageFormat.format("SELECT count({0}) FROM scv_address WHERE {1} = {2} AND {3} != {4}",
//                                                    checkField,
//                                                    conditionalField,
//                                                    value,
//                                                    neglectRowWithField,
//                                                    neglectRowWithValue);
//        boolean result = true;
//        ResultSetProcessor<Boolean, ResultSet> isPresent = (resultSet) -> {
//            while (resultSet.next()) {
//                if (resultSet.getInt(1) > 0) {
//                    return Boolean.TRUE;
//                }
//            }
//            return Boolean.FALSE;
//        };
//        try {
//            result = isPresent.applyOn(getFieldQuery, null, connectionManager, false, 0).booleanValue();
//        } catch (SQLException e) {
//            new AppException(Error.SQL_READ_ERROR, e);
//        }
//        return result;
//    }
    @Override
    public List<Address> search(String searchText) {

        String query = "SELECT id, street, city, postal_code FROM scv_address WHERE " +
                        constructSearchCondition(searchText);
        System.out.println(query);
        ResultSetProcessor<List<Address>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Address> addresses = new ArrayList<>(resultSet.getFetchSize());

            while (resultSet.next()) {
                Address address = new Address(resultSet.getString("street"),
                                              resultSet.getString("city"),
                                              resultSet.getLong("postal_code"));
                address.setId(resultSet.getLong("id"));
                addresses.add(address);
            }
            return addresses;
        };

        try {
            return readAll.applyOn(query, null, connectionManager, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    private String constructSearchCondition(String searchText) {

        String[] addressFields = searchText.split(",");
        StringBuilder sBuilder = new StringBuilder();
        String[] stringFields = new String[2];
        int stringFieldsIndex = 0;
        int limit = (addressFields.length > 2 ? 2 : addressFields.length);
        for (int index = 0; index < limit; index++) {
            addressFields[index] = addressFields[index].trim();
            try {
                Long.parseLong(addressFields[index]);
                sBuilder.append(MessageFormat.format(" postal_code Like {0} ",addressFields[index]));
                sBuilder.append(" AND ");
            } catch (NumberFormatException e) {
                stringFields[stringFieldsIndex++] = addressFields[index];
            }
        }
        if (stringFieldsIndex == 2) {
            sBuilder.append(MessageFormat.format(" street Like \"%{0}%\" AND city LIKE \"%{1}%\" ",
                            stringFields[0],
                            stringFields[1]));
            sBuilder.append(" OR ");
            sBuilder.append(MessageFormat.format(" street Like \"%{0}%\" AND city LIKE \"%{1}%\" ",
                            stringFields[1],
                            stringFields[0]));
            sBuilder.append(" AND ");
        } else if (stringFieldsIndex == 1) {
            sBuilder.append(MessageFormat.format(" street Like \"%{0}%\" OR city LIKE \"%{1}%\" ",
                    stringFields[0],
                    stringFields[0]));
            sBuilder.append(" AND ");
        }
        return sBuilder.substring(0, sBuilder.length() - 4).toString();
    }
}
