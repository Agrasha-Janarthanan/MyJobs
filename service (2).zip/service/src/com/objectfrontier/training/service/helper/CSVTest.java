package com.objectfrontier.training.service.helper;

/**
 * @author Lokesh.
 * @since Oct 15, 2018
 */
public class CSVTest {

    public static void main(String[] args) {
        CSVTest obj = new CSVTest();

        try {
        //    obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

//    private void run(String[] args) {

//        CSVParser csvParser = new CSVParser("persons.csv", "addresses.csv");
//        while (csvParser.hasMoreElements()) {
//            log("%s%n", csvParser.nextElement().getLastName());
//        } 
//    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
