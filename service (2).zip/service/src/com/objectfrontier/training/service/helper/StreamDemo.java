package com.objectfrontier.training.service.helper;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.objectfrontier.training.service.entity.POJO.Person;


public class StreamDemo {

    public static void main(String[] args) throws SQLException, IOException {


        ConnectionManager connectionManager = new ConnectionManager("jdbc:mysql://pc1620:3306/lokesh_rajendran",
                "mysqlCredentials.txt");
        connectionManager.getConnection();

        String query = "SELECT scv_person.id, scv_person.first_name, scv_person.last_name FROM scv_person";
        ResultSetProcessor<Person, ResultSet> streamDemo = (resultSet) -> {
            ResultSetStreamer.stream(resultSet)
                             .forEach(rs -> {
                                             try {
                                                 System.out.println(rs.getLong(1) + ":" + rs.getString(2));
                                             } catch (SQLException e) {
                                                 e.printStackTrace();
                                             }
                              });
            return null;
        };
        streamDemo.applyOn(query, null, connectionManager, false, 0);
    }
}
