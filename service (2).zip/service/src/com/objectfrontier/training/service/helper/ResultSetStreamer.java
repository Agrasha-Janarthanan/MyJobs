package com.objectfrontier.training.service.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Spliterators;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class ResultSetStreamer implements Iterator<ResultSet>{

    ResultSet resultSet;
    public ResultSetStreamer(ResultSet resultSet) {
        super();
        this.resultSet = resultSet;
    }

    @Override
    public boolean hasNext() {
        boolean hasNext = false;
        try {
            hasNext = resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hasNext;
    }

    @Override
    public ResultSet next() {
        return resultSet;
    }

    public static Stream<ResultSet> stream(ResultSet resultSet) {
        return StreamSupport.stream(Spliterators.spliteratorUnknownSize(new ResultSetStreamer(resultSet), 0), false);
    }
}
