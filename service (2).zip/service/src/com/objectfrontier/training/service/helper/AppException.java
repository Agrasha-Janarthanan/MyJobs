package com.objectfrontier.training.service.helper;

import java.util.ArrayList;
import java.util.Arrays;

public class AppException extends RuntimeException {

    protected Error error;
    protected int errorCode;
    protected ArrayList<Error> associatedErrors = new ArrayList<>();

    public AppException(Error[] errors, Error error) {
        this(error); 
        associatedErrors.addAll(Arrays.asList(errors));
    }

    public AppException() {
        super();
    }

    public AppException(Error error) {
        super(error.getMessage());
        this.error = error;
        this.errorCode = error.getErrorCode();
    }

    public AppException(Error error, Exception cause) {
        super(error.getMessage(), cause);
        this.error = error;
        this.errorCode = error.getErrorCode();
    }
    
    public Error[] getAssociatedErrors() {
        return associatedErrors.toArray(new Error[associatedErrors.size()]);
    }

    public void setErrorCodes(Error[] errors) {
        this.associatedErrors.addAll(Arrays.asList(errors));
    }

    public int getErrorCode() {
        return errorCode;
    }

    public Error getError() {
        return error;
    }

}
