package com.objectfrontier.training.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.beust.jcommander.Strings;
import com.objectfrontier.training.service.DAO.PersonDAO;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.PersonMySQLDBManager;



public class PersonService {

    private PersonDAO personDBManager;
    private AddressService addressService;

    public PersonService(ConnectionManager connectionManager, AddressService addressService) {
        this.personDBManager = new PersonMySQLDBManager(connectionManager);
        this.addressService = addressService;
    }

    public Person create(Person person) {

        Address address = person.getAddress();
        AppException exceptions = new AppException(Error.DATA_VALIDATION_ERROR);

        try {
            person.setAddress(addressService.create(address));
        } catch (AppException e) {
            if (e.getErrorCode() == Error.ADDRESS_VALIDATION_ERROR.getErrorCode()) {
                exceptions.setErrorCodes(e.getAssociatedErrors());
            }
//            else {
//                exceptions.setErrorCodes(new Error[] { e.getError() });
//            }
        }

        try {
            validatePerson(person);
        } catch (AppException e) {
            if (e.getErrorCode() == Error.PERSON_VALIDATION_ERROR.getErrorCode()) {
                exceptions.setErrorCodes(e.getAssociatedErrors());
            }
//            else {
//                exceptions.setErrorCodes(new Error[] { e.getError() });
//            }
        }
        if (exceptions.getAssociatedErrors().length > 0) {
            throw exceptions;
        }
        return personDBManager.create(person);
    }

    public Person read(long id, boolean includeAddress) {
        validatePersonId(id);
        Person person = personDBManager.read(id, includeAddress);
        if (includeAddress) {
            Address address = addressService.read(person.getAddress().getId());
            person.setAddress(address);
        }
        return person;
    }

    public Person update(Person person) {
        Address address = person.getAddress();
        AppException exceptions = new AppException(Error.DATA_VALIDATION_ERROR);
        try {
            person.setAddress(addressService.update(address));
        }
        catch (AppException e) {
            if (e.getErrorCode() == Error.ADDRESS_VALIDATION_ERROR.getErrorCode()) {
                exceptions.setErrorCodes(e.getAssociatedErrors());
            }
//            else {
//                exceptions.setErrorCodes(new Error[] { e.getError() });
//            }
        }
        try {
            validateUpdatedPerson(person);
        }
        catch (AppException e) {
            if (e.getErrorCode() == Error.PERSON_VALIDATION_ERROR.getErrorCode()) {
                exceptions.setErrorCodes(e.getAssociatedErrors());
            }
//            else {
//                exceptions.setErrorCodes(new Error[] { e.getError() });
//            }
        }
        if (exceptions.getAssociatedErrors().length > 0) {
            throw exceptions;
        }
        return personDBManager.update(person);
    }

    public Person delete(Person person) {
        validatePersonId(person.getId());
        addressService.delete(person.getAddress());
        return personDBManager.delete(person);
    }

    public List<Person> readAll() {
        List<Person> persons = personDBManager.readAll();
        Map<Long, Address> addresses = new HashMap<>(); 
        for (Address address : addressService.readAll()) {
            addresses.put(address.getId(), address);
        }
        persons.stream().forEach((perzon) -> {
            perzon.setAddress(addresses.get(perzon.getAddress().getId()));
        });
        return persons;
    }

    public List<Person> readAll(int limit, int offset) {
        List<Person> persons = personDBManager.readAll(limit, offset);
        Map<Long, Address> addresses = new HashMap<>(); 
        for (Address address : addressService.readAll(limit, offset)) {
            addresses.put(address.getId(), address);
        }
        persons.stream().forEach((perzon) -> {
            perzon.setAddress(addresses.get(perzon.getAddress().getId()));
        });
        return persons;
    }

    private void validatePerson(Person person) {
        int exceptionCount = 0;
        ArrayList<Error> errors = new ArrayList<>();

        String firstName = person.getFirstName();
        String lastName = person.getLastName();

        if (firstName == null || firstName.isEmpty()) {
            errors.add(Error.FIRST_NAME_NULL_VALUE_ERROR);
            exceptionCount++;
        }
        if (lastName == null || lastName.isEmpty()) {
            errors.add(Error.LAST_NAME_NULL_VALUE_ERROR);
            exceptionCount++;
        }
        if (firstName != null && lastName != null && !firstName.isEmpty() && !lastName.isEmpty() && 
            personDBManager.isPresent("id",
                                     "concat(first_name,last_name)",
                                     person.getFirstName() + person.getLastName(),
                                     "id",
                                     Long.toString(person.getId())
                                     )) {

            errors.add(Error.DATA_FIRST_LAST_NAME_DUPLICATION_ERROR);
            exceptionCount++;
        }
        if (person.getBirthDate() == null) {
            errors.add(Error.DOB_NULL_VALUE_ERROR);
            exceptionCount++;
        }
        if (person.getEmail() == null) {
            errors.add(Error.EMAIL_NULL_VALUE_ERROR);
            exceptionCount++;
        }
        if (personDBManager.isPresent("id", "email", person.getEmail(), "id", Long.toString(person.getId()))) {
            errors.add(Error.EMAIL_DUPLICATION_ERROR);
            exceptionCount++;
        }
        if (exceptionCount > 0) {
            throw new AppException(errors.toArray(new Error[errors.size()]), Error.PERSON_VALIDATION_ERROR);
        }
    }

    public void validatePersonId(long id) {
        if (id <= 0) {
            throw new AppException(Error.INVALID_PERSON_ID);
        }
        if (! personDBManager.isPresent("id", "id", Long.toString(id))) {
            throw new AppException(Error.INVALID_PERSON_REQUEST);
        }
    }

    private void validateUpdatedPerson(Person person) {
        try {
            validatePerson(person);
            validatePersonId(person.getId());
        } catch (AppException e) {
            if (e.getErrorCode() == 209) {
                throw new AppException(new Error[] { Error.INVALID_PERSON_REQUEST }, Error.PERSON_VALIDATION_ERROR);
            }
            try {
                validatePersonId(person.getId());
            } catch (AppException e2) {
                Error[] errors = e.getAssociatedErrors();
                Error[] newErrors = new Error[errors.length + 1];
                System.arraycopy(errors, 0, newErrors, 0, errors.length);
                newErrors[errors.length] = Error.INVALID_PERSON_REQUEST;
                throw new AppException(newErrors, Error.PERSON_VALIDATION_ERROR);
            }
        }
    }

    public List<Person> searchPersonByAddress(String searchText) {

        Map<Long, Address> addresses = new HashMap<>(); 
        for (Address address : addressService.search(searchText)) {
            addresses.put(address.getId(), address);
        }
        Set<Long> addressIds = addresses.keySet();
        List<Person> persons = personDBManager.searchByAddressId(addressIds.toArray(new Long[addressIds.size()]));
        persons.stream()
               .forEach((perzon) -> {
                                  perzon.setAddress(addresses.get(perzon.getAddress().getId()));
                              });
        return persons;
    }
}
