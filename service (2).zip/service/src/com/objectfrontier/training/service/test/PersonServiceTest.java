package com.objectfrontier.training.service.test;

import java.util.List;
import java.io.IOException;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.PersonService;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.CSVParser;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.Error;

public class PersonServiceTest {


    @BeforeClass
    private void setup() throws IOException, SQLException {

    }

    ConnectionManager initiliseConnection() {
        ConnectionManager connectionManager = new ConnectionManager("jdbc:mysql://pc1620:3306/lokesh_rajendran",
                "mysqlCredentials.txt");
        connectionManager.getConnection();
        connectionManager.autoCommit(false);
        return connectionManager;
    }

    @Test (dataProvider = "insertTest_positiveDP")
    private void insertTest_positive(Person person) {

        ConnectionManager connectionManager = initiliseConnection();
        PersonService personService = new PersonService(connectionManager, new AddressService(connectionManager));
        Person actualResult = null;
        Person expectedResult = person;
        try {
            actualResult = personService.create(person);
            connectionManager.commit();
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            connectionManager.rollBack();
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e, person));
        } finally {
            connectionManager.close();
            personService = null;
        }
    }

    @DataProvider
    private Iterator<Person> insertTest_positiveDP() {
        CSVParser csvParser = new CSVParser("persons.csv", "addresses.csv");
        return csvParser.getPersons().iterator();
    }

    @Test (dataProvider = "insertTest_negativeDP")
    private void insertTest_negative(Person person, AppException expectedResult) {
        
        ConnectionManager connectionManager = initiliseConnection();
        PersonService personService = new PersonService(connectionManager, new AddressService(connectionManager));
        try {
            personService.create(person);
            connectionManager.commit();
            Assert.fail(MessageFormat.format("Expected an Exception for {0}", person));
        } catch (AppException e) {
            connectionManager.rollBack();
            Error[] caught = e.getAssociatedErrors();
            Error[] expected = expectedResult.getAssociatedErrors();
            for (int i = 0; i < caught.length; i++) {
                Assert.assertEquals(caught[i].getErrorCode(),
                       expected[i].getErrorCode());
            }
        } finally {
            connectionManager.close();
            personService = null;
        }
    }

    @DataProvider
    private Object[][] insertTest_negativeDP() {
        Address address = new Address(null, null, 517001);
        Person person = new Person("Lokesh2",
                                   "Balaji",
                                   "lokeshbalaji268@gmail.com",
                                   address,
                                   null);
        Address addressTwo = new Address(null, null, 0);
        Person personTwo = new Person(null,
                                      null,
                                      null,
                                      addressTwo,
                                   null);
        Error[] errorsOne = { Error.STREET_NULL_VALUE_ERROR,
                              Error.CITY_NULL_VALUE_ERROR,
                              Error.DATA_FIRST_LAST_NAME_DUPLICATION_ERROR,
                              Error.DOB_NULL_VALUE_ERROR,
                              Error.EMAIL_DUPLICATION_ERROR};

        Error[] errorsTwo = { Error.STREET_NULL_VALUE_ERROR,
                              Error.CITY_NULL_VALUE_ERROR,
                              Error.POSTAL_CODE_NULL_VALUE_ERROR,
                              Error.FIRST_NAME_NULL_VALUE_ERROR,
                              Error.LAST_NAME_NULL_VALUE_ERROR,
                              Error.DOB_NULL_VALUE_ERROR,
                              Error.EMAIL_NULL_VALUE_ERROR};

        return new Object[][] {
            { person, new AppException(errorsOne, Error.DATA_VALIDATION_ERROR) },
            { personTwo, new AppException(errorsTwo, Error.DATA_VALIDATION_ERROR) }
        };
    }

    @Test (dataProvider = "readAllTest_positiveDP")
    private void readAllTest_positive(List<Person> expectedResult) {
        ConnectionManager connectionManager = initiliseConnection();
        PersonService personService = new PersonService(connectionManager, new AddressService(connectionManager));
        List<Person> actualResult;
        try {
            actualResult = personService.readAll();
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e));
        } finally {
            connectionManager.close();
            personService = null;
        }
    }

    @DataProvider
    private Object[][] readAllTest_positiveDP() {
        CSVParser csvParser = new CSVParser("personsReadAll.csv", "addresses.csv");
        return new Object[][] {
            { csvParser.getPersons() }
        };
    }

    @Test (dataProvider = "readAllOffsetTest_positiveDP")
    private void readAllOffsetTest_positive(List<Person> expectedResult, int limit, int offset) {
        ConnectionManager connectionManager = initiliseConnection();
        PersonService personService = new PersonService(connectionManager, new AddressService(connectionManager));
        List<Person> actualResult;
        try {
            actualResult = personService.readAll(limit, offset);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e));
        } finally {
            connectionManager.close();
            personService = null;
        }
    }

    @DataProvider
    private Object[][] readAllOffsetTest_positiveDP() {
        CSVParser csvParser = new CSVParser("personsReadAll.csv", "addresses.csv");
        return new Object[][] {
            { csvParser.getPersons(5, 0), 5 , 0},
            { csvParser.getPersons(5, 5), 5 , 5}
        };
    }

    @Test (dataProvider = "readTest_positiveDP")
    private void readTest_positive(Person expectedResult, boolean includeAddress, int id) {
        Person actualResult;
        ConnectionManager connectionManager = initiliseConnection();
        PersonService personService = new PersonService(connectionManager, new AddressService(connectionManager));
        try {
            actualResult = personService.read(id, includeAddress);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e, id));
        } finally {
            connectionManager.close();
            personService = null;
        }
    }


    @DataProvider
    private Object[][] readTest_positiveDP() {
        Address address = new Address("Hassan khan2 Street", "Mittoor", 517001);
        address.setId(2);
        Person person = new Person("Lokesh2",
                                   "Balaji",
                                   "lokeshbalaji268@gmail.com",
                                   address,
                                   LocalDate.parse("06-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        person.setId(2);
        Person personTwo = new Person("Lokesh2",
                "Balaji",
                "lokeshbalaji268@gmail.com",
                null,
                LocalDate.parse("06-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        personTwo.setId(2);
        return new Object[][] {
            {person, true, 2},
            {personTwo, false, 2}
        };
    }

    @Test (dataProvider = "readTest_negativeDP")
    private void readTest_negative(int id, boolean includeAddress, AppException expectedResult) {
        ConnectionManager connectionManager = initiliseConnection();
        PersonService personService = new PersonService(connectionManager, new AddressService(connectionManager));
        try {
            personService.read(id, includeAddress);
            Assert.fail(MessageFormat.format("Expected an Exception for {0}", id));
        } catch (AppException e) {
            Assert.assertEquals(e.getMessage(),
                                expectedResult.getMessage());
        } finally {
            connectionManager.close();
            personService = null;
        }
    }

    @DataProvider
    private Object[][] readTest_negativeDP() {
        return new Object[][] {
            {1000, true, new AppException(Error.INVALID_PERSON_REQUEST)}
        };
    }

    @Test (dataProvider = "updateTest_positiveDP")
    private void updateTest_positive(Person person) throws SQLException {
        ConnectionManager connectionManager = initiliseConnection();
        PersonService personService = new PersonService(connectionManager, new AddressService(connectionManager));
        Person expectedResult = person;
        try {
            Person actualResult = personService.update(person);
            connectionManager.commit();
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (AppException e) {
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}",
                        e.getAssociatedErrors(), person));
        } finally {
            connectionManager.close();
            personService = null;
        }
    }

    @DataProvider
    private Iterator<Person> updateTest_positiveDP() {
        CSVParser csvParser = new CSVParser("personsUpdate.csv", "addressesUpdate.csv");
        return csvParser.getPersons().iterator();
    }

    @Test (dataProvider = "updateTest_negativeDP")
    private void updateTest_negative(Person person, AppException expectedException) throws SQLException {
        ConnectionManager connectionManager = initiliseConnection();
        PersonService personService = new PersonService(connectionManager, new AddressService(connectionManager));
        try {
            personService.update(person);
            connectionManager.commit();
            Assert.fail("Expected an AppException " + expectedException);
        } catch (AppException e) {
            if (e.getAssociatedErrors() != null) {
                Error[] caught = e.getAssociatedErrors();
                Error[] expected = expectedException.getAssociatedErrors();
                for (int i = 0; i < caught.length; i++) {
                    Assert.assertEquals(caught[i].getErrorCode(),
                            expected[i].getErrorCode());
                }
            }
        } finally {
            connectionManager.close();
            personService = null;
        }
    }

    @DataProvider
    private Object[][] updateTest_negativeDP() {
        Address address = new Address(null, null, 517001);
        address.setId(2000);
        Person person = new Person("Lokesh2",
                                   "Balajiupdate",
                                   "lokeshbalaji268@gmail.com",
                                   address,
                                   null);
        person.setId(2000);
        Address addressTwo = new Address(null, null, 0);
        address.setId(1000);
        Person personTwo = new Person(null,
                                      null,
                                      null,
                                      addressTwo,
                                   null);
        person.setId(1000);
        Address addressThree = new Address("hai", "hello", 517001);
        address.setId(1000);
        Person personThree = new Person("Vijaya",
                                      "Rajendran",
                                      "vijaya.rajendran@gmail.com",
                                      addressThree,
                                      LocalDate.parse("06-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy"))
                                   );
        person.setId(1000);
        Error[] errorsOne = { Error.STREET_NULL_VALUE_ERROR,
                              Error.CITY_NULL_VALUE_ERROR,
                              Error.INVALID_ADDRESS_REQUEST,
                              Error.DATA_FIRST_LAST_NAME_DUPLICATION_ERROR,
                              Error.DOB_NULL_VALUE_ERROR,
                              Error.EMAIL_DUPLICATION_ERROR,
                              Error.INVALID_PERSON_REQUEST};

        Error[] errorsTwo = { Error.STREET_NULL_VALUE_ERROR,
                              Error.CITY_NULL_VALUE_ERROR,
                              Error.POSTAL_CODE_NULL_VALUE_ERROR,
                              Error.INVALID_ADDRESS_REQUEST,
                              Error.FIRST_NAME_NULL_VALUE_ERROR,
                              Error.LAST_NAME_NULL_VALUE_ERROR,
                              Error.DOB_NULL_VALUE_ERROR,
                              Error.EMAIL_NULL_VALUE_ERROR,
                              Error.INVALID_PERSON_REQUEST};
        Error[] errorThree = {
                Error.INVALID_ADDRESS_REQUEST,
                Error.INVALID_PERSON_REQUEST
        };

        return new Object[][] {
            { person, new AppException(errorsOne, Error.DATA_VALIDATION_ERROR) },
            { personTwo, new AppException(errorsTwo, Error.DATA_VALIDATION_ERROR)},
            { personThree, new AppException(errorThree, Error.DATA_VALIDATION_ERROR)}
        };
    }

    @Test (dataProvider = "deleteTest_positiveDP")
    private void deleteTest_positive(Person person) throws SQLException {
        ConnectionManager connectionManager = initiliseConnection();
        PersonService personService = new PersonService(connectionManager, new AddressService(connectionManager));
        Person expectedResult = person;
        try {
            Person actualResult = personService.delete(person);
            connectionManager.commit();
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (AppException e) {
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e, person));
        } finally {
            connectionManager.close();
            personService = null;
        }
    }

    @DataProvider
    private Iterator<Person> deleteTest_positiveDP() {
        CSVParser csvParser = new CSVParser("personsDelete.csv", "addressesDelete.csv");
        return csvParser.getPersons().iterator();
    }

    @Test (dataProvider = "deleteTest_negativeDP")
    private void deleteTest_negative(Person person, AppException expectedException) throws SQLException {
        ConnectionManager connectionManager = initiliseConnection();
        PersonService personService = new PersonService(connectionManager, new AddressService(connectionManager));
        try {
            personService.delete(person);
            connectionManager.commit();
            Assert.fail("Expected an AppException");
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCode(), expectedException.getErrorCode());
        } finally {
            connectionManager.close();
            personService = null;
        }
    }

    @DataProvider
    private Object[][] deleteTest_negativeDP() {
        Address address = new Address("Boovan street", "Banglore", 600123);
        Person person = new Person("Lokesh4",
                                   "Lokesh4",
                                   "lokeshbalaji684@gmail.com",
                                   address,
                                   LocalDate.parse("09-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        person.setId(8);
        return new Object[][] {
            {person, new AppException(Error.INVALID_PERSON_REQUEST)}
        };
    }

    @AfterClass
    private void afterClass() throws SQLException {
    }
}
