package com.objectfrontier.training.service.DAO;

import java.util.List;

import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;

public interface AddressDAO {

    List<Address> readAll();

    List<Address> readAll(int limit, int offset);

    Address read(long id);

    Address update(Address address);

    Address delete(Address address);

    Address create(Address address);

    List<Address> search(String searchText);

    <V> boolean isPresent(String checkField, String conditionalField, V value);

}
