// class VarArgsDemonstrator {
public class VarArgsDemonstrator {

    // static void execute() {
    public static void main(String[] args) {

        // VarArgsDemonstrator firstDemonstrator = displayName(agrasha);
        VarArgsDemonstrator firstDemonstrator = new VarArgsDemonstrator();
        firstDemonstrator.displayName("agrasha");

        // VarArgsDemonstrator secondDemonstrator = displayName(agrasha, janarthanan);
        VarArgsDemonstrator secondDemonstrator = new VarArgsDemonstrator();
        secondDemonstrator.displayName("agrasha", "janarthanan");

        // VarArgsDemonstrator thirdDemonstrator = displayName();
        VarArgsDemonstrator thirdDemonstrator = new VarArgsDemonstrator();
        thirdDemonstrator.displayName();
    }

    // void displayName(String... name) {
    void displayName(String... name) {

        // Console console = getConsole()......
        // console.print(name);
        for(String myName : name) {

            System.out.println(myName);
        }
    }
}
