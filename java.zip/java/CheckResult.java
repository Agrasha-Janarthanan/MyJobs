// class CheckResult {
public class CheckResult {

    // static void execute() {
    public static void main(String[] args) {

        Double doubleNumber = new Double(9876.20);

        // float floatNumber = convertToFloat(doubleNumber);
        float floatNumber = doubleNumber.floatValue();

        // Console console = getConsole()...
        // console.print(floatNumber);
        System.out.println(floatNumber);

        // console.print(hasSpecialNumber(floatNumber));
        System.out.println(Double.isNaN(floatNumber));
    }
}
