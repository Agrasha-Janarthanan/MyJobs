// class InitialFinder {
public class InitialFinder {

    // static void execute() {
    public static void main(String[] args) {

        // String fullname = getName();
        String fullName = "Agrasha Janarthanan";

        // String name = fullname.getSubString();
        String[] name = fullName.split(" ");

        // String initial = name.getFirstLetter();
        // Console console = getConsole()....
        // console.print(initial);
        for(int index = 0; index < name.length; index++) {

            char initial = name[index].charAt(0);
            System.out.print(initial);
        }
    }
}
