// class IntegerConverter {
public class IntegerConverter {

    // static void execute() {
    public static void main(String[] args) {

        int number = 65;

        // String hexaNumber = convertToHexaNumer(number);
        String hexaNumber = Integer.toHexString(number);

        // Console console = getConsole()...
        // console.print(hexaNumber);
        System.out.println(hexaNumber);
    }
}
