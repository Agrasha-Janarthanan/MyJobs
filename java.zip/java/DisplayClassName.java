public class DisplayClassName {

    public static void main(String[] args) {

        System.out.println(int.class.getName());
        System.out.println(char.class.getName());
        System.out.println(float.class.getName());
    }
}
