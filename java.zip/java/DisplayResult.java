public class DisplayResult {

    public static void main(String[] args) {

        Object result = 100/24;
        System.out.println(result.getClass().getTypeName());

        Object result1 = 100.01/2.01;
        System.out.println(result1.getClass().getTypeName());

        Object result2 = 'Z' / 2;
        System.out.println(result2.getClass().getTypeName());


        Object result3 = 10.5 / 0.5;
        System.out.println(result3.getClass().getTypeName());

        Object result4 = 12.4 % 5.5;
        System.out.println(result4.getClass().getTypeName());

        Object result5 = 100 % 56;
        System.out.println(result5.getClass().getTypeName());
    }
}
