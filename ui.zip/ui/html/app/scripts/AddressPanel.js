function createAddressPanel() {
    createChildren();
}

var createChildren = function () {
    createListPanel();
    createInformationPanel();
}
