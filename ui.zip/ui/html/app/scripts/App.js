function onLoad() {

    var createChildren = function () {
        createLsp();
        createRsp();
    }
    createChildren();
}
