function createPersonPanel() {
    createChildren();
}

var createChildren = function () {
    createListPanel();
    createInformationPanel();
}
