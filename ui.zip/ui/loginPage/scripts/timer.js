var count = 1;
function changeText() {
    setInterval(function() {
        var element = document.getElementById("message");
        element.innerHTML = count++;
    }, 1000);
}