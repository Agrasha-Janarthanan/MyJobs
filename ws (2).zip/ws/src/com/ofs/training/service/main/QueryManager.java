package com.ofs.training.service.main;

public interface QueryManager {

    static final String createPerson = new StringBuilder().append("INSERT INTO person (first_name   ")
                                                          .append("                   , last_name   ")
                                                          .append("                   , email       ")
                                                          .append("                   , birth_date  ")
                                                          .append("                   , password    ")
                                                          .append("                   , isAdmin     ")
                                                          .append("                   , address_id) ")
                                                          .append("VALUES (?, ?, ?, ?, ?, ?, ?)           ")
                                                          .toString();

    static final String updatePerson = new StringBuilder().append("UPDATE person          ")
                                                          .append("   SET first_name = ?  ")
                                                          .append("     , last_name = ?   ")
                                                          .append("     , email = ?       ")
                                                          .append("     , birth_date = ?  ")
                                                          .append("     , password = ?    ")
                                                          .append("     , isAdmin = ?     ")
                                                          .append("     , address_id = ?  ")
                                                          .append(" WHERE id = ?          ")
                                                          .toString();

    static final String readPerson = new StringBuilder().append("SELECT id             ")
                                                        .append("     , first_name     ")
                                                        .append("     , last_name      ")
                                                        .append("     , email          ")
                                                        .append("     , birth_date     ")
                                                        .append("     , created_date   ")
                                                        .append("     , address_id     ")
                                                        .append("     , isAdmin     ")
                                                        .append("  FROM person         ")
                                                        .append(" WHERE id = ?         ")
                                                        .toString();

    static final String getPersonPasswordByEmail = new StringBuilder().append("SELECT id, email, isAdmin             ")
                                                                      .append("  FROM person                         ")
                                                                      .append(" WHERE email = ?                      ")
                                                                      .append("   AND password = ?                   ")
                                                                      .toString();
    
    static final String readAllPerson = new StringBuilder().append("SELECT id             ")
                                                           .append("       , first_name   ")
                                                           .append("       , last_name    ")
                                                           .append("       , email        ")
                                                           .append("       , birth_date   ")
                                                           .append("       , created_date ")
                                                           .append("       , address_id   ")
                                                           .append("       , isAdmin      ")
                                                           .append("  FROM person         ")
                                                           .toString();

    static final String deletePerson = new StringBuilder().append("DELETE FROM person ")
                                                          .append("WHERE id = ?       ")
                                                          .toString();

    static final String countPersonByName = new StringBuilder().append("SELECT COUNT(id) FROM person")
                                                               .append(" WHERE first_name = ?       ")
                                                               .append("   AND last_name = ?        ")
                                                               .toString();

    static final String countPersonByEmail = new StringBuilder().append("SELECT COUNT(id) FROM person")
                                                                .append(" WHERE email = ?            ")
                                                                .toString();

    static final String createAddress = new StringBuilder().append("INSERT INTO address (street"    )
                                                           .append("          , city, postal_code) ")
                                                           .append("     VALUES (?, ?, ?)          ")
                                                           .toString();

    static final String updateAddress = new StringBuilder().append("UPDATE address          ")
                                                           .append("   SET street = ?       ")
                                                           .append("     , city = ?         ")
                                                           .append("     , postal_code = ?  ")
                                                           .append(" WHERE id = ?           ")
                                                           .toString();

    static final String readAddress = new StringBuilder().append("SELECT id, street, city, postal_code ")
                                                         .append("FROM address                         ")
                                                         .append("WHERE id = ?                         ")
                                                         .toString();

    static final String readAllAddress = new StringBuilder().append("SELECT id, street, city, postal_code ")
                                                            .append("FROM address                         ")
                                                            .toString();

    static final String deleteAddress = new StringBuilder().append("DELETE FROM address ")
                                                           .append("WHERE id = ?        ")
                                                           .toString();

    static final String searchAddress = new StringBuffer().append("SELECT id, street, city, postal_code ")
                                                          .append("  FROM address                       ")
                                                          .append(" WHERE                               ")
                                                          .toString();
}