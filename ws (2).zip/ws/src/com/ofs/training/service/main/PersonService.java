package com.ofs.training.service.main;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class PersonService {

    AddressService addressService = new AddressService();

    private void validate(Person person, Connection conn) throws Exception{

        List<Error> errors = new ArrayList<Error>();

        if (isEmpty(person.getFirstName())) {
            errors.add(Error.INVALID_FIRSTNAME);
        }

        if (isEmpty(person.getLastName())) {
            errors.add(Error.INVALID_LASTNAME);
        }

        if (isEmpty(person.getEmail())) {
            errors.add(Error.INVALID_EMAIL);
        }

        if (person.getBirthDate() == null) {
            errors.add(Error.INVALID_BIRTHDATE);
        }

        try {
            validateName(person, conn);
        } catch (AppException e) {
            errors.addAll(e.getErrorCodes());
        }

        try {
            validateEmail(person, conn);
        } catch (AppException e) {
            errors.addAll(e.getErrorCodes());
        }

        if (errors.size() > 0) {
            throw new AppException(errors);
        }
    }

    private boolean isEmpty(String value) {
        return Objects.isNull(value) || "".equals(value);
    }

    private void validateName(Person person, Connection conn) throws Exception{

        try {
            String query = QueryManager.countPersonByName;
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            ResultSet executeQuery = statement.executeQuery();
            executeQuery.next();
            int count = executeQuery.getInt(1);
            if (count > 0) {
                List<Error> errors = new ArrayList<>();
                errors.add(Error.DUPLICATE_NAME);
                throw new AppException(errors);
            }
        } catch (SQLException exception) {
             throw new AppException(Error.DATABASE_ERROR, exception.getCause());
        }
    }

    private void validateEmail(Person person, Connection conn) throws Exception {

        try {
            String query = QueryManager.countPersonByEmail;
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, person.getEmail());
            ResultSet executeQuery = statement.executeQuery();
            executeQuery.next();
            int count = executeQuery.getInt(1);
            if (count > 0) {
                List<Error> errors = new ArrayList<>();
                errors.add(Error.DUPLICATE_EMAIL);
                throw new AppException(errors);
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }

    private void validateId(long id, Connection conn) throws Exception {

        if (id == 0) {
            List<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_ID);
            throw new AppException(errors);
        }
    }

    private void constructPerson(Person person, ResultSet result) throws Exception {

        try {
            person.setId         (result.getLong("id"));
            person.setFirstName  (result.getString("first_name"));
            person.setLastName   (result.getString("last_name"));
            person.setEmail      (result.getString("email"));
            person.setBirthDate  (result.getDate("birth_date"));
            person.setPassword   (result.getString("password"));
            person.setAdmin       (result.getBoolean("isAdmin"));
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }


    private void setValue(Person person, PreparedStatement statement) throws AppException {

        try {
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setString(3, person.getEmail());
            statement.setDate  (4, person.getBirthDate());
            statement.setString  (5, person.getPassword());
            statement.setBoolean  (6, person.isAdmin());
        } catch (Exception e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }

    public Person create(Person person, Connection conn) throws Exception {

        long generatedKey = 0;

        String insertQuery = QueryManager.createPerson;
        try {
            validate(person, conn);

            PreparedStatement statement = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
            Address address = addressService.create(person.getAddress(), conn);
            setValue(person, statement);
            person.setAddress  (address);
            statement.setLong  (7, person.getAddress().getId());
            statement.executeUpdate();

            ResultSet generatedKeys = statement.getGeneratedKeys();
            if ((generatedKeys != null) && (generatedKeys.next())) {
                generatedKey = generatedKeys.getLong(1);
            }
            person.setId(generatedKey);
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return person; 
    }

    public Person update(Person person, Connection conn) throws Exception {

        String query = QueryManager.updatePerson;

        try {
            validateId(person.getId(), conn);

            PreparedStatement statement = conn.prepareStatement(query);
            Address address = addressService.update(person.getAddress(), conn);
            setValue(person, statement);
            person.setAddress  (address);
            statement.setLong  (7, person.getAddress().getId());
            statement.setLong  (8, person.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return person;
    }

    public Person read(long id, boolean includeAddress, Connection connection) throws Exception {

        String readQuery = QueryManager.readPerson;
        Person person = new Person();
        try {

            validateId(id, connection);
            PreparedStatement statement = connection.prepareStatement(readQuery);
            statement.setLong(1, id);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) { 
                constructPerson(person, rs);
                if (includeAddress) {
                    Address address = new Address();
                    address.setId(rs.getLong("address_id"));
                    Address readAddress = addressService.read(address.getId(), connection);
                    person.setAddress(readAddress);
                }
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return person;
    }

    public List<Person> readAll(boolean includeAddress, Connection conn) throws Exception {

        String readAllQuery = QueryManager.readAllPerson;
        List<Person> resultRecord = new ArrayList<>();
        Person person;

        try {

                ArrayList<Address> addresses = addressService.readAll(conn);
                Map<Long, Address> addressMapper = new HashMap<>();
                for (Address address : addresses) {
                    addressMapper.put(address.getId(), address);
                }
                PreparedStatement statement = conn.prepareStatement(readAllQuery);
                ResultSet result = statement.executeQuery();

                while (result.next()) {
                    person = new Person();
                    constructPerson(person, result);

                    if (includeAddress) {
                        Address address = new Address();
                        address.setId(result.getLong("address_id"));
                        person.setAddress(address);
                        person.setAddress(addressMapper.get(person.getAddress().getId()));
                    }
                    resultRecord.add(person);
                }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return resultRecord;
    }

    public Person delete(long id, Connection conn) throws Exception {

        String deleteQuery = QueryManager.deletePerson;

        try {
            validateId(id,conn);
            boolean includeAddress = true;
            Person person = read(id, includeAddress, conn);
            PreparedStatement statement = conn.prepareStatement(deleteQuery.toString());
            statement.setLong(1, id);
            statement.executeUpdate();
            addressService.delete(person.getAddress().getId(), conn);
            return person;
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }
}
