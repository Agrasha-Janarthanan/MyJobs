package com.ofs.training.servlets.test;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.Error;
import com.ofs.training.servlets.plugin.HttpMethod;
import com.ofs.training.servlets.plugin.JsonUtil;
import com.ofs.training.servlets.plugin.RequestHelper;
import com.ofs.training.servlets.plugin.Response;

public class AddressServletTest extends TestBaseServlet {

    RequestHelper helper;
    AddressParser parser;

    @BeforeClass
    public void setUp() {

        helper = new RequestHelper();
        parser = new AddressParser();
    }

    @Test(dataProvider = "testCreate_positiveDP", priority = 1)
    public void testCreate_positive(String uri, Address input) throws Exception {

            Address actual  = helper.setMethod(HttpMethod.PUT)
                                    .setSecured(true)
                                    .setInput(input)
                                    .requestObject(uri, Address.class);
            input.setId(actual.getId());
            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testCreate_positiveDP() {

        String uri = "http://localhost:8080/ws/address";
        Address address = new Address("xyz street", "tvm", 606601);
        return new Object[][] {
                                {uri, address}
                              };
    }

    @Test(dataProvider = "testUpdate_positiveDP", priority = 2)
    public void testUpdate_positive(String uri, Address input) throws Exception {

        Address actual = helper.setMethod(HttpMethod.POST)
                               .setInput(input)
                               .requestObject(uri, Address.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        String uri = "http://localhost:8080/ws/address";
        Address address = new Address();
        address.setId(1);
        address.setStreet("car street");
        address.setCity("tvm");
        address.setPostalCode(606601);
        return new Object[][] {
                                {uri, address}
                              };
    }

    @Test(dataProvider = "testDelete_positiveDP", priority = 3)
    public void testDelete_positive(String uri, Address input) throws Exception {

        Address actual = helper.setMethod(HttpMethod.DELETE)
                               .requestObject(uri, Address.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {

        String uri = "http://localhost:8080/ws/address?id=4";
        Address address = new Address();
        address.setId(4);
        address.setStreet("Marinjana koil");
        address.setCity("Sannamalai");
        address.setPostalCode(636615);
        return new Object[][] {
                                {uri, address}
                              };
    }

    @Test(dataProvider = "testDelete_negativeDP", priority = 4)
    public void testDelete_negative(String uri, List<Error> expected) throws Exception {

        List<?> actual = helper.setMethod(HttpMethod.DELETE)
                               .requestObject(uri, List.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testDelete_negativeDP() {

        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_URL_EXCEPTION);
        return new Object[][] {
                                {"http://localhost:8080/ws/address?id", errors},
                                {"http://localhost:8080/ws/address?id=", errors},
                                {"http://localhost:8080/ws/address?id=abc", errors},
                              };
    }

    @Test(dataProvider = "testRead_positiveDP", priority = 6)
    public void testRead_positive(String uri, Address input) throws Exception {

        Address actual = helper.setMethod(HttpMethod.GET)
                               .requestObject(uri, Address.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {

        String uri = "http://localhost:8080/ws/address?id=2";
        Address address = new Address();
        address.setId(2);
        address.setStreet("Thirumanjana gopuram street");
        address.setCity("Thiruvanamalai");
        address.setPostalCode(606601);
        return new Object[][] {
                                {uri, address}
                              };
    }

    @Test(dataProvider = "testRead_negativeDP", priority = 7)
    public void testRead_negative(String uri, List<Error> expected) throws Exception {

        List<?> actual = helper.setMethod(HttpMethod.GET)
                               .requestObject(uri, List.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {

        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_URL_EXCEPTION);
        return new Object[][] {
                                {"http://localhost:8080/ws/address?id", errors},
                                {"http://localhost:8080/ws/address?id=", errors},
                                {"http://localhost:8080/ws/address?id=abc", errors},
                                {"http://localhost:8080/ws/address?id=7.20", errors}
                              };
    }

    @Test(dataProvider = "testReadAll_positiveDP", priority = 8)
    public void testReadAll_positive(String uri, List<Address> input) throws Exception {

        List<?> actual = helper.setMethod(HttpMethod.GET)
                               .requestObject(uri, List.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {

        String uri = "http://localhost:8080/ws/address";
        List<Address> addresses = new ArrayList<>();
        addresses.add(new Address(1, "car street", "tvm", 606601));
        addresses.add(new Address(2, "Thirumanjana gopuram street", "Thiruvanamalai", 606601));
        addresses.add(new Address(3, "Perumal koil street", "Chennai", 600015));
        return new Object[][] {
                                {uri, addresses}
                              };
    }

    @Test(dataProvider = "testSearch_positiveDP", priority = 9)
    public void testSearch_positive(List<Address> input, String[] fields, String searchInput) throws Exception {

        StringBuilder uri = new StringBuilder("http://localhost:8080/ws/address?searchInput=").append(searchInput)
                                                                                              .append("&searchField=");
        for (String field : fields) {
            uri.append(field);
            uri.append(",");
        }
        uri.substring(0, uri.length() - 1);

        List<?> actual = helper.setMethod(HttpMethod.GET)
                                       .requestObject(uri.toString(), List.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input)); 
    }

    @DataProvider
    private Object[][] testSearch_positiveDP() {

        List<Address> addresses = new ArrayList<>();
        addresses.add(new Address(3, "Perumal koil street", "Chennai", 600015));
        String[] field = {"city", "street"};
        String searchInput = "koil";
        return new Object[][] {
                                {addresses, field, searchInput}
                              };
    }

    @Test(dataProvider = "testSearch_negativeDP", priority = 10)
    public void testSearch_negative(String uri, List<Error> expected) throws Exception {

        List<?> actual = helper.setMethod(HttpMethod.GET)
                               .requestObject(uri, List.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testSearch_negativeDP() {

        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_URL_EXCEPTION);
        return new Object[][] {
                                {"http://localhost:8080/ws/address?searchInput=&searchField=", errors},
                                {"http://localhost:8080/ws/address?searchInput=", errors},
                                {"http://localhost:8080/ws/address?searchInput=7.2&searchField=", errors},
                                {"http://localhost:8080/ws/address?searchField=", errors},
                              };
    }
}
