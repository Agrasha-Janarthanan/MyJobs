package com.ofs.training.servlets.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.ofs.training.service.main.Error;
import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.AppException;

public class AddressParser {

    public List<Address> parse(String file) {

        List<Address> addresses = new ArrayList<>();
        final String DELIMITER = ",";
        BufferedReader br;
        String line;
        try {
            br = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("AddressData.csv")));

            while ((line = br.readLine()) != null) {

                String[] data = line.split(DELIMITER);
                Address address = new Address();
                address.setStreet(data[0]);
                address.setCity(data[1]);
                address.setPostalCode(Integer.parseInt((data[2])));
                addresses.add(address);
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
            List<Error> errors = new ArrayList<>();
            errors.add(Error.PARSER_EXCEPTION);
            throw new AppException(errors);
        }
        return addresses;
    }
}
