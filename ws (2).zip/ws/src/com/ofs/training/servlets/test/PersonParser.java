package com.ofs.training.servlets.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.AppException;
import com.ofs.training.service.main.Error;
import com.ofs.training.service.main.Person;

public class PersonParser {

    public List<Person> parse(String fileName) {

        List<Person> persons = new ArrayList<>();
        final String DELIMITER = ",";
        BufferedReader br;
        String line;
        try {
            br = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("PersonData.csv")));

            while ((line = br.readLine()) != null) {

                String[] data = line.split(DELIMITER);
                Person person = new Person();
                Address address = new Address();
                person.setFirstName(data[0]);
                person.setLastName(data[1]);
                person.setEmail(data[2]);
                Date date = new Date(Long.parseLong(data[3]));
                SimpleDateFormat format = new SimpleDateFormat("dd/mm/yyyy");
                person.setBirthDate(Date.valueOf(format.format(date)));
                address.setStreet(data[4]);
                address.setCity(data[5]);
                address.setPostalCode(Integer.parseInt((data[6])));
                person.setAddress(address);
                persons.add(person);
            }
            br.close();
        } catch (Exception e) {
//            List<Error> errors = new ArrayList<>();
//            errors.add(Error.PARSER_EXCEPTION);
//            throw new AppException(errors);
            e.printStackTrace();
        }
        return persons;
    }
}
