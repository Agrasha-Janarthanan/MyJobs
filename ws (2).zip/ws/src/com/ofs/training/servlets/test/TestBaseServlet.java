package com.ofs.training.servlets.test;

import java.net.URI;
import java.net.URL;

import org.apache.http.HttpResponse;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.util.resource.Resource;
import org.eclipse.jetty.webapp.WebAppContext;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.ofs.training.service.main.AppException;
import com.ofs.training.service.main.Person;
import com.ofs.training.servlets.plugin.HttpMethod;
import com.ofs.training.servlets.plugin.RequestHelper;

public class TestBaseServlet {

    Person person = new Person(); //initialize your person with credentials
    protected RequestHelper login() { return login(person); }
    protected RequestHelper login(Person person) {

        try {

            RequestHelper helper = RequestHelper.create();
            //Prepare your login call here, if you have implemented it in a different HTTP Method
            HttpResponse response = helper.setMethod(HttpMethod.GET).setInput(person).requestRaw("/login?email=g@gmail.com&password=password");
            log(RequestHelper.asString(response));
            Assert.assertEquals(RequestHelper.getStatus(response), 200);
            helper.setSecureDetails(response);
            System.out.println(helper);
            return helper;
        } catch (Exception e) {
            throw new AppException(e);
        }
    }

    private static Server server;
    private static int port = 8080;
    private static String contextPath = "/ws";

    @BeforeSuite
    protected void initServer() throws Exception {

        // creating server instance
      server = new Server(port);
      System.out.println(server.getClass().getClassLoader().getSystemResource("."));
      URL webXmlResource = server.getClass().getClassLoader().getResource("WEB-INF/web.xml");
      System.out.println(webXmlResource);
      URI webResourceBase = webXmlResource.toURI().resolve("..").normalize();

      log("Using BaseResource: " + webResourceBase);
      WebAppContext context = new WebAppContext();
      context.setBaseResource(Resource.newResource(webResourceBase));

      context.setContextPath(contextPath);
      context.setParentLoaderPriority(true);
      server.setHandler(context);
      server.start();

      String baseUrl = String.format("http://localhost:%s%s", port, contextPath);
      RequestHelper.setBaseUrl(baseUrl);
}

    @AfterSuite
    protected void stopServer() throws Exception {
        server.stop();
    }

    void log(String message) {
        System.out.println(message);
    }
 }