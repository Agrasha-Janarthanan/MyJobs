package com.ofs.training.servlets.test;

import java.io.File;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.Error;
import com.ofs.training.service.main.Person;
import com.ofs.training.servlets.plugin.HttpMethod;
import com.ofs.training.servlets.plugin.JsonUtil;
import com.ofs.training.servlets.plugin.RequestHelper;

public class PersonServletTest {

    RequestHelper helper;
    AddressParser parser;
    File file = new File("com.ofs.training.servlets.test.AddressData.csv");

    @BeforeClass
    public void setUp() {
        helper = new RequestHelper();
        parser = new AddressParser();
    }

    @Test(dataProvider = "testCreate_positiveDP")
    public void testCreate_positive(String uri, Person input) throws Exception {

        Person person = helper.setMethod(HttpMethod.PUT)
                                  .setInput(input)
                                  .requestObject(uri, Person.class);

        input.setId(person.getId());
        Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testCreate_positiveDP() {

        String uri = "http://localhost:8080/ws/person";
        Address address = new Address(1, "pqr street", "Palam", 606601);
        Person person = new Person("Emily", "Blunt", "emBlu@123", Date.valueOf("1990-09-09"), address, "demo", false);
        Address anotherAddress = new Address(2, "car street", "tvm", 606601);
        Person anotherPerson = new Person("Ayshu", "Devi", "g@gmail.com", Date.valueOf("1996-08-08"), anotherAddress, "password", true);
        return new Object[][] {
                                {uri, person},
                                {uri, anotherPerson}
                              };
    }

    @Test(dataProvider = "testUpdate_positiveDP")
    public void testUpdate_positive(String uri, Person input) throws Exception {

        Person person = helper.setMethod(HttpMethod.POST)
                                  .setInput(input)
                                  .requestObject(uri, Person.class);

        Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        String uri = "http://localhost:8080/ws/person?id=1";
        Address anotherAddress = new Address(2, "car street", "tvm", 606601);
        Person person = new Person();
        person.setId(2);
        person.setFirstName("Ayshu");
        person.setLastName("Ezhil");
        person.setEmail("g@gmail.com");
        person.setBirthDate(Date.valueOf("1996-08-08"));
        person.setAddress(anotherAddress);
        return new Object[][] {
                                {uri, person}
                              };
    }

    @Test(dataProvider = "testDelete_positiveDP")
    public void testDelete_positive(String uri, Person input) throws Exception {

        Person person = helper.setMethod(HttpMethod.DELETE)
                                  .requestObject(uri, Person.class);

        Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {

        String uri = "http://localhost:8080/ws/person?id=1";
        Address address = new Address(1, "pqr street", "Palam", 606601);
        Person person = new Person(1, "Emily", "Blunt", "emBlu@123", Date.valueOf("1990-09-09"), address, "demo", false);
        return new Object[][] {
                                {uri, person}
                              };
    }

    @Test(dataProvider = "testDelete_negativeDP")
    public void testDelete_negative(String uri, List<Error> expected) throws Exception {

        List<?> person = helper.setMethod(HttpMethod.DELETE)
                                  .requestObject(uri, List.class);

        Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testDelete_negativeDP() {

        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_URL_EXCEPTION);
        return new Object[][] {
                                {"http://localhost:8080/ws/person?id", errors},
                                {"http://localhost:8080/ws/person?id=", errors},
                                {"http://localhost:8080/ws/person?id=1adg", errors}
                              };
    }

    @Test(dataProvider = "testRead_positiveDP")
    public void testRead_positive(String uri, Person input) throws Exception {

        Person person = helper.setMethod(HttpMethod.GET)
                                  .requestObject(uri, Person.class);

        Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {

        String uri = "http://localhost:8080/ws/person?id=1&includeAddress=true";
        Address address = new Address(1, "pqr street", "Palam", 606601);
        Person person = new Person(1, "Emily", "Blunt", "emBlu@123", Date.valueOf("1990-09-09"), address, "demo", false);
        return new Object[][] {
                                {uri, person}
                              };
    }

    @Test(dataProvider = "testRead_negativeDP")
    public void testRead_negative(String uri, List<Error> expected) throws Exception {

        List<?> person = helper.setMethod(HttpMethod.GET)
                                  .requestObject(uri, List.class);

        Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {

        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_URL_EXCEPTION);
        return new Object[][] {
                                {"http://localhost:8080/ws/person?id", errors},
                                {"http://localhost:8080/ws/person?id=", errors},
                                {"http://localhost:8080/ws/person?id=abc", errors},
                                {"http://localhost:8080/ws/person?id=7.20", errors}
                              };
    }

    @Test(dataProvider = "testReadAll_positiveDP")
    public void testReadAll_positive(String uri, List<Person> input) throws Exception {

        List<?> actual = helper.setMethod(HttpMethod.GET)
                                     .requestObject(uri, List.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {

        String uri = "http://localhost:8080/ws/person?includeAddress=true";
        List<Person> persons = new ArrayList<>();
        persons.add(new Person(1, "Emily", "Blunt", "emBlu@123", Date.valueOf("1990-09-09"), new Address(1, "pqr street", "Palam", 606601), "demo", false));
        persons.add(new Person(2, "Ayshu", "Ezhil", "g@gmail.com", Date.valueOf("1996-08-08"), new Address(2, "car street", "tvm", 606601), "password", true));

        return new Object[][] {
                                {uri, persons}
                              };
    }
}
