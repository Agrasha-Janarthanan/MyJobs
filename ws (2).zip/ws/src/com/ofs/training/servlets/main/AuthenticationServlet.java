package com.ofs.training.servlets.main;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Objects;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ofs.training.service.main.AppException;
import com.ofs.training.service.main.ConnectionManager;
import com.ofs.training.service.main.Error;
import com.ofs.training.service.main.AuthenticationService;
import com.ofs.training.service.main.Person;
import com.ofs.training.servlets.plugin.JsonUtil;

public class AuthenticationServlet extends HttpServlet{


    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        AuthenticationService loginService = new AuthenticationService();
        Connection con = ConnectionManager.openConnection();
        PrintWriter out = response.getWriter();

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Person person = loginService.login(email, password, con);
        HttpSession session = request.getSession();
        String sessionId = request.getRequestedSessionId();
        Cookie setCookie = new Cookie("Set-Cookie", sessionId);
        response.addCookie(setCookie);
        session.setAttribute("person", person);
        out.write(JsonUtil.toJson(sessionId));
        ConnectionManager.releaseConnection(true);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        if (! Objects.isNull(session)) {
            session.invalidate();
        } else {
            throw new AppException(Error.INVALID_REQUEST);
        }
    }
}
