package com.ofs.training.servlets.plugin;

public class Response {

    int statusCode;
    String content;
    public Response(int statusCode, String content) {
        super();
        this.statusCode = statusCode;
        this.content = content;
    }
    public int getStatusCode() {
        return statusCode;
    }
    public String getContent() {
        return content;
    }
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }
    public void setContent(String content) {
        this.content = content;
    }

    public Response() {
        super();
        // TODO Auto-generated constructor stub
    }
}
