package com.ofs.training.filter;


import java.net.URI;
import java.net.URL;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.util.resource.Resource;
import org.eclipse.jetty.webapp.WebAppContext;

/**
 * @author Lokesh.
 * @since Nov 23, 2018
 */
public class JettyIntiliser {

    private Server server;
    
    public void init() throws Exception {
        server = new Server(8080);

        URL webXmlResource = server.getClass().getClassLoader().getResource("WEB-INF/web.xml");
        System.out.println(webXmlResource);
        URI webResourceBase = webXmlResource.toURI().resolve("..").normalize();
        System.out.println(webResourceBase);

        System.out.println("Using BaseResource: " + webResourceBase);
        WebAppContext context = new WebAppContext();
        context.setBaseResource(Resource.newResource(webResourceBase));

        context.setContextPath("/ws");
        context.setParentLoaderPriority(true);
        server.setHandler(context);
        server.start();
    }
    
    public static void main(String[] args) throws Exception {
        JettyIntiliser jettyIntiliser = new JettyIntiliser();
        jettyIntiliser.init();
    }
}
