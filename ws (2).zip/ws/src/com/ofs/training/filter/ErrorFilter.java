package com.ofs.training.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;

import com.ofs.training.service.main.AppException;
import com.ofs.training.service.main.Error;
import com.ofs.training.servlets.plugin.JsonUtil;

public class ErrorFilter implements Filter{

    @Override
    public void init(FilterConfig config) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        
        PrintWriter out = response.getWriter();
        try {
            chain.doFilter(request, response);
//            ((HttpServletResponse) response).setStatus(HttpStatus.SC_ACCEPTED); 
        } catch (Exception e) {
            if (e instanceof AppException) {
                out.write(JsonUtil.toJson(((AppException) e).getErrorCodes()));
            } else {
                ArrayList<Error> errors = new ArrayList<>();
                errors.add(Error.INTERNAL_SERVER_ERROR);
                out.write(JsonUtil.toJson(errors));
            }
        }
    }

    @Override
    public void destroy() {
    }
}
