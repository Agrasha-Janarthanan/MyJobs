package com.ofs.training.util;

import java.util.ArrayList;
import java.util.List;

import com.ofs.training.util.Error;

public class AppException extends RuntimeException{

    private static final long serialVersionUID = -1711827770663962725L;
    List<Error> errorCodes = new ArrayList<>();
    Error error;
    Throwable cause;

    public AppException(List<Error> errorCodes) {
        super();
        this.errorCodes = errorCodes;
    }

    public AppException(Error errorCode, Throwable cause) {
        super(errorCode.getErrorMessage(), cause);
        if (errorCodes != null && errorCodes.size() != 0) {
            errorCodes = new ArrayList<>();
            errorCodes.add(errorCode);
            this.cause = cause;
        }
    }

    public AppException(Throwable cause) {
        this(Error.UNKNOWN_ERROR, cause);
    }

    public AppException(List<Error> errorCodes, String message, Exception e) {
        super();
        this.errorCodes = errorCodes;
    }

    public AppException(Error error) {
        super();
        this.error = error;
    }

    public List<Error> getErrorCodes() {
        return errorCodes;
    }

    public void setErrorCodes(List<Error> errorCodes) {
        this.errorCodes = errorCodes;
    }

}
