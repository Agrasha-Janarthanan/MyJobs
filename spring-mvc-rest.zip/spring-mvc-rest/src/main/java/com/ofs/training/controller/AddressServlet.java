package com.ofs.training.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ofs.training.service.AddressService;

import com.ofs.training.model.Address;

@RestController
@ComponentScan(basePackages = {"com.ofs.training.service"})
@RequestMapping(value = "/address")
public class AddressServlet {

    @Autowired
    AddressService addressService;

    @RequestMapping(value = "/address", method = RequestMethod.PUT)
    protected Address doPut(@RequestBody Address address) {

        Address addrezz = addressService.create(address);
        return addrezz;
    }

    @RequestMapping(method = RequestMethod.POST)
    protected Address doPost(@RequestBody Address address) {

        Address addrezz = addressService.update(address);
        return addrezz;
    }

    @RequestMapping(value = "/address", method = RequestMethod.GET, params = {"id, searchInput, searchField"})
    protected List<Address> doSearch(@RequestBody Address address
                                     , @PathVariable("id, searchInput, searchField") long addressId
                                                                                 , String searchInput
                                                                                 , String searchField) {

        List<Address> result = new ArrayList<>();

        if ((searchField != null) || (searchInput != null)) {
            String[] fields = searchField.split(",");
            result = addressService.search(fields, searchInput);
        }
        return result;
    }

    @RequestMapping(value = "/address",method = RequestMethod.GET)
    protected List<Address> doGet() {

        List<Address> result = new ArrayList<>();
        result = addressService.readAll();
        return result;
    }

    @RequestMapping(method = RequestMethod.GET, params = {"id"})
    protected Address get(@RequestBody Address address, @PathVariable("id") long addressId) {

        Address addrezz = addressService.read(addressId);
        return addrezz;
    }

    @RequestMapping(method = RequestMethod.DELETE, params = {"id"})
    protected ResponseEntity<Object> doDelete(@RequestBody Address address, @PathVariable("id") long addressId) {

        addressService.delete(addressId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
