package com.ofs.training.controller;

import java.util.List;

import javax.servlet.http.HttpServlet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ofs.training.model.Person;
import com.ofs.training.service.PersonService;

@Controller
@RequestMapping("/person")
public class PersonServlet {


    @Autowired
    PersonService personService;

    @RequestMapping(method = RequestMethod.PUT)
    protected ResponseEntity<Person> doPut(@RequestBody Person person) {
        Person perzon = personService.create(person);
        return new ResponseEntity<> (perzon, null, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST)
    protected ResponseEntity<Person> doPost(@RequestBody Person person) {
        Person perzon = personService.update(person);
        return new ResponseEntity<> (perzon, null, HttpStatus.OK);
    }
    @RequestMapping(method = RequestMethod.GET)
    protected ResponseEntity<Person> doGet(@RequestBody Person person, @PathVariable("id") long id, boolean includeAddress) {
        Person perzon = personService.read(id, includeAddress);
        return new ResponseEntity<> (perzon, null, HttpStatus.OK);
    }

    @RequestMapping(params= {"action=readAll"}, method= RequestMethod.GET)
    protected ResponseEntity<List<Person>> doGetAll(@RequestParam ("includeAddress")boolean includeAddress) {
        List<Person> perzonz = personService.readAll(includeAddress);
        return new ResponseEntity<> (perzonz, null, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.DELETE)
    protected ResponseEntity<Person> doDelete(@RequestBody Person person, @PathVariable("id") long id) {
        personService.delete(id);
        return new ResponseEntity<> (HttpStatus.OK);
    }
}

