package com.ofs.training.service.main;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConnectionManager {

    Connection conn = null;
    public Connection openConnection() {

        try {
            String url = "jdbc:mysql://pc1620:3306/agrasha_janarthanan?useSSL=false";
            Properties properties = new Properties();
            InputStream inputStream = ConnectionManager.class.getResourceAsStream("ConnectionProperties.properties");
            properties.load(inputStream);
            conn = DriverManager.getConnection(url, properties);
            conn.setAutoCommit(false);
        } catch (Exception exception) {
            throw new RuntimeException("Invalid Connection");
        }
        return conn;
    }

    public void closeConnection() {

        try {
            conn.close();
        } catch (Exception exception) {
            throw new RuntimeException("Connection is not open");
        }
    }
}
