package com.ofs.training.service.test;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.AddressService;
import com.ofs.training.service.main.AppException;
import com.ofs.training.service.main.ConnectionManager;
import com.ofs.training.service.main.Error;

@Test
public class AddressServiceTest {

    AddressService addressService;

    @BeforeClass
    private void setUp() {
        addressService = new AddressService();
    }

    @Test(dataProvider = "testCreate_positiveDP", priority = 1, groups = "create")
    private void testCreate_positive(Address address, Address expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try{
            Address actualResult = addressService.create(address, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
                Assert.fail("Unexpected Exception for the given input"
                            + address
                            +"Expected result is "
                            + expectedResult
                            + e.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider()
    private Object[][] testCreate_positiveDP() {

        Address address = new Address ("Mint street", "Madras", 600235);
        Address expectedResult = new Address (1, "Mint street", "Madras", 600235);
        Address nextAddress = new Address ("Car street", "Tiruvannamalai", 606601);
        Address expectedOutput = new Address (2, "Car street", "Tiruvannamalai", 606601);
        return new Object[][] {
                               {address, expectedResult},
                               {nextAddress, expectedOutput}
                              };
    }

    @Test(dataProvider = "testCreate_negativeDP", priority = 2, groups = "create")
    private void testCreate_negative(Address address, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try{

            addressService.create(address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(expectedException.getErrorCodes(), e.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider()
    private Object[][] testCreate_negativeDP() {

        ArrayList<Error> errorListOne = new ArrayList<>();
        errorListOne.add(Error.INVALID_STREET);
        ArrayList<Error> errorListTwo = new ArrayList<>();
        errorListTwo.add(Error.INVALID_CITY);
        ArrayList<Error> errorListThree = new ArrayList<>();
        errorListThree.add(Error.INVALID_POSTALCODE);

        return new Object[][] {
                               {new Address (null, "Madras", 606601), new AppException(errorListOne)},
                               {new Address ("Mint street", null, 600028), new AppException(errorListTwo)},
                               {new Address ("Mint street", "Madras", 0), new AppException(errorListThree)}
                             };
    }

    @Test(dataProvider = "testUpdate_positiveDP", priority = 3)
    private void testUpdate_positive(Address address, Address expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {
            Address actualResult = addressService.update(address, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input"
                        + address
                        + "Expected result is "
                        + expectedResult
                        + e.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {
        
        Address address = new Address(1, "Mint street", "Chennai", 600235);
        Address expectedResult = new Address(1, "Mint street", "Chennai", 600235);
        return new Object[][] {
                               { address, expectedResult},
                              };
    }

    @Test(dataProvider = "testUpdate_negativeDP", priority = 4)
    private void testUpdate_negative(Address address, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try{
            addressService.update(address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testUpdate_negativeDP() {
        ArrayList<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_ID);
        return new Object[][] {
                                {new Address (0, "Mint street", "Mumbai", 606601), new AppException(errors)},
                              };
    }

    @Test(dataProvider = "testRead_positiveDP", priority = 5)
    private void testRead_positive(Address address, Address expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {
            Address actualResult = addressService.read(address, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input"
                        + address
                        + "Expected result is "
                        + expectedResult
                        + e.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {
        
        Address address = new Address(1, "Mint street", "Chennai", 600235);
        Address expectedResult = new Address(1, "Mint street", "Chennai", 600235);
        return new Object[][] {
                                { address, expectedResult},
                              };
    }

    @Test(dataProvider = "testRead_negativeDP", priority = 6)
    private void testRead_negative(Address address, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try{
            
            addressService.read(address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {
        ArrayList<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_ID);
        return new Object[][] {
                                {new Address (0, "Mint street", "Chennai", 606601)
                                 , new AppException(errors)}
                              };
    }

    @Test(dataProvider = "testReadAll_positiveDP", priority = 7)
    private void testReadAll_positive(List<Address> expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {
            List<Address> actualResult = addressService.readAll(conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
                Assert.fail("Unexpected Exception." 
                            + "Expected result is "
                            + expectedResult
                            + e.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {

        List<Address> expectedResult = new ArrayList<>();
        expectedResult.add(new Address(1, "Mint street", "Chennai", 600235));
        expectedResult.add(new Address(2, "Car street", "Tiruvannamalai", 606601));
        return new Object[][] {
                                {expectedResult},
                              };
    }

    @Test(dataProvider = "testSearch_positiveDP", priority = 8)
    private void testSearch_positive(String[] fields, String value, List<Address> expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {
            List<Address> actualResult = addressService.search(fields, value, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input"
                        + value
                        + "Expected result is "
                        + expectedResult
                        + e.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testSearch_positiveDP() {

        String[] fields = { "street", "city"};
        String value = "Ch";
        List<Address> expectedResult = new ArrayList<>();
        expectedResult.add(new Address(1, "Mint street", "Chennai", 600235));
        String[] columns = {"postalCode"};
        String searchValue = "660";
        List<Address> expectedRecord = new ArrayList<>();
        expectedRecord.add(new Address(2, "Car street", "Tiruvannamalai", 606601));
        return new Object[][] {
                                {fields, value, expectedResult},
                                {columns, searchValue, expectedRecord},
                              };
    }

    @Test(dataProvider = "testSearch_negativeDP", priority = 9)
    private void testSearch_negative(String[] fields, String value, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try{
            addressService.search(fields, value, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testSearch_negativeDP() {
        ArrayList<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_INPUT);
        return new Object[][] {
                                { null, null, new AppException(errors)},
                              };
    }

    @Test(dataProvider = "testDelete_positiveDP", priority = 10)
    private void testDelete_positive(Address address) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {
            addressService.delete(address, conn);
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input"
                        + address
                        + e.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {

        Address address = new Address(1, "Mint street", "Chennai", 600235);
        return new Object[][] {
                                {address}
                              };
    }

    @Test(dataProvider = "testDelete_negativeDP", priority = 11)
    private void testDelete_negative(Address address, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try{
            addressService.delete(address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testDelete_negativeDP() {
        ArrayList<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_ID);

        return new Object[][] {
            {new Address (0, "Mint street", "Mumbai", 606601), new AppException(errors)},
        };
    }
}
