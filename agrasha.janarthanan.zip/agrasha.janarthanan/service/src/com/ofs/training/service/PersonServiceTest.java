package com.ofs.training.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class PersonServiceTest {

    PersonService personService;
    String connectionString = new StringBuilder().append("jdbc:mysql://pc1620:3306/agrasha_janarthanan?useSSL=false")
                                                 .append("&user=agrasha_janarthanan&password=demo").toString();

    @BeforeClass
    private void initialize() {
        personService = new PersonService();
    }

//    @Test(dataProvider = "testCreateRecord_positiveDP", priority = 1)
//    private void testCreateRecord_positive(Person person, Person expectedResult) throws Exception {
//
//        ConnectionManager txn = new ConnectionManager();
//        Connection conn = txn.openConnection(connectionString);
//
//        try {
//            Person actualResult = personService.create(person, conn);
//            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
//            conn.commit();
//        } catch (AppException e) {
//            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e.getErrorCodes());
//        } finally {
//            conn.close();
//        }
//    }
//
//    @DataProvider
//    private Object[][] testCreateRecord_positiveDP() {
//        return new Object[][] { 
//                                { new Person ("agi", "jana","agi@gmail.com", Date.valueOf("1996-08-08"),
//                                  new Address ("Mint street", "Chennai", 600345)),
//                                  new Person (1, "agi", "jana","agi@gmail.com", Date.valueOf("1996-08-08"),
//                                  new Address (1, "Mint street", "Chennai", 600345))
//                                },
//                                { new Person ("agrasha", "janarthanan", "agrasha@gmail.com",Date.valueOf("1996-09-08"),
//                                  new Address ("Car street", "Tiruvannamalai", 606601)),
//                                  new Person (2, "agrasha", "janarthanan", "agrasha@gmail.com",Date.valueOf("1996-09-08"),
//                                  new Address (2, "Car street", "Tiruvannamalai", 606601))
//                                }
//        };
//    }
//
//    @Test(dataProvider = "testCreateRecord_negativeDP", priority = 2)
//    private void testCreateRecord_negative(Person person, AppException expectedException) throws Exception {
//
//        ConnectionManager txn = new ConnectionManager();
//        Connection conn = txn.openConnection(connectionString);
//
//        try {
//            personService.create(person, conn);
//            Assert.fail("Expected an exception.");
//            conn.rollback();
//        } catch (AppException e) {
//            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
//        } finally {
//            conn.close();
//        }
//    }
//
//    @DataProvider
//    private Object[][] testCreateRecord_negativeDP() {
//        return new Object[][] { 
//                                { new Person ("agrasha", "janarthanan", "agrasha@gmail.com", Date.valueOf("1996-08-08"),
//                                  new Address ("Car street", "Tiruvannamalai", 606601)),
//                                  new AppException(Error.DUPLICATE_EMAIL)
//                                },
//                                { new Person ("agrasha", "", "agrasha@gmail.com", Date.valueOf("1996-08-08"),
//                                  new Address ("Car street", "Tiruvannamalai", 606601)),
//                                  new AppException(Error.INVALID_LASTNAME)
//                                },
//                                { new Person ("", "janarthanan", "agrasha@gmail.com", Date.valueOf("1996-08-08"),
//                                  new Address ("Car street", "Tiruvannamalai", 606601)),
//                                  new AppException(Error.INVALID_FIRSTNAME)
//                                },
//                                {new Person ("agrasha", "janarthanan", "agrasha@gmail.com", null,
//                                 new Address ("Car street", "Tiruvannamalai", 606601)),
//                                 new AppException(Error.INVALID_BIRTHDATE)
//                                },
//                                {new Person ("agrasha", "janarthanan", "", Date.valueOf("1996-08-08"),
//                                 new Address ("Car street", "Tiruvannamalai", 606601)),
//                                 new AppException(Error.INVALID_EMAIL)
//                                },
//                                {new Person ("agrasha", "agrasha", "agrasha@gmail.com", Date.valueOf("1996-08-08"),
//                                 new Address ("Car street", "Tiruvannamalai", 606601)),
//                                 new AppException(Error.DUPLICATE_NAME)
//                                }
//                              };
//    }
//
//    @Test(dataProvider = "testUpdate_positiveDP", priority = 3)
//    private void testUpdate_positive(Person person, Person expectedResult) throws Exception {
//
//        ConnectionManager txn = new ConnectionManager();
//        Connection conn = txn.openConnection(connectionString);
//
//        try {
//
//            Person actualPerson = personService.update(person, conn);
//            Assert.assertEquals(actualPerson.toString(), expectedResult.toString());
//            conn.commit();
//        } catch (AppException e) {
//            Assert.fail("Unexpected exception for given input. Expected result is " + e.getErrorCode());
//        } finally {
//            conn.close();
//        }
//    }
//
//    @DataProvider
//    private Object[][] testUpdate_positiveDP() {
//
//        return new Object[][] { 
//                                { new Person(1, "agi", "jana", "abc@gmail.com", Date.valueOf("1996-08-08"),
//                                  new Address (1, "Mint street", "Chennai", 600345)),
//                                  new Person(1, "agi", "jana", "abc@gmail.com", Date.valueOf("1996-08-08"),
//                                  new Address (1, "Mint street", "Chennai", 600345))
//                                }
//                              };
//    }
//
//    @Test(dataProvider = "testUpdate_negativeDP", priority = 4)
//    private void testUpdate_negative(Person person, AppException exceptionMessage) throws Exception {
//
//        ConnectionManager txn = new ConnectionManager();
//        Connection conn = txn.openConnection(connectionString);
//
//        try {
//
//            personService.update(person, conn);
//            Assert.fail("Expected an exception.");
//            conn.rollback();
//        } catch (AppException e) {
//            Assert.assertEquals(e.getErrorCode(), exceptionMessage.getErrorCode());
//        } finally {
//            conn.close();
//        }
//    }
//
//    @DataProvider
//    private Object[][] testUpdate_negativeDP() {
//
//        Person person = new Person();
//        person.setId(0);
//        return new Object[][] { 
//                                {person, new AppException(Error.INVALID_ID)}
//                              };
//    }

    @Test(dataProvider = "testRead_positiveDP", priority = 5)
    private void testRead_positive(Person person, boolean includeAddress, Person expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try {
            Person actualResult = personService.read(person, includeAddress, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e.getErrorCode());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {
        Person person = new Person();
        person.setId(1);
        Person expectedResult = new Person(1, "agi", "jana", "abcd@gmail.com", Date.valueOf("1996-08-08"), null);
        Person person1 = new Person();
        person1.setId(2);
        Person expectedResult1 = new Person(2, "agrasha", "janarthanan", "agrasha@gmail.com", Date.valueOf("1996-09-08")
                                             , new Address(2, "Mint street", "Chennai", 600345)); 
        return new Object[][] {
            {person, false, expectedResult},
            {person1, true, expectedResult1}
        };
    }

    @Test(dataProvider= "testRead_negativeDP", priority = 6)
    private void testRead_negative(Person person, boolean includeAddress, AppException expectedException) throws Exception {
        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try {
            personService.read(person, includeAddress, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), expectedException.getErrorCode());
        }  finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {
        Person person = new Person();
        person.setId(0);
        return new Object[][] {
            {person, false, new AppException(Error.INVALID_ID)}
        };
    }
//
//    @Test(dataProvider = "testReadAllRecords_positiveDP", priority = 7)
//    private void testReadAllRecords_positive(boolean includeAddress, List<Object> expectedResult) {
//        try {
//
//            List<Object> actualResult = personService.readAll(includeAddress, conn);
//            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
//            conn.commit();
//        } catch (Exception e) {
//            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
//        }
//    }
//
//    @DataProvider
//    private Object[][] testReadAllRecords_positiveDP() {
//        List<Object> result = new ArrayList<>();
//        result.add(new Person("agi", "abcd@gmail.com", Date.valueOf("1996-08-08"), 1));
//        result.add(new Person("agrasha", "agrasha@gmail.com", Date.valueOf("1996-09-08"), 2));
////        [Person [name=agrasha, email=agrasha@gmail.com, birthDate=1996-09-08], Person [name=agrasha, email=agrasha@gmail.com, birthDate=1996-09-08]]
//        return new Object[][] { 
//                                {false, result}
//                              };
//    }
//
//    @Test(dataProvider = "testDeleteRecord_positiveDP", priority = 8)
//    private void testDeleteRecord_positive(Person person, Persron expectedResult) {
//        try {
//
//            Person actualResult = personService.delete(person, conn);
//            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
//            conn.commit();
//        } catch (Exception e) {
//            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
//        }
//    }
//
//    @DataProvider
//    private Object[][] testDeleteRecord_positiveDP() {
//
//        Person person = new Person ("agrasha", "agrasha@gmail.com",Date.valueOf("1996-09-08"), 2);
//        person.setId(2);
//        Person expectedResult = new Person ("agrasha", "agrasha@gmail.com",Date.valueOf("1996-09-08"), 2);
//        return new Object[][] { 
//                                {person, expectedResult}
//                              };
//    }
//
//    @Test(dataProvider = "testDeleteRecord_negativeDP",priority = 9)
//    private void testDeleteRecord_negative(Person person) {
//
//        try {
//
//            personService.delete(person, conn);
//            Assert.fail("Expected an exception.");
//            conn.rollback();
//        } catch (Exception e) {
//            Assert.assertEquals(e.getMessage(), "ID cannot be null");
//        }
//    }
//
//    @DataProvider
//    private Object[][] testDeleteRecord_negativeDP() {
//
//        Person person = new Person();
//        person.setId(0);
//        return new Object[][] { 
//                                {person}
//                              };
//    }
}
