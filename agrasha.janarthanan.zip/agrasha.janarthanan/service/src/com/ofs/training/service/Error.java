package com.ofs.training.service;


public enum Error{
    INVALID_ID(101, "Id cannot be null"),
    INVALID_STREET(201, "Street cannot be empty or null"),
    INVALID_CITY(202, "City cannot be empty or null"),
    INVALID_POSTALCODE(203, "PostalCode cannot be null"),
    SQL_EXCEPTION(301, "Invalid SQL Query");

    private final int errorCode;
    private final String errorDescription;

    private Error(int errorCode, String errorDescription) {
        this.errorCode = errorCode;
        this.errorDescription = errorDescription;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    @Override
    public String toString() {
        return "Code : " + errorCode + "Description : " + errorDescription;
    }
}
