package com.ofs.training.service.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AddressService {

    private void validate(Address address) {

        List<Error> errors = new ArrayList<>();

        if (isEmpty(address.getStreet())) {
            errors.add(Error.INVALID_STREET);
        };

        if (isEmpty(address.getCity())) {
            errors.add(Error.INVALID_CITY);
        };

        if (address.getPosatlCode() == 0) {
            errors.add(Error.INVALID_POSTALCODE);
        };

        if (errors.size() > 0) {
            throw new AppException(errors);
        }
    }

    private boolean isEmpty(String value) {
        return Objects.isNull(value) || "".equals(value);
    }

    private void validateId(long id, Connection conn) throws Exception {

        if (id == 0) {
            ArrayList<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_ID);
            throw new AppException(errors);
        }
    }

    private void validateValue(String searchValue) {
        if (searchValue == null) {
            ArrayList<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_INPUT);
            throw new AppException(errors);
        }
    }

    private void setValue(Address address, PreparedStatement statement) throws Exception {
        try {
            statement.setString(1, address.getStreet());
            statement.setString(2, address.getCity());
            statement.setInt   (3, address.getPosatlCode());
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }

    private void constructAddress(ResultSet result, Address address) throws Exception {
        try {
            address.setId        (result.getLong("id"));
            address.setStreet    (result.getString("street"));
            address.setCity      (result.getString("city"));
            address.setPostalCode(result.getInt("postal_code"));
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }

    public Address create(Address address, Connection conn) throws Exception {

        String insertQuery = new StringBuilder().append("INSERT INTO address (street, city, postal_code) ")
                                                .append("VALUES (?, ?, ?)                                ").toString();
        long generatedId = 0;

        try {
            validate(address);
            PreparedStatement statement = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
            setValue(address, statement);
            statement.executeUpdate();

            ResultSet rs = statement.getGeneratedKeys();
            if ((rs.next()) && (rs != null)) {
                generatedId = rs.getLong(1);
            }
            address.setId(generatedId);
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return address;
    }

    public Address update(Address address, Connection conn) throws Exception {

        String query = new StringBuilder().append("UPDATE address          ")
                                          .append("   SET street = ?       ")
                                          .append("       , city = ?       ")
                                          .append("       , postal_code = ?")
                                          .append(" WHERE id = ?           ").toString();

        try {
            validate(address);
            validateId(address.id, conn);
            PreparedStatement statement = conn.prepareStatement(query);
            setValue(address, statement);
            statement.setLong  (4, address.getId());
            statement.executeUpdate();
        } catch(SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return address;
    }

    public Address read(Address address, Connection conn) throws Exception {

        String query = new StringBuilder().append("SELECT id, street, city, postal_code ")
                                          .append("FROM address                         ")
                                          .append("WHERE id = ?                         ").toString();

        try {
            validate(address);
            validateId(address.id, conn);
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setLong(1, address.id);
            ResultSet result = statement.executeQuery();
            result.next();
            constructAddress(result, address);
        } catch(SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return address;
    }

    public ArrayList<Address> readAll(Connection conn) throws Exception {

        String query = new StringBuilder().append("SELECT id, street, city, postal_code ")
                                          .append("FROM address                         ").toString();
        ArrayList<Address> resultRecords = new ArrayList<>();

        try {
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                Address address = new Address();
                constructAddress(result, address);
                resultRecords.add(address);
            }
        } catch(SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return resultRecords;
    }

    public void delete(Address address, Connection conn) throws Exception {

        String query = new StringBuilder().append("DELETE FROM address ")
                                          .append("WHERE id = ?        ").toString();

        try {
            validateId(address.id,conn);
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setLong(1, address.id);
            statement.executeUpdate();
        } catch(SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }

    public List<Address> search(String[] fields, String searchValue, Connection conn) throws Exception {

        List<Address> result = new ArrayList<>();

        try {

            validateValue(searchValue);
            String query = "SELECT id, street, city, postal_code FROM address WHERE ";
            StringBuilder sb = new StringBuilder(query);

            for (String field : fields) {
                if (field == "postalCode") {
                    field = "postal_code";
                }
                sb.append(String.format("%s LIKE ? OR ", field));
            }
            query = sb.substring(0, sb.length() - 3);

            PreparedStatement statement = conn.prepareStatement(query);
            for (int i = 1; i <= fields.length; i++) {
                statement.setString(i, "%" + searchValue + "%");
            }

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Address address = new Address();
                constructAddress(resultSet, address);
                result.add(address);
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return result;
    }
}