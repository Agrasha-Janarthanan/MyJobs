package com.ofs.training.service;

public class Address {

    long id;
    private String street;
    private String city;
    private int postalCode;

    public Address(String street, String city, int postalCode) {

        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
    }

    public Address(long id, String street, String city, int postalCode) {

        this.id = id;
        this.street =street;
        this.city = city;
        this.postalCode = postalCode;
    }

    public Address() {
        // TODO Auto-generated constructor stub
    }

    public long getId() {
        return this.id;
    }

    public String getStreet() {
        return this.street;
    }

    public String getCity() {
        return this.city;
    }

    public int getPosatlCode() {
        return this.postalCode;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setPostalCode(int postalcode) {
        this.postalCode = postalcode;
    }

    @Override
    public String toString() {
        return "Address [id=" + id + ", street=" + street + ", city=" + city + ", postal_code=" + postalCode + "]";
    }
}
