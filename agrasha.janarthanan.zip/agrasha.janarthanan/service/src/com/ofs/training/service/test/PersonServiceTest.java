package com.ofs.training.service.test;

import java.sql.Connection;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.AppException;
import com.ofs.training.service.main.ConnectionManager;
import com.ofs.training.service.main.Error;
import com.ofs.training.service.main.Person;
import com.ofs.training.service.main.PersonService;

@Test
public class PersonServiceTest {

    PersonService personService;

    @BeforeTest
    private void initialize() {
        personService = new PersonService();
    }

    @Test(dataProvider = "testCreateRecord_positiveDP", priority = 1, groups = "create")
    private void testCreateRecord_positive(Person person, Person expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {
            Person actualResult = personService.create(person, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected exception for given input."
                        + person
                        + "Expected result is "
                        + expectedResult
                        + e.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider()
    private Object[][] testCreateRecord_positiveDP() {

        return new Object[][] { 
                                { new Person ("agi", "jana","agi@gmail.com", Date.valueOf("1996-08-08")
                                                   , new Address ("Mint street", "Chennai", 600345)),
                                  new Person (1, "agi", "jana","agi@gmail.com", Date.valueOf("1996-08-08")
                                               , new Address (1, "Mint street", "Chennai", 600345))
                                },
                                { new Person ("agrasha", "janarthanan", "agrasha@gmail.com",Date.valueOf("1996-09-08")
                                                       , new Address ("Car street", "Tiruvannamalai", 606601)),
                                  new Person (2, "agrasha", "janarthanan", "agrasha@gmail.com"
                                               , Date.valueOf("1996-09-08")
                                               , new Address (2, "Car street", "Tiruvannamalai", 606601))
                                }
        };
    }

    @Test(dataProvider = "testCreateRecord_negativeDP", priority = 2, groups = "create")
    private void testCreateRecord_negative(Person person, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {
            personService.create(person, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider()
    private Object[][] testCreateRecord_negativeDP() {

        ArrayList<Error> errorListOne = new ArrayList<>();
        errorListOne.add(Error.DUPLICATE_EMAIL);
        ArrayList<Error> errorListTwo = new ArrayList<>();
        errorListTwo.add(Error.INVALID_LASTNAME);
        ArrayList<Error> errorListThree = new ArrayList<>();
        errorListThree.add(Error.INVALID_FIRSTNAME);
        ArrayList<Error> errorListFour = new ArrayList<>();
        errorListFour.add(Error.INVALID_BIRTHDATE);
        ArrayList<Error> errorListFive = new ArrayList<>();
        errorListFive.add(Error.INVALID_EMAIL);
        ArrayList<Error> errorListSix = new ArrayList<>();
        errorListSix.add(Error.DUPLICATE_NAME);

        return new Object[][] { 
                                { new Person ("varshini", "jana pandu", "agrasha@gmail.com", Date.valueOf("1996-08-08")
                                                        , new Address ("Car street", "Tiruvannamalai", 606601)),
                                  new AppException(errorListOne)
                                },
                                { new Person ("oviya", "", "ers@gmail.com", Date.valueOf("1996-08-08")
                                                     , new Address ("Car street", "Tiruvannamalai", 606601)),
                                  new AppException(errorListTwo)
                                },
                                { new Person ("", "lalitha", "aaa@gmail.com", Date.valueOf("1996-08-08")
                                                , new Address ("Car street", "Tiruvannamalai", 606601)),
                                  new AppException(errorListThree)
                                },
                                {new Person ("harsha", "agi", "zxf@gmail.com", null
                                                     , new Address ("Car street", "Tiruvannamalai", 606601)),
                                 new AppException(errorListFour)
                                },
                                {new Person ("janarthanan", "lalitha", "", Date.valueOf("1996-08-08")
                                                          , new Address ("Car street", "Tiruvannamalai", 606601)),
                                 new AppException(errorListFive)
                                },
                                {new Person ("agrasha", "janarthanan", "abcd@gmail.com", Date.valueOf("1996-08-08")
                                                      , new Address ("Car street", "Tiruvannamalai", 606601)),
                                 new AppException(errorListSix)
                                }
                              };
    }

    @Test(dataProvider = "testUpdate_positiveDP", priority = 3, groups = "update")
    private void testUpdate_positive(Person person, Person expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {

            Person actualPerson = personService.update(person, conn);
            Assert.assertEquals(actualPerson.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected exception for given input"
                        + person
                        + "Expected result is "
                        + e.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        return new Object[][] { 
                                { new Person(1, "agi", "jana", "abc@gmail.com", Date.valueOf("1996-08-08")
                                              , new Address (1, "Mint street", "Chennai", 600345)),
                                  new Person(1, "agi", "jana", "abc@gmail.com", Date.valueOf("1996-08-08")
                                              , new Address (1, "Mint street", "Chennai", 600345))
                                }
                              };
    }

    @Test(dataProvider = "testUpdate_negativeDP", priority = 4, groups = "update")
    private void testUpdate_negative(Person person, AppException exceptionMessage) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {

            personService.update(person, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), exceptionMessage.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testUpdate_negativeDP() {

        Person person = new Person();
        person.setId(0);
        ArrayList<Error> errorList = new ArrayList<>();
        errorList.add(Error.INVALID_ID);
        return new Object[][] { 
                                {person, new AppException(errorList)}
                              };
    }

    @Test(dataProvider = "testRead_positiveDP", priority = 5, groups = "read")
    private void testRead_positive(Person person, boolean includeAddress, Person expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {
            Person actualResult = personService.read(person, includeAddress, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected exception for given input"
                        + person
                        + "Expected result is "
                        + expectedResult
                        + e.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {

        Person personOne = new Person(2, "agrasha", "janarthanan", "agrasha@gmail.com", Date.valueOf("1996-09-08")
                                       , new Address(2, "Car street", "Tiruvannamalai", 606601));
        Person expectedResult = new Person(2, "agrasha", "janarthanan", "agrasha@gmail.com", Date.valueOf("1996-09-08")
                                            , new Address(2, "Car street", "Tiruvannamalai", 606601));
        Person person = new Person(2, "agrasha", "janarthanan", "agrasha@gmail.com", Date.valueOf("1996-09-08"), null);
        Person result = new Person(2, "agrasha", "janarthanan", "agrasha@gmail.com", Date.valueOf("1996-09-08"), null);
        return new Object[][] {
                                {personOne, true, expectedResult},
                                {person, false, result}
                              };
    }

    @Test(dataProvider= "testRead_negativeDP", priority = 6, groups = "read")
    private void testRead_negative(Person person, boolean includeAddress
                                                , AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {
            personService.read(person, includeAddress, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        }  finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {

        Person person = new Person();
        person.setId(0);
        ArrayList<Error> errorList = new ArrayList<>();
        errorList.add(Error.INVALID_ID);
        return new Object[][] {
            {person, false, new AppException(errorList)}
        };
    }

    @Test(dataProvider = "testReadAllRecords_positiveDP", priority = 7, groups = "readAll")
    private void testReadAllRecords_positive(boolean includeAddress, List<Person> expectedResult) throws Exception {
        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {

            List<Person> actualResult = personService.readAll(includeAddress, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected exception "
                        + "Expected result is "
                        + expectedResult
                        + e.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testReadAllRecords_positiveDP() {
        List<Object> result = new ArrayList<>();
        result.add(new Person (1, "agi", "jana","abc@gmail.com", Date.valueOf("1996-08-08")
                                , new Address (1, "Mint street", "Chennai", 600345)));
        result.add(new Person (2, "agrasha", "janarthanan", "agrasha@gmail.com",Date.valueOf("1996-09-08")
                                , new Address (2, "Car street", "Tiruvannamalai", 606601)));
        List<Object> expectedResult = new ArrayList<>();
        expectedResult.add(new Person (1, "agi", "jana","abc@gmail.com", Date.valueOf("1996-08-08"), null));
        expectedResult.add(new Person (2, "agrasha", "janarthanan", "agrasha@gmail.com"
                                        ,Date.valueOf("1996-09-08"), null));
        return new Object[][] { 
                                {true, result},
                                {false, expectedResult}
                              };
    }

    @Test(dataProvider = "testDeleteRecord_positiveDP", priority = 8, groups = "delete")
    private void testDeleteRecord_positive(Person person) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {
            personService.delete(person, conn);
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected exception for given input" 
                        + person
                        + e.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testDeleteRecord_positiveDP() {

        Person person = new Person ("agrasha", "janarthanan", "agrasha@gmail.com", Date.valueOf("1996-09-08")
                                             , new Address(2, "Car street", "Tiruvannamalai", 606601));
        person.setId(2);
        return new Object[][] { 
                                {person}
                              };
    }

    @Test(dataProvider = "testDeleteRecord_negativeDP",priority = 9, groups = "delete")
    private void testDeleteRecord_negative(Person person, AppException expectedException) throws Exception {
        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection();

        try {
            personService.delete(person, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testDeleteRecord_negativeDP() {

        Person person = new Person();
        person.setId(0);
        ArrayList<Error> errorList = new ArrayList<>();
        errorList.add(Error.INVALID_ID);
        return new Object[][] { 
                                {person, new AppException(errorList)}
                              };
    }
}
