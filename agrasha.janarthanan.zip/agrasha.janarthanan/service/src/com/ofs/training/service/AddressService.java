package com.ofs.training.service;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AddressService {

    private void validate(Address address) {

        List<Error> errors = new ArrayList<Error>();
        int exceptionCount = 0;

        if (address.getStreet() == null || address.getStreet() == "") {
            errors.add(Error.INVALID_STREET);
            exceptionCount++;
        };

        if (address.getCity() == null || address.getCity() == "") {
            errors.add(Error.INVALID_CITY);
            exceptionCount++;
        };

        if (address.getPosatlCode() == 0) {
            errors.add(Error.INVALID_POSTALCODE);
            exceptionCount++;
        };

        if (exceptionCount > 0) {
            throw new AppException(Error.SQL_EXCEPTION);
        }
    }

    private void validateId(long id, Connection conn) throws Exception {

        String sb = new StringBuilder("SELECT id FROM address").toString();
        PreparedStatement stmt = conn.prepareStatement(sb.toString());
        ResultSet rs = stmt.executeQuery(sb.toString());
        while (rs.next()) {
            if (rs.getLong("id") == id) {
                throw new AppException(Error.INVALID_ID);
            }
        }
    }

    public Address create(Address address, Connection conn) throws Exception {

        String query = new StringBuilder("INSERT INTO address (street, city, postal_code)").append("VALUES (?, ?, ?)")
                                                                                           .toString();
        long generatedId = 0;

        try {
            validate(address);
            PreparedStatement statement = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, address.getStreet());
            statement.setString(2, address.getCity());
            statement.setInt   (3, address.getPosatlCode());
            statement.executeUpdate();

            ResultSet rs = statement.getGeneratedKeys();
            if ((rs.next()) && (rs != null)) {
                generatedId = rs.getLong("id");
            }
            address.setId(generatedId);
        } catch (Exception e) {
            throw new AppException(Error.SQL_EXCEPTION);
        }
        return address;
    }

    public Address update(Address address, Connection conn) throws Exception {

        String query = new StringBuilder("UPDATE address SET street = ?").append("city = ?")
                                                                         .append("postal_code = ?")
                                                                         .append("WHERE id = ?")
                                                                         .toString();

        try {
            validate(address);
            validateId(address.id, conn);
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, address.getStreet());
            statement.setString(2, address.getCity());
            statement.setInt   (3, address.getPosatlCode());
            statement.setLong  (4, address.id);
            statement.executeUpdate();
        } catch(Exception e) {
            throw new AppException(Error.SQL_EXCEPTION);
        }
        return address;
    }

    public Address read(Address address, Connection conn) {

        String query = new StringBuilder("SELECT id, street, city, postal_code FROM address WHERE id = ?").toString();

        try {
            validate(address);
            validateId(address.id, conn);
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setLong(1, address.id);
            ResultSet result = statement.executeQuery();
            result.next();
            address.setId        (result.getLong("id"));
            address.setStreet    (result.getString("street"));
            address.setCity      (result.getString("city"));
            address.setPostalCode(result.getInt("postal_code"));
        } catch (Exception e) {
            throw new AppException(Error.SQL_EXCEPTION);
        }
        return address;
    }

    public List<Address> readAll(Connection conn) throws Exception {

        String query = new StringBuilder("SELECT id, street, city, postal_code FROM address").toString();
        List<Address> resultRecords = new ArrayList<>();

        try {
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                Address address = new Address();
                address.setId        (result.getLong("id"));
                address.setStreet    (result.getString("street"));
                address.setCity      (result.getString("city"));
                address.setPostalCode(result.getInt("postal_code"));
                resultRecords.add(address);
            }
        } catch(Exception e) {
            throw new AppException(Error.SQL_EXCEPTION);
        }
        return resultRecords;
    }

    public Address delete(Address address, Connection conn) throws SQLException {

        String query = new StringBuilder("DELETE FROM address WHERE id = ?").toString();

        try {
            validateId(address.id,conn);
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setLong(1, address.id);
            statement.executeUpdate();
        } catch (Exception e) {
            throw new AppException(Error.SQL_EXCEPTION);
        }
        return address;
    }
}
