package com.ofs.training.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AddressService {

    private void validate(Address address) {

        List<Error> errors = new ArrayList<Error>();
        int exceptionCount = 0;

        if (address.getStreet() == null || address.getStreet() == "") {
            errors.add(Error.INVALID_STREET);
            exceptionCount++;
        };

        if (address.getCity() == null || address.getCity() == "") {
            errors.add(Error.INVALID_CITY);
            exceptionCount++;
        };

        if (address.getPosatlCode() == 0) {
            errors.add(Error.INVALID_POSTALCODE);
            exceptionCount++;
        };

        if (exceptionCount > 0) {
            throw new AppException(errors);
        }
    }

    private void validateId(long id, Connection conn) throws AppException {

        if (id == 0) {
            throw new AppException(Error.INVALID_ID);
        }
    }

    private void setValue(Address address, PreparedStatement statement) throws AppException {
        try {
            statement.setString(1, address.getStreet());
            statement.setString(2, address.getCity());
            statement.setInt   (3, address.getPosatlCode());
        } catch (Exception e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
    }

    private void constructAddress(ResultSet result, Address address) throws AppException {
        try {
            address.setId        (result.getLong("id"));
            address.setStreet    (result.getString("street"));
            address.setCity      (result.getString("city"));
            address.setPostalCode(result.getInt("postal_code"));
        } catch (Exception e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
    }

    public Address create(Address address, Connection conn) throws AppException {

        String query = new StringBuilder().append("INSERT INTO address (street, city, postal_code)")
                                          .append("VALUES (?, ?, ?)                               ")
                                          .toString();
        long generatedId = 0;

        try {
            validate(address);
            PreparedStatement statement = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            setValue(address, statement);
            statement.executeUpdate();

            ResultSet rs = statement.getGeneratedKeys();
            if ((rs.next()) && (rs != null)) {
                generatedId = rs.getLong(1);
            }
            address.setId(generatedId);
        } catch (AppException e) {
            throw e;
        } catch (Exception e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
        return address;
    }

    public Address update(Address address, Connection conn) throws AppException {

        String query = new StringBuilder().append("UPDATE address SET street = ?, city = ?, postal_code = ? WHERE id = ?").toString();

        try {
            validate(address);
            validateId(address.id, conn);
            PreparedStatement statement = conn.prepareStatement(query);
            setValue(address, statement);
            statement.setLong  (4, address.getId());
            statement.executeUpdate();
        } catch(AppException e) {
            throw e;
        } catch(Exception e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
        return address;
    }

    public Address read(Address address, Connection conn) throws AppException {

        String query = new StringBuilder().append("SELECT id, street, city, postal_code ")
                                          .append("FROM address                         ")
                                          .append("WHERE id = ?                         ")
                                          .toString();

        try {
            validate(address);
            validateId(address.id, conn);
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setLong(1, address.id);
            ResultSet result = statement.executeQuery();
            result.next();
            constructAddress(result, address);
        } catch (AppException e) {
            throw e;
        } catch(Exception e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
        return address;
    }

    public List<Address> readAll(Connection conn) throws AppException {

        String query = new StringBuilder().append("SELECT id, street, city, postal_code ")
                                          .append("FROM address                         ")
                                          .toString();
        List<Address> resultRecords = new ArrayList<>();

        if (conn == null) {
            throw new AppException(Error.DATABASE_ERROR);
        }

        try {
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                Address address = new Address();
                constructAddress(result, address);
                resultRecords.add(address);
            }
        } catch(AppException e) {
            throw e;
        } catch(Exception e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
        return resultRecords;
    }

    public void delete(Address address, Connection conn) throws AppException {

        String query = new StringBuilder().append("DELETE FROM address ")
                                          .append("WHERE id = ?        ")
                                          .toString();

        try {
            validateId(address.id,conn);
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setLong(1, address.id);
            statement.executeUpdate();
        } catch (AppException e) {
            throw e;
        } catch(Exception e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
    }

    private List<Address> searchByStreet(String street, Connection conn) throws AppException {

        List<Address> result = new ArrayList<>();
        try {
            if (street == null) {
                throw new AppException(Error.INVALID_STREET);
            }
            String value = "%" + street + "%";
            String query = new StringBuilder().append("SELECT id, street, city, postal_code")
                                              .append(" FROM address                       ")
                                              .append(" WHERE street LIKE ?                ").toString();
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, value);
            ResultSet resultRecord = statement.executeQuery();
            while (resultRecord.next()) {
                Address address = new Address();
                constructAddress(resultRecord, address);
                result.add(address);
            }
        } catch(AppException e) {
            throw e;
        } catch (Exception e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
        return result;
    }

    private List<Address> searchByCity(String city, Connection conn) throws AppException {
        List<Address> result = new ArrayList<>();
        try {
            if (city == null) {
                throw new AppException(Error.INVALID_CITY);
            }
            String value = "%" + city + "%";
            String query = new StringBuilder().append("SELECT id, street, city, postal_code")
                                              .append(" FROM address                       ")
                                              .append(" WHERE city LIKE ?                  ").toString();
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, value);
            ResultSet resultRecord = statement.executeQuery();
            while (resultRecord.next()) {
                Address address = new Address();
                constructAddress(resultRecord, address);
                result.add(address);
            }
        } catch(AppException e) {
            throw e;
        } catch (Exception e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
        return result;
    }
    private List<Address> serchByPostalCode(int postalCode, Connection conn) throws AppException {
        List<Address> result = new ArrayList<>();
        try {
            if (postalCode == 0) {
                throw new AppException(Error.INVALID_POSTALCODE);
            }
            String value = "%" + postalCode + "%";
            String query = new StringBuilder().append("SELECT id, street, city, postal_code")
                                              .append(" FROM address                       ")
                                              .append(" WHERE postal_code LIKE ?           ").toString();
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, value);
            ResultSet resultRecord = statement.executeQuery();
            while (resultRecord.next()) {
                Address address = new Address();
                constructAddress(resultRecord, address);
                result.add(address);
            }
        } catch(AppException e) {
            throw e;
        } catch (Exception e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
        return result;
    }

    public List<Address> search(Object value, Connection conn) throws AppException {

        List<Address> result = new ArrayList<>();
        try {
            if (value == null) {
                throw new AppException(Error.INVALID_INPUT);
            }
            if (value instanceof Integer) {
                List<Address> resultPostalRecords = serchByPostalCode((int) value, conn);
                result.addAll(resultPostalRecords);
            }
            if (value instanceof String) {
                List<Address> resultStreetRecords = searchByStreet((String) value, conn);
                List<Address> resultCityRecords = searchByCity((String) value, conn);
                result.addAll(resultStreetRecords);
                result.addAll(resultCityRecords);
            }
        } catch (AppException e) {
            throw e;
        } catch (Exception e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
        return result;
    }
}