package com.ofs.training.service;

import java.util.ArrayList;
import java.util.List;

public class AppException extends RuntimeException{

    List<Error> errorCodes = new ArrayList<>();
    Error errorCode;

    public AppException(List<Error> errorCodes) {
         this.errorCodes = errorCodes;
    }

    public AppException(Exception e) {
        // TODO Auto-generated constructor stub
    }

    public AppException(Error error) {
        this.errorCode = error;
    }
}
