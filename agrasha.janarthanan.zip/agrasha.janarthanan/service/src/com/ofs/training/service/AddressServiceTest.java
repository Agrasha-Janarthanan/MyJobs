package com.ofs.training.service;

import java.sql.Connection;
import java.sql.SQLException;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class AddressServiceTest {

    AddressService addressService;
    ConnectionManager txn = new ConnectionManager();
    Connection conn = txn.openConnection("jdbc:mysql://pc1620:3306/agrasha_janarthanan?useSSL=false&user=agrasha_janarthanan&password=demo");

    @BeforeClass
    private void initialize() {
        addressService = new AddressService();
    }

//    positive test case to insert a record
    @Test(dataProvider = "testCreate_positiveDP", priority = 1)
    private void testCreate_positive(Address address, Address expectedResult) throws SQLException {

        try{

            Address actualResult = addressService.create(address, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
                Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() {

        Address address = new Address ("Mint street", "Madras", 600235);
        Address expectedResult = new Address (1, "Mint street", "Madras", 600235);
        Address nextAddress = new Address ("Car street", "Tiruvannamalai", 606601);
        Address expectedOutput = new Address (2, "Car street", "Tiruvannamalai", 606601);
        return new Object[][] {
            {address, expectedResult},
            {nextAddress, expectedOutput}
        };
    }

//    negative test case to insert a record
    @Test(dataProvider = "testCreate_negativeDP", priority = 2)
    private void testCreate_negative(Address address, AppException expectedException) {

        try{

            addressService.create(address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e, expectedException);
        }
    }

    @DataProvider
    private Object[][] testCreate_negativeDP() {

        return new Object[][] {
            {new Address ("", "Madras", 606601), new AppException(Error.INVALID_STREET)},
            {new Address ("Mint street", "", 600028), new AppException(Error.INVALID_CITY)},
            {new Address ("Mint street", "Madras", 0), new AppException(Error.INVALID_POSTALCODE)}
        };
    }

    @AfterClass
    private void closeConnection() {
        txn.closeConnection();
    }
}
