package com.ofs.training.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class AddressServiceTest {

    AddressService addressService;
    String connectionString = new StringBuilder().append("jdbc:mysql://pc1620:3306/agrasha_janarthanan?useSSL=false")
                                                 .append("&user=agrasha_janarthanan&password=demo").toString();

    @BeforeClass
    private void setUp() {
        addressService = new AddressService();
    }

    @Test(dataProvider = "testCreate_positiveDP", priority = 1)
    private void testCreate_positive(Address address, Address expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try{
            Address actualResult = addressService.create(address, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
                Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e.toString());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() {

        Address address = new Address ("Mint street", "Madras", 600235);
        Address expectedResult = new Address (1, "Mint street", "Madras", 600235);
        Address nextAddress = new Address ("Car street", "Tiruvannamalai", 606601);
        Address expectedOutput = new Address (2, "Car street", "Tiruvannamalai", 606601);
        return new Object[][] {
            {address, expectedResult},
            {nextAddress, expectedOutput}
        };
    }

    @Test(dataProvider = "testCreate_negativeDP", priority = 2)
    private void testCreate_negative(Address address, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try{

            addressService.create(address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testCreate_negativeDP() {

        return new Object[][] {
            {new Address ("", "Madras", 606601), new AppException(Error.INVALID_STREET)},
            {new Address ("Mint street", "", 600028), new AppException(Error.INVALID_CITY)},
            {new Address ("Mint street", "Madras", 0), new AppException(Error.INVALID_POSTALCODE)}
        };
    }

    @Test(dataProvider = "testUpdate_positiveDP", priority = 3)
    private void testUpdate_positive(Address address, Address expectedResult) throws SQLException {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try {
            Address actualResult = addressService.update(address, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e.getErrorCode());
        } finally {
            conn.close();
        }
    }
    
    @DataProvider
    private Object[][] testUpdate_positiveDP() {
        
        Address address = new Address(1, "Mint street", "Chennai", 600235);
        Address expectedResult = new Address(1, "Mint street", "Chennai", 600235);
        return new Object[][] {
            { address, expectedResult},
        };
    }
    
    @Test(dataProvider = "testUpdate_negativeDP", priority = 4)
    private void testUpdate_negative(Address address, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try{
            addressService.update(address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            conn.close();
        }
    }
    
    @DataProvider
    private Object[][] testUpdate_negativeDP() {
        
        return new Object[][] {
            {new Address (0, "Mint street", "Mumbai", 606601), new AppException(Error.INVALID_ID)},
        };
    }

    @Test(dataProvider = "testRead_positiveDP", priority = 5)
    private void testRead_positive(Address address, Address expectedResult) throws SQLException {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try {
            Address actualResult = addressService.read(address, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e.getErrorCode());
        } finally {
            conn.close();
        }
    }
    
    @DataProvider
    private Object[][] testRead_positiveDP() {
        
        Address address = new Address(1, "Mint street", "Chennai", 600235);
        Address expectedResult = new Address(1, "Mint street", "Chennai", 600235);
        return new Object[][] {
            { address, expectedResult},
        };
    }
    
    @Test(dataProvider = "testRead_negativeDP", priority = 6)
    private void testRead_negative(Address address, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try{
            
            addressService.update(address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            conn.close();
        }
    }
    
    @DataProvider
    private Object[][] testRead_negativeDP() {
        
        return new Object[][] {
            {new Address (0, "Mint street", "Chennai", 606601), new AppException(Error.INVALID_ID)},
        };
    }

    @Test(dataProvider = "testReadAll_positiveDP", priority = 7)
    private void testReadAll_positive(List<Address> expectedResult) throws SQLException {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try {
            List<Address> actualResult = addressService.readAll(conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
                Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e.getErrorCode());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {

        List<Address> expectedResult = new ArrayList<>();
        expectedResult.add(new Address(1, "Mint street", "Chennai", 600235));
        expectedResult.add(new Address(2, "Car street", "Tiruvannamalai", 606601));
        return new Object[][] {
                                {expectedResult},
                              };
    }

    @Test(dataProvider = "testReadAll_negativeDP", priority = 8)
    private void testReadAll_negative(AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try{
            addressService.readAll(null);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCode(), expectedException.getErrorCode());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testReadAll_negativeDP() {

        return new Object[][] {
            { new AppException(Error.DATABASE_ERROR)}
        };
    }

    @Test(dataProvider = "testSearch_positiveDP", priority = 9)
    private void testSearch_positive(Object value, List<Address> expectedResult) throws SQLException {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try {
            List<Address> actualResult = addressService.search(value, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e.getErrorCode());
        } finally {
            conn.close();
        }
    }
    
    @DataProvider
    private Object[][] testSearch_positiveDP() {

        Object value = "Mi";
        List<Address> expectedResult = new ArrayList<>();
        expectedResult.add(new Address(1, "Mint street", "Chennai", 600235));
        Object city = "Che"; 
        List<Address> expectedOutput = new ArrayList<>();
        expectedOutput.add(new Address(1, "Mint street", "Chennai", 600235));
        Object postalCode = 606;
        List<Address> expectedRecord = new ArrayList<>();
        expectedRecord.add(new Address(2, "Car street", "Tiruvannamalai", 606601));
        return new Object[][] {
            { value, expectedResult},
            { city, expectedOutput},
            { postalCode, expectedRecord}
        };
    }
    
    @Test(dataProvider = "testSearch_negativeDP", priority = 10)
    private void testSearch_negative(Object value, AppException expectedException) throws SQLException {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try{
            addressService.search(value, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            conn.close();
        }
    }
    
    @DataProvider
    private Object[][] testSearch_negativeDP() {

        return new Object[][] {
            { null, new AppException(Error.INVALID_STREET)},
            { 0, new AppException(Error.INVALID_POSTALCODE)}
        };
    }

    @Test(dataProvider = "testDelete_positiveDP", priority = 11)
    private void testDelete_positive(Address address) throws SQLException {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try {
            addressService.delete(address, conn);
            conn.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + e.getErrorCode());
        } finally {
            conn.close();
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {
        
        Address address = new Address(1, "Mint street", "Chennai", 600235);
        return new Object[][] {
            {address}
        };
    }

    @Test(dataProvider = "testDelete_negativeDP", priority = 12)
    private void testDelete_negative(Address address, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection conn = txn.openConnection(connectionString);

        try{
            addressService.delete(address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            conn.close();
        }
    }
    
    @DataProvider
    private Object[][] testDelete_negativeDP() {
        
        return new Object[][] {
            {new Address (0, "Mint street", "Mumbai", 606601), new AppException(Error.INVALID_ID)},
        };
    }
}
