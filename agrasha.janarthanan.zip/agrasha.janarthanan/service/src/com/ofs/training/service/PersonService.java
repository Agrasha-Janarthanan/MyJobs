package com.ofs.training.service;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PersonService {

    AddressService addressService = new AddressService();

    private void validate(Person person, Connection conn) throws Exception{

        List<Error> errors = new ArrayList<Error>();
        int exceptionCount = 0;

        if (person.firstName == null || person.firstName == "") {
            errors.add(Error.INVALID_FIRSTNAME);
            exceptionCount++;
        }

        if (person.lastName == null || person.lastName == "") {
            errors.add(Error.INVALID_LASTNAME);
            exceptionCount++;
        }

        if (person.email == null || person.email == "") {
            errors.add(Error.INVALID_EMAIL);
            exceptionCount++;
        }

        if (person.birthDate == null) {
            errors.add(Error.INVALID_BIRTHDATE);
            exceptionCount++;
        }

        try {
            validateName(person, conn);
        } catch (AppException e) {
            errors.add(e.getErrorCode());
            exceptionCount++;
        }

        try {
            validateEmail(person, conn);
        } catch (AppException e) {
            errors.add(e.getErrorCode());
            exceptionCount++;
        }

        if (exceptionCount > 0) {
            throw new AppException(errors);
        }
    }

    private void validateName(Person person, Connection conn) throws Exception{
        try {
            String query = "SELECT COUNT(id) FROM person WHERE first_name = ? AND last_name = ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            ResultSet executeQuery = statement.executeQuery();
            executeQuery.next();
            int count = executeQuery.getInt(1);
            if (count > 0) {
                throw new AppException(Error.DUPLICATE_NAME);
            }
        } catch (SQLException exception) {
             throw new AppException(Error.DATABASE_ERROR);
        } catch (AppException exception) {
            throw exception;
       }
    }

    private void validateEmail(Person person, Connection conn) throws Exception {

        try {
            String query = "SELECT COUNT(id) FROM person WHERE email = ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, person.getEmail());
            ResultSet executeQuery = statement.executeQuery();
            executeQuery.next();
            int count = executeQuery.getInt(1);
            if (count > 0) {
                throw new AppException(Error.DUPLICATE_EMAIL);
            }
        } catch (AppException e) {
             throw e;
        }catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
    }

    private void validateId(long id, Connection conn) throws Exception {
        
        if (id == 0) {
            throw new AppException(Error.INVALID_ID);
        }
    }

    private void constructPerson(Person person, ResultSet result) throws Exception {

        try {
             person.setId         (result.getLong("id"));
             person.setFirstName  (result.getString("firstName"));
             person.setLastName   (result.getString("lastName"));
             person.setEmail      (result.getString("email"));
             person.setBirthDate  (result.getDate("birth_date"));
        } catch (AppException e) {
            throw e;
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
    }


//    private void setValue(Person person, PreparedStatement statement) throws AppException {
//
//        try {
//            statement.setString(1, person.getFirstName());
//            statement.setString(2, person.getLastName());
//            statement.setString(3, person.getEmail());
//            statement.setDate  (4, person.getBirthDate());
//        } catch (Exception e) {
//            throw new AppException(Error.SQL_EXCEPTION);
//        }
//    }

    public List<Person> setValue(ResultSet resultSet, Connection conn) throws Exception {

        List<Person> resultRecord = new ArrayList<>();
        try {
            while (resultSet.next()) {
                Person person = new Person();
                constructPerson(person, resultSet);
                resultRecord.add(person);
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR);
        } catch (AppException e) {
            throw e;
        }
       return resultRecord;
    }

    public Person create(Person person, Connection conn) throws Exception {

        long generatedKey = 0;

        String insertQuery = new StringBuilder().append("INSERT INTO person (first_name   ")
                                                .append("                   , last_name   ")
                                                .append("                   , email       ")
                                                .append("                   , birth_date  ")
                                                .append("                   , address_id) ")
                                                .append("VALUES (?, ?, ?, ?, ?)           ")
                                                .toString();

        try {
            validate(person, conn);

            PreparedStatement statement = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
            Address address = addressService.create(person.getAddress(), conn);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setString(3, person.getEmail());
            statement.setDate  (4, person.getBirthDate());
            person.setAddress  (address);
            statement.setLong  (5, person.address.id);
            statement.executeUpdate();

            ResultSet generatedKeys = statement.getGeneratedKeys();
            if ((generatedKeys != null) && (generatedKeys.next())) {
                generatedKey = generatedKeys.getLong(1);
            }
            person.setId(generatedKey);
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR);
        } catch (AppException e) {
            throw e;
        }
        return person; 
    }

    public Person update(Person person, Connection conn) throws Exception {

        String query = new StringBuilder().append("UPDATE person SET first_name = ?  ")
                                          .append("                  , last_name = ? ")
                                          .append("                  , email = ?     ")
                                          .append("                  , birth_date = ?")
                                          .append("                  , address_id = ?")
                                          .append(" WHERE id = ?                     ").toString();

        try {
            validateId(person.id, conn);

            PreparedStatement statement = conn.prepareStatement(query);
            Address address = addressService.update(person.getAddress(), conn);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setString(3, person.getEmail());
            statement.setDate  (4, person.getBirthDate());
            person.setAddress  (address);
            statement.setLong  (5, person.address.getId());
            statement.setLong  (6, person.id);
            statement.executeUpdate();
        } catch (AppException e) {
            throw e;
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR);
        } 
        return person;
    }


    public Person read(Person person, boolean includeAddress, Connection conn) throws Exception {

        String readQuery = new StringBuilder().append("SELECT id            ")
                                              .append("       , first_name  ")
                                              .append("       , last_name   ")
                                              .append("       , email       ")
                                              .append("       , birth_date  ")
                                              .append("       , created_date")
                                              .append("       , address_id  ")
                                              .append("  FROM person        ")
                                              .append("  WHERE id = ?       ").toString();

        try {
            validateId(person.id, conn);
            if (includeAddress) {

                 PreparedStatement statement = conn.prepareStatement(readQuery);
                 statement.setLong(1, person.id);
                 ResultSet result = statement.executeQuery();
                 result.next();
                 constructPerson(person, result);
                 Address address = addressService.read(person.getAddress(), conn);
                 person.setAddress    (address);
            } else {

                PreparedStatement statement = conn.prepareStatement(readQuery);
                statement.setLong(1, person.id);
                ResultSet result = statement.executeQuery();
                result.next();
                constructPerson(person, result);
            }
        } catch (AppException e) {
            throw e;
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
        return person;
    }


    public List<Person> readAll(boolean includeAddress, Connection conn) throws Exception {

        String query = new StringBuilder().append("SELECT id, name, email, birth_date, created_date, address_id FROM person")
                .toString();
        List<Person> resultRecord = new ArrayList<>();

        try {

            if (includeAddress) {

                List<Address> address = addressService.readAll(conn);
                PreparedStatement statement = conn.prepareStatement(query);
                ResultSet result = statement.executeQuery();
                for (Address myAddress : address) {
                    Person person = new Person();
                    person.setAddress(myAddress);
                }
                resultRecord = setValue(result, conn);
            } else {

                PreparedStatement statement = conn.prepareStatement(query);
                ResultSet result = statement.executeQuery();
                resultRecord = setValue(result, conn);
            }
        } catch (AppException e) {
            throw e;
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
        return resultRecord;
    }

    public void delete(Person person, Connection conn) throws Exception {

        String deleteQuery = new StringBuilder().append("DELETE FROM person ")
                                                .append("WHERE id = ?       ")
                                                .toString();

        try {
            validateId(person.id,conn);
            PreparedStatement statement = conn.prepareStatement(deleteQuery.toString());
            addressService.delete(person.getAddress(), conn);
            statement.setLong(1, person.id);
            statement.executeUpdate();
        } catch (AppException e) {
            throw e;
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR);
        }
    }
}
