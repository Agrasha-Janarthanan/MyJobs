package com.ofs.training.basics;

// class ObjectEqualityDemo {
public class ObjectEqualityDemo {

    // static void execute() {
    public static void main(String[] args) {

        String firstName = new String("Agrasha");
        String lastName = new String("Agrasha");

        // ObjectEqualityDemo object = compareNames(firstName, lastName);
        System.out.println(firstName.equals(lastName));

        // Console console = getConsole()...
        // console.print(object);
        // console.print(firstName == lastName);
        System.out.println(firstName == lastName);
    }
}
