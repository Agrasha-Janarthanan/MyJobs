package com.ofs.training.basics;

public class Rectangle {

    public static int width;
    public static int height;

    public int area(int length, int breadth) {
        int area = length * breadth;
        return area;
    }

    public static void main(String[] args) {

        Rectangle myRect = new Rectangle();
        Rectangle.width = 40;
        Rectangle.height = 50;

        System.out.println("myRect's area is " + myRect.area(Rectangle.width,Rectangle.height));
    }
}
