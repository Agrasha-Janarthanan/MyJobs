package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class DisplayResultTest {

    private DisplayResult result;

    @BeforeClass
    private void initialize() {

        result = new DisplayResult();
    }

    @Test(dataProvider = "testGetReturnType_positiveDP")
    private void testGetReturnType_positive(Object object, String expectedResult) {

        try {

            String actualResult = result.getReturnType(object);
            Assert.assertEquals(actualResult, expectedResult, "Given Input" + object);
        } catch (Exception e) {

            Assert.fail("Unexpected result for input"
                        + object
                        + "Expected result"
                        + expectedResult
                        + e
                       );
        }
    }

    @Test
    private void testGetReturnType_negative() {

        Object object = null;
        try {

            result.getReturnType(object);
            Assert.fail("Exception is expected");
        } catch (Exception e) {

            Assert.assertEquals(e.getMessage(), "The input expression is invalid");
        }
    }

    @DataProvider
    private Object[][] testGetReturnType_positiveDP() {
        return new Object[][] {
                                { 100 / 24 , "int" },
                                { 100.01 / 2.01 , "double"},
                                { 'Z' / 2 , "int"},
                                { 10.5 / 0.5 , "double"},
                                { 12.4 % 5.5 , "double"},
                                { 100 % 56 , "int"},
                              };
    }

    @AfterClass
    private void afterClass() {
    }
}
