package com.ofs.training.basics;

// class EqualityDemo {
public class EqualityDemo {

    //static void execute() {
    public static void main(String[] args) {

        // String firstName = "Agrasha";
        String firstName = new String("Agrasha");

        // String lastName = "Janarthanan";
        String lastName = new String("Agrasha");

        // EqualityDemo myDemo = checkEquality(firstName, lastName);
        System.out.println(firstName.equals(lastName));

        // Console console = getConsole()...
        // console.print(firstName == lastName);
        System.out.println(firstName == lastName);
    }
}
