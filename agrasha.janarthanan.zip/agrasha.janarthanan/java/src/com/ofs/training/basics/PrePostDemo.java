package com.ofs.training.basics;

public class PrePostDemo {

    public static void main(String[] args){

        int i = 3;
        i++;

        System.out.println(i);
        ++i;

        System.out.println(i);
        System.out.println(++i);
        System.out.println(i++);
        System.out.println(i);
    }
}

// OUTPUT:
// 4
// 5
// 6
// 6
// 7
// since the post increment is used,the value of i is 
// printed and the incremented which is the reason to
// print 6 twice