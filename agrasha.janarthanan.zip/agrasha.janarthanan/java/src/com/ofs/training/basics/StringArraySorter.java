package com.ofs.training.basics;

import java.util.Arrays;

//class StringArraySorter {
public class StringArraySorter {

    private static final String ERR_STRING_IS_EMPTY = "The Input String is empty";
    public String[] stringSort(String[] input) {

        if (input == null) {
            throw new RuntimeException(ERR_STRING_IS_EMPTY);
        }

        // ArraySorter sortedCities = sortIgnoreCase(Cities);
        Arrays.sort(input, String.CASE_INSENSITIVE_ORDER);
        return input;
    }

    public String[] stringUpperCaseConvert(String[] sortedArray) {

        if (sortedArray == null) {
            throw new RuntimeException(ERR_STRING_IS_EMPTY);
        }

        // ArraySorter evenIndexedString = evenIndexedString(Cities);
        // ArraySorter upperCaseString = toUpperCase(evenIndexedString);
        // console.print(upperCaseString);
        for (int position = 0; position < sortedArray.length ; position += 2) {
            sortedArray[position] = (sortedArray[position].toUpperCase());
        }
        return sortedArray;
    }

    // static void execute() {
    public static void main(String[] args) {

        String[] cities = { "Madurai",
                            "Thanjavur",
                            "TRICHY",
                            "Karur",
                            "Erode",
                            "trichy",
                            "Salem" };
        StringArraySorter arraySorter = new StringArraySorter();
        String[] sortedArray = arraySorter.stringSort(cities);

        for (String string : sortedArray) {
            System.out.println(string);
        }

        String[] convertedArray = arraySorter.stringUpperCaseConvert(sortedArray);

        for (String string : convertedArray) {
            System.out.println(string);
        }
    }
}
