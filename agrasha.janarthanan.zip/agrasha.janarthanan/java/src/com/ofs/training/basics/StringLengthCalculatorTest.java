package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class StringLengthCalculatorTest {

    StringLengthCalculator demo = new StringLengthCalculator();

    @BeforeClass
    private void init() {
        demo = new StringLengthCalculator();
    }

    @Test(dataProvider = "testStringOperation_positiveDP")
    private void testStringOperation_positive(String input,String expectedResult) {

        try {

            String actualResult = demo.stringOperation(input);
            Assert.assertEquals(expectedResult, actualResult, "Given Input " + input);
        } catch(Exception e) {

            Assert.fail("Unexpected exception for input "
                        + input
                        + ". Expected result is "
                        + expectedResult
                        + e);
       }
    }

    @Test(dataProvider = "testStringLength_positiveDP")
    private void testStringLength_positive(String input,int expectedOutput) {

        try {

            int actualOutput = demo.stringLength(input);
            Assert.assertEquals(expectedOutput, actualOutput, "Given Input " + input);
        } catch(Exception e) {

            Assert.fail("Unexpected exception for input "
                        + input
                        + ". Expected result is "
                        + expectedOutput
                        + e);
        }
    }

    @Test
    private void testStringOperation_negative() {

        String input = "";

        try {

            demo.stringOperation(input);
            Assert.fail("Exception is expected");
        } catch (Exception e) {

            Assert.assertEquals(e.getMessage(), "Invalid Input string");
        }
    }

    @Test
    private void testStringLength_negative() {

        String input = "";

        try {

            demo.stringLength(input);
            Assert.fail("Exception is expected");
        } catch (Exception e) {

            Assert.assertEquals(e.getMessage(), "Invalid Input string");
        }
    }

    @DataProvider
    private Object[][] testStringOperation_positiveDP() {
        return new String[][] {
                                { "This is a Java Program", " Ja"},
                                { "Substring operation is used", " op"},
        };
    }

    @DataProvider
    private Object[][] testStringLength_positiveDP() {
        return new Object[][] {
                                { " Ja", 3},
                                { " op", 3},
        };
    }

    @AfterClass
    private void afterClass() {

    }
}
