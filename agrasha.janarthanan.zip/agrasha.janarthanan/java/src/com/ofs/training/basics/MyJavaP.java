package com.ofs.training.basics;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class MyJavaP {

    public static void main(String[] args) {

        String classPackage = args[0];
        Class<?> clazz= loadClass(classPackage);
        printClassDetails(clazz);
    }

    private static void printClassDetails(Class<?> clazz) {

        System.out.println("Compiled from " + "\"" + clazz.getSimpleName() + ".java" + "\"");

        //print superclass
        printSuperClass(clazz);

        //print Interfaces
        printInterface(clazz);

        System.out.print("{");

        //print Constructors
        printConstructor(clazz);

        //print Fields
        printField(clazz);

        //print Methods
        printMethod(clazz);

        System.out.println("}");

    }

    private static void printSuperClass(Class<?> clazz) {

        StringBuilder sb =  new StringBuilder();
        Class<?> classSuperClass = clazz.getSuperclass();
        if (classSuperClass != null) {
            sb.append("extends").append(classSuperClass.getName());
            System.out.println(sb.toString());
        }
    }

    private static void printMethod(Class<?> clazz) {

        StringBuilder sb = new StringBuilder();
        Method[] classMethods = clazz.getMethods();
        for (int index = 0; index < classMethods.length; index++) {
            sb.append("\n").append(classMethods[index]);
        }
        System.out.println(sb);
    }

    private static void printField(Class<?> clazz) {

        StringBuilder sb = new StringBuilder();
        Field[] classFields = clazz.getFields();
        for (int index = 0; index < classFields.length; index++) {
            sb.append("\n").append(classFields[index]);
        }
        System.out.println(sb);
    }

    private static void printConstructor(Class<?> clazz) {

        StringBuilder sb = new StringBuilder();
        Constructor<?>[] classConstructors = clazz.getConstructors();
        for (int index = 0; index < classConstructors.length; index++) {
            sb.append("\n").append(classConstructors[index]);
        }
        System.out.println(sb);
    }

    private static void printInterface(Class<?> clazz) {

        //getModifier()
        int modifier = clazz.getModifiers();
        String classModifier = getModifier(modifier);
        System.out.println(classModifier + " " + "class " + clazz.getName());

        Class<?> classInterfaces[] = clazz.getInterfaces();
        if (classInterfaces.length > 0) {
            System.out.println("implements");
            StringBuilder sb =  new StringBuilder();
            for ( Class<?> classInterface : classInterfaces) {
                sb.append(classInterface.getName());
                System.out.println("," + sb );
            }
        }
    }

    private static String getModifier(int modifier) {

        StringBuilder sb = new StringBuilder();
        if(Modifier.isPrivate(modifier))   { sb.append("private"); }
        if(Modifier.isProtected(modifier)) { sb.append("protected"); }
        if(Modifier.isPublic(modifier))    { sb.append("public"); }
        if(Modifier.isFinal(modifier))     { sb.append("final"); }
        if(Modifier.isStatic(modifier))    { sb.append("static"); }
        if(Modifier.isNative(modifier))    { sb.append("native"); }
        if(Modifier.isSynchronized(modifier))    { sb.append("synchronized"); }

        return sb.toString();
    }

    private static Class<?> loadClass(String myPackage) {

        try {
            Class<?> myClassName =  Class.forName(myPackage);
            return myClassName;
        } catch (ClassNotFoundException e) {

            throw new RuntimeException(e);
        }
    }
}
