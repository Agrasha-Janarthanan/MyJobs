package com.ofs.training.basics;

// class IntegerToString {
public class IntegerToString {

    // static void execute() {
    public static void main(String[] args) {

        Integer aNumber = 230;

        // String myValue = convertToString(aNumber);
        String myValue = Integer.toString(aNumber);
        int myNumber = Integer.parseInt(myValue, 5);

        // Console console = getConsole()...;
        // console.print(myValue);
        System.out.println(myNumber);
    }
}
