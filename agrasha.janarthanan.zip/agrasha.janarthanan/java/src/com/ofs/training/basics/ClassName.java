package com.ofs.training.basics;

public class ClassName {

    public static void main(String[] args) {

        int[] numbers = {1, 2, 3};
        String[] words = {"apple", "ball", "cat"};
        char[] letters = {'a', 'b', 'c'};

        String number = numbers.getClass().getName();
        String letter = letters.getClass().getName();
        String word = words.getClass().getName();

        System.out.println(number);
        System.out.println(letter);
        System.out.println(word);
    }
}
