package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class InitialFinderTest {

    private InitialFinder myInitial;

    @BeforeClass
    private void initialize() {

        myInitial = new InitialFinder();
    }

    @Test(dataProvider = "testComputeInitial_positiveDP")
    private void testComputeInitial_positive(String name, String expectedOutput) {

        try {
            String actualOutput = myInitial.computeInitial(name);
            Assert.assertEquals(actualOutput, expectedOutput, "Given input " + name);
        } catch (Exception e) {
            Assert.fail("Unexpected exception for input "
                        + name
                        + "Expected result is "
                        + expectedOutput
                        + e);
        }
    }

    @DataProvider
    private Object[][] testComputeInitial_positiveDP() {
        return new String[][] {
                                {"Lalitha Janarthanan", "LJ"},
                                {"Agrasha", "A"}
                              };
    }

    @Test
    private void testComputeInitial_negative() {
        
        try {
            myInitial.computeInitial(null);
            Assert.fail("Expected an exception");
        } catch (Exception e) {
            
            Assert.assertEquals(e.getMessage(),"Name cannot be null");
        }
    }

    @Test
    private void testComputeInitial_negative1() {

        try {
            myInitial.computeInitial(" ");
            Assert.fail("Expected an exception");
        } catch (Exception e) {

            Assert.assertEquals(e.getMessage(),"Name cannot be empty");
        }
    }
}
