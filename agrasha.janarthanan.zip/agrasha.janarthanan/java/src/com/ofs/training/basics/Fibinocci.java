package com.ofs.training.basics;

// class Fibinocci {
public class Fibinocci {

    static int firstNumber = 0;
    static int secondNumber = 1;
    static int nextNumber;

    // static void execute() {
    public static void main(String[] args) {

        // Console console = getConsole()....
        // console.print("Fibinocci using while loop");
        System.out.println("Fibinocci using while loop");

        // Fibinocci fibinocci = fibinocciGenerator();
        Fibinocci fibinocci = new Fibinocci();
        fibinocci.seriesGenerator();

        // console.print("Fibinocci using for loop");
        System.out.println("Fibinocci using for loop");

        // Fibinocci fibinocci = fibinocciSeries();
        Fibinocci myFibinocci = new Fibinocci();
        myFibinocci.generator();

        // console.print("Fibinocci using recursion");
        System.out.println("Fibinocci using recursion");

        // Fibinocci fibinocci = printFibinocci();
        Fibinocci fibinocciObject = new Fibinocci();
        System.out.println(firstNumber);
        System.out.println(secondNumber);
        fibinocciObject.seriesPrinter(10);
    }

    public void seriesGenerator() {

        int firstNumber = 0;
        int secondNumber = 1;
        int count = 10;
        int position = 0;
        int nextNumber;

        System.out.println(firstNumber);
        System.out.println(secondNumber);

        while (position < count) {
            nextNumber = firstNumber + secondNumber;
            System.out.println(nextNumber);
            firstNumber = secondNumber;
            secondNumber = nextNumber;
            position++;
        }
    }

    public void generator() {

        int firstNumber = 0;
        int secondNumber = 1;
        int count = 10;
        int nextNumber;

        System.out.println(firstNumber);
        System.out.println(secondNumber);

        for (int index = 2; index < count; index++) {
            nextNumber = firstNumber + secondNumber;
            System.out.println(nextNumber);
            firstNumber = secondNumber;
            secondNumber = nextNumber;
        }
    }

    public void seriesPrinter(int count) {

        if (count > 0) {
            nextNumber = firstNumber + secondNumber;
            System.out.println(nextNumber);
            firstNumber = secondNumber;
            secondNumber = nextNumber;
            seriesPrinter(count - 1);
        }
    }
}
