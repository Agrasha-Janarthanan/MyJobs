package com.ofs.training.basics;

interface SomethingIsWrong {
    void aMethod(int aValue);
}

public class InterfaceDemo implements SomethingIsWrong {

    public void aMethod(int aValue) {
        System.out.println("Hi Mom");
    }

    public static void main(String[] args) {

        InterfaceDemo myInterface = new InterfaceDemo();
        myInterface.aMethod(10);
    }
}
