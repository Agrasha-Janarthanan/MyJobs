package com.ofs.training.basics;

public class NumberHolder {

    public int anInt;
    public float aFloat;

    NumberHolder(int number, float decimal) {
        this.anInt = number;
        this.aFloat = decimal;
    }

    public static void main(String[] args) {

        NumberHolder object = new NumberHolder(10, 50.5f);

        System.out.println(object.anInt);
        System.out.println(object.aFloat);
    }
}
