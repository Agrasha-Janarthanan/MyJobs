package com.ofs.training.basics;

// class InitialFinder {
public class InitialFinder {

    private static final String ERR_NAME_CANNOT_BE_NULL = "Name cannot be null";
    private static final String ERR_NAME_CANNOT_BE_EMPTY = "Name cannot be empty";

    //compute the initials of given name
    public String computeInitial(String userName) {

        if (userName == null) {
            throw new RuntimeException(ERR_NAME_CANNOT_BE_NULL);
        } else if (userName == " "){
            throw new RuntimeException(ERR_NAME_CANNOT_BE_EMPTY);
        }

        // String name = fullname.getSubString();
        String[] names = userName.split(" ");

        // String initial = name.getFirstLetter();
        System.out.println("The Initial of " + userName + " is :");

        StringBuilder sb =new StringBuilder();
        for (int index = 0; index < names.length; index++) {
            char initial = names[index].charAt(0);
            sb.append(initial);
        }
        return sb.toString();
    }

    // static void execute() {
    public static void main(String[] args) {

        // String fullname = getName();
        String fullName = "Agrasha Janathanan";

        //Create object for the class
        InitialFinder myInitial = new InitialFinder();
        System.out.println(myInitial.computeInitial(fullName)); 
    }
}
