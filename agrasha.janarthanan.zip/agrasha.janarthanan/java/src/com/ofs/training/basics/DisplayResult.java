package com.ofs.training.basics;

public class DisplayResult {

    private static final String ERR_INVALID_INPUT_EXPRESSION = "The input expression is invalid";
    public String getReturnType(Object object) {

        if (object != null) {
            if (object instanceof Integer) {
                return "int";
            } else if (object instanceof Character) {
                return "char";
            } else if (object instanceof Float) {
                return "float";
            } else if (object instanceof Double) {
                return "double";
            }
        }
        throw new RuntimeException(ERR_INVALID_INPUT_EXPRESSION);
    }

    public static void main(String[] args) {

        DisplayResult displayResult = new DisplayResult();
        Object result1 = 100 / 24;
        System.out.println(displayResult.getReturnType(result1));

        Object result2 = 100.01 / 2.01;
        System.out.println(displayResult.getReturnType(result2));

        Object result3 = 'Z' / 2;
        System.out.println(displayResult.getReturnType(result3));

        Object result4 = 10.5 / 0.5;
        System.out.println(displayResult.getReturnType(result4));

        Object result5 = 12.4 % 5.5;
        System.out.println(displayResult.getReturnType(result5));

        Object result6 = 100 % 56;
        System.out.println(displayResult.getReturnType(result6));
    }
}
