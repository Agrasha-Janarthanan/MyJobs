package com.ofs.training;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DisplayDateTime {

    //void static execute() {
    public static void main(String[] args) {

        //DisplayDateTime time = new DisplayDateTime();
        //int instantTime = time.getInstantTime();
        Instant instantTime = Instant.now();

        //Console console = getConsole()...
        //console.print(instantTime);
        System.out.format("Instant time : %s %n", instantTime);

        //int now = time.getInstantTime();
        Instant now = Instant.now();

        //console.print(now);
        System.out.format("Current Time : %s%n", now);

        //int duration = time.getDuration(instantTime, now);
        Duration duration = Duration.between(instantTime, now);

        //console.print(duration);
        System.out.format("Duration between two timings : %s%n", duration);

        //DisplayDateTime day = new DisplayDateTime();
        //int date = day.getDate();
        LocalDate date = LocalDate.now();

        //int month = day.getMonth();
        Month month = date.getMonth();

        //int year = day.getYear();
        int year = date.getYear();

        //console.print("Today's Date : " , date, "-", month, "-", year);
        System.out.format("Today's Date : %s%n Current Month : %s%n Current Year : %s%n", date, month, year);

        //int zoneTime = getZoneTime();
        ZonedDateTime zonedDateTime = ZonedDateTime.now();

        //console.print(zoneTime);
        System.out.format("Current Zone date and time : %s%n", zonedDateTime);

        //String formattedDate = formatDate(date);
        DateTimeFormatter formatter = DateTimeFormatter.RFC_1123_DATE_TIME;
        String formattedZonedDate = formatter.format(zonedDateTime);

        //console.print(formattedDate);
        System.out.format("formattedDate = %s ", formattedZonedDate);
    }
}
