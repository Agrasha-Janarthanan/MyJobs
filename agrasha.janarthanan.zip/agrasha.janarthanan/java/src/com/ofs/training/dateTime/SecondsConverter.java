package com.ofs.training.dateTime;

import java.time.Instant;

public class SecondsConverter {

    private void run(String[] args) throws Exception {

        Instant instant =Instant.now();
        log(instant);

        long milliSeconds = System.currentTimeMillis();
        long nanoSeconds = System.nanoTime();

        log(milliSeconds, nanoSeconds);
    }

    private void log(Instant time) {
        System.out.println("Current time : " + time);
    }

    private void log(long milliSeconds, long nanoSeconds) {
        System.out.format("Current time in milliSeconds : %d %nCurrent time in nanoseconds : %d", milliSeconds, nanoSeconds);
    }

    public static void main(String[] args) {
        try {
            SecondsConverter o = new SecondsConverter();
            o.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
