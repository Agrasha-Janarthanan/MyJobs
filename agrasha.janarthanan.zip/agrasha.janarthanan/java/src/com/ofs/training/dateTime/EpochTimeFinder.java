package com.ofs.training.dateTime;

import java.util.Calendar;
import java.util.Date;

public class EpochTimeFinder {

    private void run() throws Exception {

        Date today = Calendar.getInstance().getTime();
        log(today);
        long epochTime = today.getTime();
        log(epochTime);
    }

    private void log(long time) {
        System.out.println("Current epoch date : " + time);
    }

    private void log(Date date) {
        System.out.println("Current Date : " + date);
    }

    public static void main(String[] args) {
        try {
            EpochTimeFinder finder = new EpochTimeFinder();
            finder.run();
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
