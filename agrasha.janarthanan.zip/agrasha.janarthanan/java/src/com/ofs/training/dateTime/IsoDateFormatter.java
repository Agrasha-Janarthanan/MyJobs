package com.ofs.training.dateTime;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class IsoDateFormatter {

    private void run() throws Exception {

        LocalDate date = LocalDate.now();
        DateTimeFormatter formatter1 = DateTimeFormatter.BASIC_ISO_DATE;
        DateTimeFormatter formatter2 = DateTimeFormatter.ISO_DATE;
        DateTimeFormatter formatter3 = DateTimeFormatter.ISO_LOCAL_DATE;
        DateTimeFormatter formatter4 = DateTimeFormatter.ISO_ORDINAL_DATE;
        DateTimeFormatter formatter5 = DateTimeFormatter.ISO_WEEK_DATE;
        log(date);
        log(formatter1.format(date));
        log(formatter2.format(date));
        log(formatter3.format(date));
        log(formatter4.format(date));
        log(formatter5.format(date));
    }

    private void log(LocalDate date) {
        System.out.format("Current Date : %s%n", date);
    }

    private void log(String string) {
        System.out.format("Formatted Date : %s%n",string);
    }

    public static void main(String[] args) {
        try {
            IsoDateFormatter formatter = new IsoDateFormatter();
            formatter.run();
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
