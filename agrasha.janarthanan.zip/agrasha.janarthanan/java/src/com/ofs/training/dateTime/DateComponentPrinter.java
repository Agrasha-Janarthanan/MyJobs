package com.ofs.training.dateTime;

import java.time.LocalDate;

public class DateComponentPrinter {

    private void run(String[] args) throws Exception {
        LocalDate date = LocalDate.now();
        log(date);
        int day = date.getDayOfMonth();
        int month = date.getMonthValue();
        int year = date.getYear();
        log(day, month, year);
    }

    private void log(LocalDate date) {
         System.out.println(date);
    }

    private void log(int day, int month, int year) {
        System.out.println("Components of the date");
        System.out.format("Date : %d Month : %d Year : %d", day, month, year);
    }

    public static void main(String[] args) {
        try {
            DateComponentPrinter printer = new DateComponentPrinter();
            printer.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
