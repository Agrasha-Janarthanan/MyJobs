package com.ofs.training;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class ReadFileUsingReader {

    public void readFile() throws IOException {

        InputStream in = new FileInputStream("src/main/java/com/ofs/training/input.txt");
        Reader inputReader = new InputStreamReader(in);
        int text;
        while ((text = in.read()) != -1) {
            char data = (char) text;
            System.out.print(data);
        }

        int data;
        while ((data = inputReader.read()) != -1) {
            char content = (char) data;
            System.out.print(content);
        }
        inputReader.close();
    }

    public static void main(String[] args) throws IOException {

        ReadFileUsingReader reader = new ReadFileUsingReader();
        reader.readFile();
    }
}
