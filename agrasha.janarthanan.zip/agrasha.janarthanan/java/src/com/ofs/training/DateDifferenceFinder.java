package com.ofs.training;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class DateDifferenceFinder {

    private void run() throws Exception {

        LocalDate firstDate = LocalDate.now();
        LocalDate secondDate = firstDate.plusDays(7);

//        finding the difference using Peroid.between()
        int dateDifference = Period.between(firstDate, secondDate).getDays();
        log(dateDifference, firstDate, secondDate);

//        Finding the difference using ChronoUnit.DAYS.between()
        long differenceInDays = ChronoUnit.DAYS.between(firstDate, secondDate);
        log(differenceInDays, firstDate, secondDate);
    }

    private void log(long difference, LocalDate firstDate, LocalDate secondDate) {
        System.out.format("Differnce between %s and %s is : %d days %n", firstDate, secondDate, difference);
    }

    public static void main(String[] args) {
        try {
            DateDifferenceFinder finder = new DateDifferenceFinder();
            finder.run();
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
