package com.ofs.training.advanced;

import java.util.ArrayList;

public class GenericsDemo {

    ArrayList<String> employeeList= new ArrayList<>();

    String employeeName = "agrasha";
}
