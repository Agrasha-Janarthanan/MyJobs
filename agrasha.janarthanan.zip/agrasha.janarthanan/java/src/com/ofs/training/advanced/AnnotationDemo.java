package com.ofs.training.advanced;

import java.lang.reflect.Method;

public class AnnotationDemo {

    @MyAnnotation (
            name = "Agrasha",
            employeeId = 1711,
            batch = "Batch 01"
    )

    public void displayDetails() {

        AnnotationDemo demo = new AnnotationDemo();
        try {
            Class<? extends AnnotationDemo> demoClass = demo.getClass();
            Method demoMethod = demoClass.getMethod("displayDetails");
            MyAnnotation myAnnotation = demoMethod.getAnnotation(MyAnnotation.class);

            System.out.println("Employee Name :" + myAnnotation.name());
            System.out.println("Employee ID : " + myAnnotation.employeeId());
            System.out.println("Project : " + myAnnotation.project());
            System.out.println("Batch : " + myAnnotation.batch());
        } catch (Exception e) {
            System.out.println("Details not found");
        }
    }

    public static void main(String[] args) {

        AnnotationDemo annotationDemo = new AnnotationDemo();
        annotationDemo.displayDetails();
    }
}
