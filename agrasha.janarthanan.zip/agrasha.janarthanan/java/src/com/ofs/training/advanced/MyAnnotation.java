package com.ofs.training.advanced;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
@interface MyAnnotation {

    String name();
    int employeeId();
    String project() default "Training";
    String batch();
}
