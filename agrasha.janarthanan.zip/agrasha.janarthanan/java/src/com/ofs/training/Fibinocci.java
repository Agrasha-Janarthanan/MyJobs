package com.ofs.training;

// class Fibinocci {
public class Fibinocci {

    static int numberOne = 0;
    static int numberTwo = 1;
    static int numberThree;

    // static void execute() {
    public static void main(String[] args) {

        // Console console = getConsole()....
        // console.print("Fibinocci using while loop");
        System.out.println("Fibinocci using while loop");

        // Fibinocci fibinocci = fibinocciGenerator();
        Fibinocci fibinocci = new Fibinocci();
        fibinocci.fibinocciGenerator();

        // console.print("Fibinocci using for loop");
        System.out.println("Fibinocci using for loop");

        // Fibinocci fibinocci = fibinocciSeries();
        Fibinocci myFibinocci = new Fibinocci();
        myFibinocci.fibinocciSeries();

        // console.print("Fibinocci using recursion");
        System.out.println("Fibinocci using recursion");

        // Fibinocci fibinocci = printFibinocci();
        Fibinocci fibinocciObject = new Fibinocci();
        System.out.println(numberOne);
        System.out.println(numberTwo);
        fibinocciObject.printFibinocci(10);
    }

    public void fibinocciGenerator() {

        int firstNumber = 0;
        int secondNumber = 1;
        int count = 10;
        int position = 0;
        int nextNumber;

        System.out.println(firstNumber);
        System.out.println(secondNumber);

        while (position < count) {
            nextNumber = firstNumber + secondNumber;
            System.out.println(nextNumber);
            firstNumber = secondNumber;
            secondNumber = nextNumber;
            position++;
        }
    }

    public void fibinocciSeries() {

        int numOne = 0;
        int numTwo = 1;
        int limit = 10;
        int result;

        System.out.println(numOne);
        System.out.println(numTwo);

        for (int index = 2; index < limit; index++) {
            result = numOne + numTwo;
            System.out.println(result);
            numOne = numTwo;
            numTwo = result;
        }
    }

    public void printFibinocci(int bound) {

        if (bound > 0) {
            numberThree = numberOne + numberTwo;
            System.out.println(numberThree);
            numberOne = numberTwo;
            numberTwo = numberThree;
            printFibinocci(bound - 1);
        }
    }
}
