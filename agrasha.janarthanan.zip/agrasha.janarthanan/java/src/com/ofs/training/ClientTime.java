package com.ofs.training;

import java.time.*;

public interface ClientTime {

    void setDate(int day, int month, int year);
    void setTime(int hour, int minute, int second);
    void displayDate();
    void displayTime();
    LocalDateTime getDateTime();
}
