package com.ofs.training;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.time.format.DateTimeFormatter;

public class DayLister {

    private void run(String[] args) throws Exception {

        Year year = Year.now();
        Month month = Month.SEPTEMBER;
        int monthLength = year.atMonth(month.getValue()).lengthOfMonth();
        DayOfWeek day = DayOfWeek.MONDAY;
        DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM-dd-yyyy");
        System.out.format("Monday's in the %s month are : %n", month);

        for (int date = 1; date <= monthLength; date++) {
            DayOfWeek dayOfWeek = year.atMonth(month).atDay(date).getDayOfWeek();
            if (dayOfWeek == day) {
                LocalDate dateOfMonth = year.atMonth(month).atDay(date);
                String dayOfMonth = dateOfMonth.format(formatters);
                log(dayOfMonth);
            }
        }
    }

    private void log(String dayOfMonth) {
        System.out.println(dayOfMonth);
    }

    public static void main(String[] args) {

        try {
            DayLister lister = new DayLister();
            lister.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
