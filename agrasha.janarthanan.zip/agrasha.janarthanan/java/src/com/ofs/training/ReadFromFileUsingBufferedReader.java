package com.ofs.training;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadFromFileUsingBufferedReader {

    public void readFileContent() throws IOException {

        FileReader reader = new FileReader("src/main/java/com/ofs/training/sample.txt");
        BufferedReader readBuffer = new BufferedReader(reader);
        int data ;
        while ((data = readBuffer.read()) != -1) {
            char text = (char) data;
            System.out.print(text);
        }
        readBuffer.close();
    }

    public static void main(String[] args) throws IOException {

        ReadFromFileUsingBufferedReader reader = new ReadFromFileUsingBufferedReader();
        reader.readFileContent();
    }
}
