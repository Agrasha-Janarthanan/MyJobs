package com.ofs.training;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;

public class TimeStampGenerator {

    private void run(String[] args) throws Exception {

        Instant instant = Instant.now();
        SimpleDateFormat formatter = new SimpleDateFormat("dd:MM:yyyy:hh:mm:ss");
        Timestamp timestamp = Timestamp.from(instant);
        log(formatter.format(timestamp));
    }

    private void log(String timestamp) {
         System.out.println(timestamp);

    }

    public static void main(String[] args) {
        try {
            TimeStampGenerator timeStampGenerator = new TimeStampGenerator();
            timeStampGenerator.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
