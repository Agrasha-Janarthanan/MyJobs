package com.ofs.training;

public class Problem {

    static String s;
    static class Inner {

        void testMethod() {
            s = "Set from Inner";
        }
    }
}

// REASON
// As the class is Static we cannot access a non static variable 
// so,we are making the variable as static variable