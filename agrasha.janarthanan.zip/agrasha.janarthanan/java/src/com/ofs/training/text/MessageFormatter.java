package com.ofs.training.text;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;

public class MessageFormatter {

    private void run() throws Exception {

        Locale inLocale = Locale.CHINA;

        NumberFormat formatter = NumberFormat.getInstance(inLocale);
        String number = formatter.format(new Long(78932135));
        System.out.println(number);

        DateFormat dateFormatter = DateFormat.getDateInstance(DateFormat.FULL, inLocale);
        String date = dateFormatter.format(new Date());
        System.out.println(date);

        Date today = new Date();
        String pattern = "On {0} date ,I joined this company ";
        Object[] argument = {today};
        String stringFormatter = MessageFormat.format(pattern, argument);
        System.out.println(stringFormatter);
    }

    public static void main(String[] args) {
        try {
            MessageFormatter formatter = new MessageFormatter();
            formatter.run();
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
