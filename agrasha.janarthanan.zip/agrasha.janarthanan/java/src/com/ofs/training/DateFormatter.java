package com.ofs.training;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class DateFormatter {

    private void run() throws Exception {

        Calendar date = Calendar.getInstance(TimeZone.getTimeZone("America/Los_Angeles"));
        SimpleDateFormat format = new SimpleDateFormat("yyyy.MM.dd 'at' HH:mm:ss z");
        format.setTimeZone(date.getTimeZone());
        System.out.println(format.format(date.getTime()));
    }

    public static void main(String[] args) {
        try {
            DateFormatter formatter = new DateFormatter();
            formatter.run();
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
