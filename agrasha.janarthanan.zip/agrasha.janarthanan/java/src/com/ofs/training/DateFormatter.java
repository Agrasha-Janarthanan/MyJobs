package com.ofs.training;

import java.time.LocalDateTime;
import java.util.Formatter;

public class DateFormatter {

    private void run(String[] args) throws Exception {

        LocalDateTime now = LocalDateTime.now();
        Formatter formatter = new Formatter();
        String dateFormat = now.getYear() + "." + now.getMonth().getValue() + "." + now.getDayOfMonth() + " at ";
        String timeFormat = now.getHour() + ":" + now.getMinute() + ":" + now.getSecond() + " ";
        String dateTimeFormat = dateFormat + timeFormat;
        formatter.format(dateTimeFormat, args);
        log(now);
        log(formatter);
        formatter.close();
    }

    private void log(Formatter formatter) {
         System.out.println(formatter);
    }

    private void log(LocalDateTime dateTime) {
         System.out.println(dateTime);
    }

    public static void main(String[] args) {
        try {
            DateFormatter formatter = new DateFormatter();
            formatter.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}

//2001-07-04T12:08:56.235-0700 and 2001.07.04 at 12:08:56 PDT
