package com.ofs.training;

public class CharSequenceDemo implements CharSequence{

    private String name;

    public CharSequenceDemo(String input) {
        this.name = input;
    }

    @Override
    public char charAt(int index) {
        if ((index < 0) || (index > name.length())){
            throw new RuntimeException ("Given String is out of bound");
        }
        return this.charAt(index);
    }

    @Override
    public int length() {
        return this.length();
    }

    @Override
    public CharSequence subSequence(int start, int end) {
        return this.subSequence(start, end);
    }

    public String toString(String input) {
        return this.toString(input);
    }

    public static void main(String[] args) {
        CharSequenceDemo myName = new CharSequenceDemo("Agrasha jana");
        for (int index = 0; index < myName.length(); index++) {
            System.out.println(myName.charAt(index));
        }
    }
}
