package com.ofs.training.collection;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortPerson {

    public void sortByAge(List<Person> roster) {

        List<Person> sortedPerson = roster.stream()
                                          .sorted(Comparator.comparingInt(person -> ((Person) person).getAge()).reversed())
                                          .collect(Collectors.toList());
        sortedPerson.stream()
                    .forEach(person -> person.printPerson());
    }

    public static void main(String[] args) {

        SortPerson sortPerson = new SortPerson();
        sortPerson.run();
    }

    public void run() {
        List<Person> person = Person.createRoster();
        SortPerson sortPerson = new SortPerson();
        sortPerson.sortByAge(person);
    }
}
