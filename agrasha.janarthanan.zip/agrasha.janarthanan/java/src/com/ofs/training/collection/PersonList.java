 package com.ofs.training.collection;

import java.time.chrono.IsoChronology;
import java.util.ArrayList;
import java.util.List;

public class PersonList {

    public List<Person> addPerson(List<Person> person) {
        List<Person> newRoster = new ArrayList<>();
        newRoster.add(new Person("John",
                                 IsoChronology.INSTANCE.date(1980, 6, 20),
                                 Person.Sex.MALE,
                                 "john@example.com"));
        newRoster.add(new Person("Jade",
                                 IsoChronology.INSTANCE.date(1990, 7, 15),
                                 Person.Sex.FEMALE, "jade@example.com"));
        newRoster.add(new Person("Donald",
                                 IsoChronology.INSTANCE.date(1991, 8, 13),
                                 Person.Sex.MALE, "donald@example.com"));
        newRoster.addAll(person);
        return newRoster;
    }

    public static void main(String[] args) {
        PersonList personList = new PersonList();
        personList.run();
    }

    private void run() {
        PersonList personList = new PersonList();
        List<Person> people = Person.createRoster();
        Person bob = new Person("Bob",
                IsoChronology.INSTANCE.date(2000, 9, 12),
                Person.Sex.MALE, "bob@example.com");
        List<Person> newRoster = personList.addPerson(people);
        newRoster.add(bob);
        System.out.println("displaying newRoster");
        personList.displayList(newRoster);
        personList.sizeOfList(newRoster);
        System.out.println(personList.checkPerson(newRoster, bob));
        System.out.println("Retaining persons");
        personList.retainList(newRoster, people);
        System.out.println("Removing bob from newRoster");
        personList.removeOne(newRoster, bob);
        System.out.println("Removing newRoster from roster");
        personList.removeAllPerson(newRoster);
        personList.removePerson(people);
    }

    private void removeOne(List<Person> newRoster, Person person) {
        newRoster.remove(person);
        displayList(newRoster);
    }

    private void retainList(List<Person> newRoster, List<Person> people) {
        newRoster.retainAll(people);
        displayList(newRoster);
    }

    private void removePerson(List<Person> people) {
        people.removeAll(people);
    }

    private boolean checkPerson(List<Person> personList, Person person) {
         return personList.contains(person);
    }

    private void sizeOfList(List<Person> newRoster) {
         int size = newRoster.size();
         System.out.format("The size of the updated list : %d%n",size);
    }

    private void removeAllPerson(List<Person> newRoster) {
         newRoster.removeAll(newRoster);
    }

    private void displayList(List<Person> newRoster) {
        newRoster.forEach(person -> person.printPerson());
    }
}
