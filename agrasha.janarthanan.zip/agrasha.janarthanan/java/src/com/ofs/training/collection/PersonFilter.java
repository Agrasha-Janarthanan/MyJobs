package com.ofs.training.collection;

import java.util.List;
import java.util.stream.Collectors;

import com.ofs.training.collection.Person.Sex;


public class PersonFilter {

    public static void main(String[] args) {

        List<Person> roster = Person.createRoster();
        List<Person> resultList = roster.stream()
                                        .filter(person -> { return person.getGender() == Sex.MALE; })
                                        .filter(person -> { return person.getAge() > 21; })
                                        .collect(Collectors.toList());
    }
}
