package com.ofs.training.collection;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class SortPersonDetail {

    public List<Person> sortPersonByAge(List<Person> roster) {

        Collections.sort(roster, Comparator.comparing(Person::getAge).reversed());
        return roster;
    }

    public static void main(String[] args) {

        SortPersonDetail sortPerson = new SortPersonDetail();
        sortPerson.run();
    }

    public void run() {

        List<Person> personList = Person.createRoster();
        List<Person> sortPersonList = sortPersonByAge(personList);
        sortPersonList.stream()
                      .forEach(person -> person.printPerson());
    }
}
