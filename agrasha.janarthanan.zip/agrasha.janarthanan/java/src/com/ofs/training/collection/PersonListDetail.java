package com.ofs.training.collection;

import java.util.List;
import java.util.stream.Collectors;

public class PersonListDetail {

    public String name;
    public String emailId;

    public static void main(String[] args) {

        PersonListDetail personListDetail = new PersonListDetail();
        personListDetail.run();
    }

    private void run() {

        List<Person> roster = Person.createRoster();
        List<PersonDetail> personList = roster.stream()
                                              .map(Person::toMinimalList)
                                              .collect(Collectors.toList());
        personList.stream()
                  .forEach(person-> System.out.println(person.name + "\t" + person.emailId));
    }

}
