package com.ofs.training;

// class ObjectEqualityDemo {
public class ObjectEqualityDemo {

    // static void execute() {
    public static void main(String[] args) {

        String firstName = "Agrasha";
        String lastName = "Janarthanan";

        // ObjectEqualityDemo object = compareNames(firstName, lastName);
        System.out.println(firstName.equals(lastName));

        // Console console = getConsole()...
        // console.print(object);
        // console.print(firstName == lastName);
        System.out.println(firstName == lastName);
    }
}
