package com.ofs.training;

import java.util.List;

public class DisplayPersonDetail {

    public void displayDetail(List<Person> personList) {
        for (Person people : personList) {
            System.out.println(people);
        }
    }

    public static void main(String[] args) {
        DisplayPersonDetail displayPersonDetail = new DisplayPersonDetail();
        displayPersonDetail.run();
    }

    public void run() {
        List<Person> person= Person.createRoster();
        displayDetail(person);
    }
}
