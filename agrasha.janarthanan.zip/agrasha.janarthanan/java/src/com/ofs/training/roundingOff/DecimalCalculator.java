package com.ofs.training.roundingOff;

import java.math.BigDecimal;

public class DecimalCalculator {

    private void run() throws Exception {

        BigDecimal number = new BigDecimal("0.056962594654");
        BigDecimal value = new BigDecimal("0.2356913216464");

        System.out.println(number.abs());

        BigDecimal ceil = number.setScale(8,BigDecimal.ROUND_CEILING);
        System.out.println(ceil);

        BigDecimal floor = number.setScale(8,BigDecimal.ROUND_FLOOR);
        System.out.println(floor);

        System.out.println(number.min(value));
        System.out.println(number.floatValue());
        System.out.println(number.max(value));
    }

    public static void main(String[] args) {
        try {
            DecimalCalculator calculator = new DecimalCalculator();
            calculator.run();
        } catch (Throwable t) {
            System.out.println(t);
        }
    }
}
