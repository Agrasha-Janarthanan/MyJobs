package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;

public class PersonListDetail {

    private String name;
    private String emailId;

    private static PersonListDetail toMinimalList(Person person) {

        PersonListDetail detail = new PersonListDetail();
        detail.setName(person.getName());
        detail.setEmailId(person.getEmailAddress());
        return detail;
    }

    private String setEmailId(String mailId) {
        return this.emailId;
    }

    private String setName(String personName) {
        return this.name;
    }

    @Override
    public String toString() {
        return "PersonListDetail [name=" + name + ", emailId=" + emailId + "]";
    }

    public static void main(String[] args) {

        PersonListDetail personListDetail = new PersonListDetail();
        personListDetail.run();
    }

    private void run() {

        List<Person> roster = Person.createRoster();
        List<PersonListDetail> personListDetail = roster.stream()
                                                        .map(PersonListDetail::toMinimalList)
                                                        .collect(Collectors.toList());
        System.out.println(personListDetail.toString());
    }

}
