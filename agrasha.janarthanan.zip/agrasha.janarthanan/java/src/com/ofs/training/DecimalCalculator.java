package com.ofs.training;

import java.math.BigDecimal;

public class DecimalCalculator {

    private void run() throws Exception {

        BigDecimal number = new BigDecimal("0.0569");
        Double decimalNumber = 158.25698745;
        System.out.println(number.abs());
        System.out.println(number.ROUND_CEILING);
        System.out.println(number.ROUND_FLOOR);
        System.out.println(Math.rint(decimalNumber));
        System.out.println(number.max(number));
        System.out.println(number.min(number));
    }

    public static void main(String[] args) {
        try {
            DecimalCalculator calculator = new DecimalCalculator();
            calculator.run();
        } catch (Throwable t) {
            System.out.println(t);
        }
    }

    private static void log (Throwable t) {
        t.printStackTrace(System.err);
    }
}
