package com.ofs.training;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class MinMaxFilter {

    public static void main(String[] args) {

        List<Integer> randomNumbers = Arrays.asList(1, 6, 10, 25, 78);

        int total = getStream(randomNumbers).
                    sum();
        System.out.format("Sum of the numbers in the list : %d%n", total);

        int minimum = getStream(randomNumbers).
                      min().
                      getAsInt();
        System.out.format("Minimum number in the list : %d%n", minimum);

        int maximum = getStream(randomNumbers).
                      max().
                      getAsInt();
        System.out.format("Maximum number in the list : %d%n", maximum);
    }

    private static IntStream getStream(List<Integer> randomNumbers) {
        return randomNumbers.
                    stream().
                    mapToInt(Integer :: intValue);
    }
}
