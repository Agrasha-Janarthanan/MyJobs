package com.ofs.training;

class MyJava {

     static void execute() {

    }
}
