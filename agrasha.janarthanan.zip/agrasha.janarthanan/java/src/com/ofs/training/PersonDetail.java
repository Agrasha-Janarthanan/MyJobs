package com.ofs.training;

import java.util.List;

public class PersonDetail {

    private String name;
    private String emailId;

    private static PersonDetail toMinimalList(Person person) {

        PersonDetail detail = new PersonDetail();
        detail.setName(person.getName());
        detail.setEmailId(person.getEmailAddress());
        return detail;
    }

    private String setEmailId(String mailId) {
        return this.emailId;
    }

    private String setName(String personName) {
        return this.name;
    }

    private void run() {

        List<Person> roster = Person.createRoster();
        roster.stream()
              .map(PersonDetail::toMinimalList)
              .forEach(person -> System.out.println(person));
    }

    @Override
    public String toString() {
        return "PersonDetail [name=" + name + ", emailId=" + emailId + "]";
    }

    public static void main(String[] args) {

        PersonDetail personDetail = new PersonDetail();
        personDetail.run();
    }
}
