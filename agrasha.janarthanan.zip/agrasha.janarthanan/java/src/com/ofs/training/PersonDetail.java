package com.ofs.training;

import java.util.List;

public class PersonDetail {

    public String name;
    public String emailId;

    private void run() {

        List<Person> roster = Person.createRoster();
        roster.stream()
              .map(Person::toMinimalList)
              .forEach(person -> System.out.println(person.name + "\t" + person.emailId));
    }

    public static void main(String[] args) {

        PersonDetail personDetail = new PersonDetail();
        personDetail.run();
    }
}
