package com.ofs.training.jdbc;

import java.sql.Date;
import java.sql.Time;

public class Person {

    long id = 1;
    String name;
    String email;
    Date birthDate;
    Time createdDate;
    long addressId;

    public Person(String name, String email, Date birthDate, long addressId) {

        this.name = name;
        this.email = email;
        this.birthDate = birthDate;
        this.addressId = addressId;
    }

    public Person() {
    }

    public long getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getEmail() {
        return this.email;
    }

    public Date getBirthDate() {
        return this.birthDate;
    }

    public Time getCreatedDate() {
        return this.createdDate;
    }

    public long getAddressId() {
        return this.addressId;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public void setCreatedDate(Time createdDate) {
        this.createdDate = createdDate;
    }

    @Override
    public String toString() {
        return "Person [name=" + name + ", email=" + email + ", birthDate=" + birthDate
                + "]";
    }

    public void setAddressId(long addressId) {
        this.addressId = addressId;
    }

}
