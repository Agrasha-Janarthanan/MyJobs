package com.ofs.training.jdbc;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AddressService {

    private void validateConnection(Connection conn) {

        if(conn == null) {
            throw new RuntimeException("Service not available");
        }
    }

    private void validatePincode(Address address) {

        if(address.getPincode() == 0) {
            throw new RuntimeException("Pincode cannot be null");
        }
    }

    public void validateId(long id) {

        if (id == 0) {
            throw new RuntimeException("ID cannot be null");
        }
    }

    public void validateCondition(String condition) {

        if (condition == null || condition == "") {
            throw new RuntimeException("condition cannot be null or empty");
        }
    }

    public int create(Address address, Connection conn) throws Exception {

        StringBuilder sb = new StringBuilder();
        int generatedKey = 0;

        validatePincode(address);
        validateConnection(conn);

        sb.append("INSERT INTO address (street, city, postal_code)");
        sb.append("VALUES (?, ?, ?)");
        PreparedStatement statement = conn.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, address.getStreet());
        statement.setString(2, address.getCity());
        statement.setInt   (3, address.getPincode());
        statement.executeUpdate();
        ResultSet generatedKeys = statement.getGeneratedKeys();

        if ((generatedKeys != null) && (generatedKeys.next())) {
            generatedKey = generatedKeys.getInt(1);
        }
        return generatedKey; 
    }

    public void update(long id, String condition, Connection conn) throws SQLException {

        StringBuilder sb = new StringBuilder();

        validateId(id);
        validateCondition(condition);
        validateConnection(conn);

        sb.append("UPDATE address SET ");
        sb.append(condition);
        sb.append("WHERE id = ");
        sb.append(id);
        PreparedStatement statement = conn.prepareStatement(sb.toString());
        statement.executeUpdate();
    }

    public Address read(long id, Connection conn) throws Exception {

        validateId(id);
        validateConnection(conn);

        String query = "SELECT id, street, city, postal_code FROM address WHERE id = " + id;
        PreparedStatement statement = conn.prepareStatement(query);
        ResultSet result = statement.executeQuery();
        result.next();
        Address address = new Address();
        address.setId     (result.getLong("id"));
        address.setStreet (result.getString("street"));
        address.setCity   (result.getString("city"));
        address.setPincode(result.getInt("postal_code"));
        return address;
    }

    public List<Address> readAll(Connection conn) throws Exception {

        validateConnection(conn);

        StringBuilder sb = new StringBuilder();
        List<Address> resultRecords = new ArrayList<>();
        sb.append("SELECT id, street, city, postal_code FROM address");
        PreparedStatement statement = conn.prepareStatement(sb.toString());
        ResultSet result = statement.executeQuery();

        while (result.next()) {

            Address address = new Address();
            address.setId(result.getLong("id"));
            address.setStreet(result.getString("street"));
            address.setCity(result.getString("city"));
            address.setPincode(result.getInt("postal_code"));
            resultRecords.add(address);
        }
        return resultRecords;
    }

    public Address delete(Address address, Connection conn) throws SQLException {

        StringBuilder sb = new StringBuilder();

        validateId(address.id);
        validateConnection(conn);

        sb.append("DELETE FROM address WHERE id = ");
        sb.append(address.id);
        PreparedStatement statement = conn.prepareStatement(sb.toString());

        statement.executeUpdate();
        return address;
    }
}
