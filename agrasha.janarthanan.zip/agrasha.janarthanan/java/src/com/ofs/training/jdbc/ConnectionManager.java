package com.ofs.training.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionManager {

    Connection conn = null;
    public Connection openConnection(String connectionString) {

        try {
            conn = DriverManager.getConnection(connectionString);
            conn.setAutoCommit(false);
        } catch (Exception exception) {
            throw new RuntimeException("Invalid Connection");
        }
        return conn;
    }

    public void closeConnection() {

        try {
            conn.close();
        } catch (Exception exception) {
            throw new RuntimeException("Connection is not open");
        }
    }
}
