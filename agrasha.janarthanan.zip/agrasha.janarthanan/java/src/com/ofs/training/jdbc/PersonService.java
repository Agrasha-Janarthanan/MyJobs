package com.ofs.training.jdbc;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PersonService {

    AddressService addressService = new AddressService();
    AddressServiceTest addressServiceTest = new AddressServiceTest();

    public void validateConnection(Connection conn) {

        if (conn == null) {
            throw new RuntimeException("Service not available");
        }
    }

    public void validateId(long id) {

        if (id == 0) {
            throw new RuntimeException("ID cannot be null");
        }
    }

    private void validateCondition(String condition) {

        if (condition == null || condition == "") {
            throw new RuntimeException("condition cann be null");
        }
    }

    public int create(Person person, Address address, Connection conn) throws Exception {

        int generatedKey = 0;
        try {
            String selectQuery = "SELECT email FROM person";
            PreparedStatement stmt = conn.prepareStatement(selectQuery);
            stmt.executeQuery(selectQuery);

            StringBuilder sb = new StringBuilder();
            sb.append("INSERT INTO person (name, email, birth_date, address_id)");
            sb.append("VALUES (?, ?, ?, ?)");

            PreparedStatement statement = conn.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
            int addressId = addressService.create(address, conn);
            statement.setString(1, person.name);
            statement.setString(2, person.email);
            statement.setDate  (3, person.birthDate);
            statement.setInt   (4, addressId);
            statement.executeUpdate();

            ResultSet generatedKeys = statement.getGeneratedKeys();
            if ((generatedKeys != null) && (generatedKeys.next())) {
                generatedKey = generatedKeys.getInt(1);
            }
        } catch (Exception e) {
            throw new RuntimeException("Email already exists");
        }
        return generatedKey; 
    }


    public void update(String condition, long id, Connection conn) throws SQLException {

        StringBuilder sb = new StringBuilder();

        if (condition == null || condition == "") {
            throw new RuntimeException("condition cann be null");
        }

        sb.append("UPDATE person SET ");
        sb.append(condition);
        sb.append("WHERE id = ");
        sb.append(id);
        PreparedStatement statement = conn.prepareStatement(sb.toString());
        statement.executeUpdate();
    }

    public Person read(long id, boolean includeAddress, Connection conn) {

//        String resultRecord = null;
        Person person = new Person();

        try {

            String query = "SELECT id, name, email, birth_date, created_date, address_id FROM person WHERE id = "+ id;
            String joinQuery = "SELECT id, name, email, birth_date, created_date, address_id FROM person JOIN address ON address.id = person.address_id WHERE id = "+ id;
            Address address = new Address();

            if (includeAddress) {

                 PreparedStatement statement = conn.prepareStatement(joinQuery);
                 ResultSet result = statement.executeQuery();
                 result.next();
                 address.setId        (result.getLong("id"));
                 address.setStreet    (result.getString("street"));
                 address.setCity      (result.getString("city"));
                 address.setPincode   (result.getInt("pincode"));
                 person.setId         (result.getLong("id"));
                 person.setAddressId  (result.getLong("address_id"));
                 person.setName       (result.getString("name"));
                 person.setEmail      (result.getString("email"));
                 person.setBirthDate  (result.getDate("birth_date"));
                 person.setCreatedDate(result.getTime("created_date"));
            } else {

                PreparedStatement statement = conn.prepareStatement(query);
                ResultSet result = statement.executeQuery();
                result.next();
                person.setId(result.getLong("id"));
                person.setAddressId(result.getLong("address_id"));
                person.setName(result.getString("name"));
                person.setEmail(result.getString("email"));
                person.setBirthDate(result.getDate("birth_date"));
                person.setCreatedDate(result.getTime("created_date"));
            }
        } catch (Exception exception) {
            throw new RuntimeException("ID cannot be empty");
        }
        return person;
    }

    public List<Object> readAll(boolean includeAddress, Connection conn) throws SQLException {

        List<Object> resultRecord = new ArrayList<>();

        String query = "SELECT id, name, email, birth_date, created_date, address_id FROM person";
        String joinQuery = "SELECT id, name, email, birth_date, created_date, address_id FROM person JOIN address ON address.id = person.address_id";
        if (includeAddress) {

            PreparedStatement statement = conn.prepareStatement(joinQuery);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Person person = new Person();
                Address address = new Address();
                person.setId         (result.getLong("id"));
                person.setName       (result.getString("name"));
                person.setEmail      (result.getString("email")); 
                person.setBirthDate  (result.getDate("birth_date"));
                person.setCreatedDate(result.getTime("created_date"));
                person.setAddressId  (result.getLong("address_id"));
                address.setStreet    (result.getString("street"));
                address.setCity      (result.getString("city"));
                address.setPincode   (result.getInt("postal_code"));
                resultRecord.add(address);
                resultRecord.add(person);
            }
        } else {

            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Person person = new Person();
                person.setId         (result.getLong("id")); 
                person.setAddressId  (result.getLong("address_id"));
                person.setName       (result.getString("name"));
                person.setEmail      (result.getString("email")); 
                person.setBirthDate  (result.getDate("birth_date"));
                person.setCreatedDate(result.getTime("created_date"));
                resultRecord.add(person);
            }
        }
        return resultRecord;
    }

    public Person delete(Person person, Connection conn) throws SQLException {

        StringBuilder sb = new StringBuilder();

        validateId(person.id);

        sb.append("DELETE FROM person WHERE id = ");
        sb.append(person.id);
        PreparedStatement statement = conn.prepareStatement(sb.toString());
        statement.executeUpdate();
        return person;
    }
}
