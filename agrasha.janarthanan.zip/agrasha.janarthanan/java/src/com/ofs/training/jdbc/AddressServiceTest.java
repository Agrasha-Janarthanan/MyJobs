package com.ofs.training.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class AddressServiceTest {

    AddressService addressService;
    ConnectionManager txn = new ConnectionManager();
    Connection conn = txn.openConnection("jdbc:mysql://pc1620:3306/agrasha_janarthanan?useSSL=false&user=agrasha_janarthanan&password=demo");

    @BeforeClass
    private void initialize() {
        addressService = new AddressService();
    }

//    positive test case to insert a record
    @Test(dataProvider = "testCreate_positiveDP", priority = 1)
    private void testCreate_positive(Address address, long expectedResult) throws SQLException {

        try{

            long actualResult = addressService.create(address, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
                Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() {

        return new Object[][] {
            {new Address ("Mint street", "Madras", 600235), 1},
            {new Address ("Car street", "Tiruvannamalai", 606601), 2}
        };
    }

//    negative test case to insert a record
    @Test(dataProvider = "testCreate_negativeDP", priority = 2)
    private void testCreate_negative(Address address) {

        try{

            addressService.create(address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Pincode cannot be null");
        }
    }

    @DataProvider
    private Object[][] testCreate_negativeDP() {

        return new Object[][] {
            {new Address ("Mint street", "Madras", 0)}
        };
    }

//    positive case to update a record
    @Test(dataProvider = "testUpdate_positiveDP", priority = 3)
    private void testUpdate_positive(long id, String condition) {

        try {

            addressService.update(id, condition, conn);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + e);
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() throws SQLException {

        return new Object[][] {
            {1, "city = 'Chennai'"},
            {2, "street = 'church park street'"}
        };
    }

//    negative case to update a record
    @Test(dataProvider = "testUpdate_negativeDP", priority = 4)
    private void testUpdate_negative(long id, String condition, String exceptionMessage) {

        try {
            addressService.update(id, condition, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), exceptionMessage);
        }
    }

    @DataProvider
    private Object[][] testUpdate_negativeDP() throws SQLException {
        
        return new Object[][] {
            {0, "city = 'Chennai'", "ID cannot be null"}
        };
    }

//    positive case to read a record using id
    @Test(dataProvider = "testRead_positiveDP", priority = 7)
    private void testRead_positive(long id, Address expectedResult) {

        try {

            Address actualResult = addressService.read(id, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {

        return new Object[][] {
            {1, new Address("Mint street", "Chennai", 600235)}
        };
    }

//    negative case to read a record using id
    @Test(priority = 8)
    private void testRead_negative() {

        try {

            addressService.read(0, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "ID cannot be null");
        }
    }

//  positive case to read all record using id
    @Test(dataProvider = "testReadAll_positiveDP", priority = 9)
    private void testReadAll_positive(List<Address> expectedResult) {

      try {

          List<Address> actualResult = addressService.readAll(conn);
          Assert.assertEquals(actualResult.toString(), expectedResult.toString());
          conn.commit();
      } catch (Exception e) {
          Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
      }
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {

        List<Address> inputAddress = new ArrayList<>();
        inputAddress.add(new Address("Mint street", "Chennai", 600235));
        return new Object[][] {
            {inputAddress}
        };
    }

//  negative case to read all record using id
    @Test(priority = 10)
    private void testReadAll_negative() {

        try {

            addressService.readAll(null);
            Assert.fail("Expected an exception.");
            conn.rollback();
      } catch (Exception e) {
          Assert.assertEquals(e.getMessage(), "Service not available");
      }
    }

//    positive case to delete a record
    @Test(dataProvider = "testDelete_positiveDP", priority = 5)
    private void testDelete_positive(Address address, Address expectedResult) {

        try {

            Address actualResult = addressService.delete(address, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + e);
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() throws SQLException{
        return new Object[][] {
            {2, new Address ("Car street", "Tiruvannamalai", 606601)}
        };
    }

//    negative case to delete a record
    @Test(priority = 6)
    private void testDelete_negative() {

        try {

            addressService.delete(null, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "ID cannot be null");
        }
    }

    @AfterClass
    private void closeConnection() {
        txn.closeConnection();
    }
}
