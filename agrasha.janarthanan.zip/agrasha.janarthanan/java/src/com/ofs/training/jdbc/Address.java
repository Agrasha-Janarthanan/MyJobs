package com.ofs.training.jdbc;

public class Address {

    long id = 1;
    private String street;
    private String city;
    private int pincode;

    public Address(String street, String city, int pincode) {

        this.street = street;
        this.city = city;
        this.pincode = pincode;
    }

    public Address() {
    }

    public long getId() {
        return this.id;
    }

    public String getStreet() {
        return this.street;
    }

    public String getCity() {
        return this.city;
    }

    public int getPincode() {
        return this.pincode;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setPincode(int pincode) {
        this.pincode = pincode;
    }

    @Override
    public String toString() {
        return "Address [id=" + id + ", street=" + street + ", city=" + city + ", postal_code=" + pincode + "]";
    }
}
