package com.ofs.training.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class PersonServiceTest {

    PersonService personService;
    ConnectionManager txn = new ConnectionManager();
    Connection conn = txn.openConnection("jdbc:mysql://pc1620:3306/agrasha_janarthanan?useSSL=false&user=agrasha_janarthanan&password=demo");

    @BeforeClass
    private void initialize() {
        personService = new PersonService();
    }

    @Test(dataProvider = "testCreateRecord_positiveDP", priority = 1)
    private void testCreateRecord_positive(Person person, Address address, int expectedResult) {

        try {

            int actualResult = personService.create(person, address, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testCreateRecord_positiveDP() throws ParseException {
        return new Object[][] { 
                                { new Person ("agi", "agi@gmail.com", Date.valueOf("1996-08-08"), 1 ), new Address ("Mint street", "Chennai", 600345), 1},
                                { new Person ("agrasha", "agrasha@gmail.com",Date.valueOf("1996-09-08"), 2), new Address ("Car street", "Tiruvannamalai", 606601), 2}
        };
    }

    @Test(dataProvider = "testCreateRecord_negativeDP", priority = 2)
    private void testCreateRecord_negative(Person person, Address address) {

        try {

            personService.create(person, address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Email already exists");
        }
    }

    @DataProvider
    private Object[][] testCreateRecord_negativeDP() throws ParseException {
        return new Object[][] { 
                                { new Person ("agrasha", "agrasha@gmail.com", Date.valueOf("1996-08-08"), 2), new Address ("Car street", "Tiruvannamalai", 606601)}
        };
    }

    @Test(dataProvider = "testUpdateRecord_positiveDP", priority = 3)
    private void testUpdate_positive(String condition, long id, Connection conn) {

        try {

            personService.update(condition, id, conn);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + e);
        }
    }

    @DataProvider
    private Object[][] testUpdateRecord_positiveDP() {
        return new Object[][] { 
                                {"email = 'abcd@gmail.com'", 1, conn}
                              };
    }

    @Test(dataProvider = "testUpdate_negativeDP", priority = 4)
    private void testUpdateRecord_negative(String condition, long id, Connection conn, String exceptionMessage) {

        try {

            personService.update(condition, id, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), exceptionMessage);
        }
    }

    @DataProvider
    private Object[][] testUpdate_negativeDP() {
        return new Object[][] { 
                                {"", 1, conn, "condition cann be null"}
                              };
    }

    @Test(dataProvider = "testRead_positiveDP", priority = 5)
    private void testRead_positive(long id, boolean includeAddress, Person expectedResult) {

        try {

            Person actualResult = personService.read(id, includeAddress, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {
        return new Object[][] { {1, false, new Person("agi", "abcd@gmail.com", Date.valueOf("1996-08-08"), 1)},
                                {2, false, new Person("agrasha", "agrasha@gmail.com", Date.valueOf("1996-09-08"), 2)}
        };
    }

    @Test(priority = 6)
    private void testRead_negative() {

        try {

            personService.read(0, false, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "ID cannot be empty");
        }
    }

    @Test(dataProvider = "testReadAllRecords_positiveDP", priority = 7)
    private void testReadAllRecords_positive(boolean includeAddress, List<Object> expectedResult) {
        try {

            List<Object> actualResult = personService.readAll(includeAddress, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testReadAllRecords_positiveDP() {
        List<Object> result = new ArrayList<>();
        result.add(new Person("agi", "abcd@gmail.com", Date.valueOf("1996-08-08"), 1));
        result.add(new Person("agrasha", "agrasha@gmail.com", Date.valueOf("1996-09-08"), 2));
//        [Person [name=agrasha, email=agrasha@gmail.com, birthDate=1996-09-08], Person [name=agrasha, email=agrasha@gmail.com, birthDate=1996-09-08]]
        return new Object[][] { 
                                {false, result}
                              };
    }

    @Test(dataProvider = "testDeleteRecord_positiveDP", priority = 8)
    private void testDeleteRecord_positive(Person person, Person expectedResult) {
        try {

            Person actualResult = personService.delete(person, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is \" + expectedResult + e");
        }
    }

    @DataProvider
    private Object[][] testDeleteRecord_positiveDP() {

        Person person = new Person ();
        person.setId(2);
        Person expectedResult = new Person ("agrasha", "agrasha@gmail.com",Date.valueOf("1996-09-08"), 2);
        return new Object[][] { 
                                {person, expectedResult}
                              };
    }

    @Test(dataProvider = "testDeleteRecord_negativeDP",priority = 9)
    private void testDeleteRecord_negative(Person person) {

        try {

            personService.delete(person, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "ID cannot be null");
        }
    }

    @DataProvider
    private Object[][] testDeleteRecord_negativeDP() {

        Person person = new Person();
        person.setId(0);
        return new Object[][] { 
                                {person}
                              };
    }

    @AfterClass
    private void closeConnection() {
        txn.closeConnection();
    }
}
