package com.ofs.training;

// class StringLengthCalculator {
public class StringLengthCalculator {

    private static final String ERR_INVALID_STRING = "Input string is invalid";
    public String stringOperation(String input) {

        if (input.length() == 0) {
            throw new RuntimeException(ERR_INVALID_STRING);
        }
        String mySubString = input.substring(9,12);
        return mySubString;
    }

    public int stringLength(String mySubString) {

        if (mySubString.length() == 0) {
            throw new RuntimeException(ERR_INVALID_STRING);
        }
        int myLength = mySubString.length();
        return myLength;
    }

    // static void execute() {
    public static void main(String[] args) {

        // String myString = "Was it a car or a cat I saw?";
        String myString = new String("Was it a car or a cat I saw?");
        StringLengthCalculator calculate = new StringLengthCalculator();

        String resultString = calculate.stringOperation(myString);
        int resultLength = calculate.stringLength(resultString);

        // Console console = getConsole()...;
        // console.print(mySubString);
        System.out.println("Sub String : " + resultString);

        // console.print(length);
        System.out.println("Length of the sub string: " + resultLength);
    }
}
