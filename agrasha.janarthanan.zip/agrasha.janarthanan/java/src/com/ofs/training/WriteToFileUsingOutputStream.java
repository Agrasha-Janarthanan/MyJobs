package com.ofs.training;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class WriteToFileUsingOutputStream {

    public void writeText() throws IOException {

        OutputStream out = new FileOutputStream("src/main/java/com/ofs/training/content.txt");
        String content = "I just added this text";
        byte[] text = content.getBytes();
        out.write(text);
        out.close();
    }
    public static void main(String[] args) throws IOException {

        WriteToFileUsingOutputStream writer = new WriteToFileUsingOutputStream();
        writer.writeText();
    }
}
