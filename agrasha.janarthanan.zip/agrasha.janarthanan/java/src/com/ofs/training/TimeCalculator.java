package com.ofs.training;

import java.util.Timer;

public class TimeCalculator {

    private void run(String[] args) throws Exception {

        Timer timer = new Timer();
        System.out.println(timer);
    }

    public static void main(String[] args) {
        try {
            TimeCalculator timeCalculator = new TimeCalculator();
            timeCalculator.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
