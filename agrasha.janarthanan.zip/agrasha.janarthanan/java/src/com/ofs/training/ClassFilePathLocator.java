package com.ofs.training;

public class ClassFilePathLocator {

    //static void execute() {
    public static void main(String[] args) {

        //ClassFilePathLocator currentProgram = getCurrentProgram()
        ClassFilePathLocator currentProgram = new ClassFilePathLocator();

        //Class currentClass = currentProgram.getClass()
        Class<? extends ClassFilePathLocator> currentClass = currentProgram.getClass();

        // File currentClassFile = currentClass.getFile()
        // String absolutePath = currentClassFile.getAbsolutePath()
        String absolutePath = currentClass.getProtectionDomain()
                                          .getCodeSource()
                                          .getLocation()
                                          .getFile();

        // Console console = getConsole()........
        // console.print(absolutePath)
        System.out.println(absolutePath + currentClass.getName() + ".class");
    }
}
