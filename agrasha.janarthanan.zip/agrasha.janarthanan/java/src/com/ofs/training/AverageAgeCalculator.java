package com.ofs.training;

import java.util.List;;

public class AverageAgeCalculator {

    public double calculateAverageAgeToDouble(List<Person> person) {

        double averageAge = person.stream()
                                  .mapToDouble(Person::getAge)
                                  .average()
                                  .getAsDouble();
        return averageAge;
    }

    public double calculateAverageAgeToInt(List<Person> person) {

        double averageAge = person.stream()
                                  .mapToInt(Person::getAge)
                                  .average()
                                  .getAsDouble();
        return averageAge;
    }

    public static void main(String[] args) {
        AverageAgeCalculator calculator = new AverageAgeCalculator();
        calculator.run();
    }

    public void run() {

        List<Person> people = Person.createRoster();
        double averageAgeAsLong = calculateAverageAgeToDouble(people);
        double averageAgeAsInt = calculateAverageAgeToInt(people);
        System.out.println(averageAgeAsLong);
        System.out.println(averageAgeAsInt);
    }
}
