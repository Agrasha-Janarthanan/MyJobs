package com.ofs.training;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class CurrentTimeGetter {

    private void run() throws Exception {

//        current time using LocalTime
        LocalTime localTime = LocalTime.now();
        log(localTime);

//        current time using ZonedDateTime
        ZonedDateTime zonedDateTime = ZonedDateTime.now();
        int zonedHour = zonedDateTime.getHour();
        int zonedMinute = zonedDateTime.getMinute();
        int zonedSecond = zonedDateTime.getSecond();
        int zonedNanoSecond = zonedDateTime.getNano();
        log(zonedHour, zonedMinute, zonedSecond, zonedNanoSecond);

//        current time using Calendar
        Calendar calendar = new GregorianCalendar();
        int hour       = calendar.get(Calendar.HOUR);
        int minute     = calendar.get(Calendar.MINUTE);
        int second     = calendar.get(Calendar.SECOND);
        int milliSecond= calendar.get(Calendar.MILLISECOND);
        log(hour, minute, second, milliSecond);

//        current time using Instance
        Clock clock = Clock.systemDefaultZone();
        Instant dateTime = Instant.now(clock);
        log(dateTime);
    }


    private void log(int hour, int minute, int second, int nanoSecond) {
        System.out.format("%d:%d:%d.%d%n", hour, minute, second, nanoSecond);
    }

    public static void main(String[] args) {
        try {
            CurrentTimeGetter timeGetter = new CurrentTimeGetter();
            timeGetter.run();
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private void log(Object time) {
        System.out.println(time);
    }
}
