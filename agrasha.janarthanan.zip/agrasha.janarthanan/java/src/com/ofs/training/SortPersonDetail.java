package com.ofs.training;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class SortPersonDetail {

    public void sortPersonByAge(List<Person> roster) {
        Collections.sort(roster, Comparator.comparing(personList -> ((Person)personList).getAge()).reversed());
        System.out.println(roster);
    }

    public static void main(String[] args) {

        SortPersonDetail sortPerson = new SortPersonDetail();
        sortPerson.run();
    }

    public void run() {
        List<Person> personList = Person.createRoster();
        SortPersonDetail sortPerson = new SortPersonDetail();
        sortPerson.sortPersonByAge(personList);
    }
}
