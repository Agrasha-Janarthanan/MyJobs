package com.ofs.training;

public class WriteToFileUsingWriter {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

}
