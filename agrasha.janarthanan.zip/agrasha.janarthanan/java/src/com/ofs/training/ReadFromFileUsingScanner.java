package com.ofs.training;

import java.io.File;
import java.util.Scanner;

public class ReadFromFileUsingScanner {

    public void readFile(File inputFile) throws Exception{

        Scanner sc = new Scanner(inputFile);
        while (sc.hasNextLine()) {
            System.out.println(sc.nextLine());
        }
        sc.close();
    }

    public static void main(String[] args) throws Exception {

        ReadFromFileUsingScanner readFromFile = new ReadFromFileUsingScanner();
        readFromFile.run();
    }

    public void run() throws Exception {

        File file = new File("src/main/java/com/ofs/training/test.txt");
        readFile(file);
    }
}
