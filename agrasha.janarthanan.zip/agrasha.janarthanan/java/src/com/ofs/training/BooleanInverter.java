package com.ofs.training;

public class BooleanInverter {

    public static void main(String[] args) {

        Boolean value = Boolean.TRUE;
        System.out.println(!value);
    }
}
