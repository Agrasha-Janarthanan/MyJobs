package com.ofs.training;

import java.util.Iterator;
import java.util.List;

public class PrintPersonDetail {

    public void printDetail(List<Person> personList) {

        Iterator<Person> itr=personList.iterator();
        while(itr.hasNext())
        {
            System.out.println(itr.next());
        }
    }

    public static void main(String[] args) {
        PrintPersonDetail printPersonDetail = new PrintPersonDetail();
        printPersonDetail.run();
    }

    public void run() {
        PrintPersonDetail printPersonDetail = new PrintPersonDetail();
        List<Person> person = Person.createRoster();
        printPersonDetail.printDetail(person);
    }
}
