package com.ofs.training;

import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

public class TaskExecutor extends TimerTask {

    public static int i = 0;

    public void run() {

        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm a EEEE , dd MMMMM yyyy:");
        System.out.println(Calendar.getInstance().getTime());
        System.out.println("Hi I am auto runner" + ++i);
         if (i == 10)
         {
             synchronized(TaskExecutor.executor)
             {
                 TaskExecutor.executor.notify();
             }
         }
    }

    public static TaskExecutor executor;

    public static void main(String[] args) {

        try {
            executor = new TaskExecutor();
            Timer timer = new Timer();
            TimerTask task = new TaskExecutor();
            timer.schedule(task, 1000, 10000);
            task.scheduledExecutionTime();
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
