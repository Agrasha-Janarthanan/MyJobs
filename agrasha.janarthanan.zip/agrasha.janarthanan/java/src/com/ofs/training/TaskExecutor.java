package com.ofs.training;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

public class TaskExecutor extends TimerTask {

    @Override
    public void run() {

        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm a EEEE , dd MMMMM yyyy:");
        System.out.println(formatter.format(Calendar.getInstance().getTime()));
        System.out.println("Hi I am auto runner");
    }

    public static TaskExecutor executor;

    public static void main(String[] args) {

        try {
            executor = new TaskExecutor();
            Timer timer = new Timer();
            TimerTask task = new TaskExecutor();
            timer.schedule(task, 100, 10000);
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
