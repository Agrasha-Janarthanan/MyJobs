package com.ofs.training;

public class ExceptionExample {

    public static void main(String[] args) {

        int number = 10;
        int divider = 0;
        int result;

            if (divider == 0) {
                throw new RuntimeException("Divided by Zero");
            }
            result = number / divider;
            System.out.println("The Result is: " + result);
    }
}
