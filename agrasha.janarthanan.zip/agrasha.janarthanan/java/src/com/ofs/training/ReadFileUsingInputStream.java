//Reading a file using InputStream

package com.ofs.training;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class ReadFileUsingInputStream {

    private void readFromInputStream(InputStream inputStream) throws Exception {

        int data;
        while ((data = inputStream.read()) != -1) {
           System.out.print((char) data);
        }
    }

    private void run() throws Exception {

        File file = new File("D:/dev/training/agrasha.janarthanan/vcs/sessionFeedback.txt");
        InputStream in = new FileInputStream(file);
        readFromInputStream(in);
    }

    public static void main(String[] args) {
        try {
            ReadFileUsingInputStream readFile = new ReadFileUsingInputStream();
            readFile.run();
        } catch (Throwable t) {
            System.out.println(t);
        }
    }
}
