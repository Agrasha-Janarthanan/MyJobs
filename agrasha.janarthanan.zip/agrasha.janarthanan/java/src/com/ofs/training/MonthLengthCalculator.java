package com.ofs.training;

import java.time.Month;
import java.time.Year;

public class MonthLengthCalculator {

    private void run(String[] args) throws Exception {

        Year year = Year.now();
        for(int index = 1; index < 13; index++) {
            log(year.atMonth(index).lengthOfMonth(), year.atMonth(index).getMonth());
        }
    }

    private void log(int lengthOfMonth, Month month) {
        System.out.format("Length of the month %s \t : %d%n" ,month, lengthOfMonth);
    }

    public static void main(String[] args) {
        try {
            MonthLengthCalculator calculator = new MonthLengthCalculator();
            calculator.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
