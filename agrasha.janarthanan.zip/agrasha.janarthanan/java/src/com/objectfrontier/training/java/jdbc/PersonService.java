package com.objectfrontier.training.java.jdbc;
 
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;

public class PersonService {

    Person person = new Person();
    Address address = new Address();
    AddressService addressService = new AddressService();
    AddressServiceTest addressServiceTest = new AddressServiceTest();

    public int createPerson(Person person, Address address, Connection conn) throws Exception {

        String selectQuery = "SELECT email FROM person";
        Statement stmt = conn.prepareStatement(selectQuery);
        ResultSet rs = stmt.executeQuery(selectQuery);
        rs.next();
        String emailId = person.getEmail();

        if (person.email == emailId) {
            throw new RuntimeException("Email already exists");
        }

        StringBuilder sb = new StringBuilder();
        sb.append("INSERT INTO person (name, email, birth_date, address_id)");
        sb.append("VALUES (?, ?, ?, ?)");

        PreparedStatement statement = (PreparedStatement) conn.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, person.name);
        statement.setString(2, person.email);
        statement.setDate(3, person.birthDate);
        int addressId = addressService.createAddress(address, conn);
        statement.setInt(4, addressId);

        int generatedKey = 0;
        ResultSet generatedKeys = statement.getGeneratedKeys();
        if ((generatedKeys != null) && (generatedKeys.next())) {
            generatedKey = generatedKeys.getInt(1);
        }
        return generatedKey; 
    }

    public int updatePerson(String condition, Connection conn) {

        StringBuilder sb = new StringBuilder();
        int rowsUpdated = 0;

        try {

            sb.append("UPDATE address SET name = 'agrasha' WHERE ");
            sb.append(condition);
            PreparedStatement statement = (PreparedStatement) conn.prepareStatement(sb.toString());
            rowsUpdated = statement.executeUpdate();
        } catch (Exception exception) {
            throw new RuntimeException("Cannot update without condition");
        }
        return rowsUpdated;
    }

    public String readPerson(long id, boolean includeAddress, Connection conn) {

        String resultRecord = null;

        try {

                String query = "SELECT id, name, email, birth_date, created_date, address_id FROM person WHERE id = "+ id;
                String joinQuery = "SELECT id, name, email, birth_date, created_date, address_id FROM person JOIN address ON address.id = person.address_id WHERE id = "+ id;

                if (includeAddress) {

                     PreparedStatement statement = (PreparedStatement) conn.prepareStatement(query);
                     ResultSet result = statement.executeQuery();
                     result.next();
                     person.setId(result.getLong("id"));
                     resultRecord = person.getId() + "," 
                                                   + person.getName() 
                                                   + "," 
                                                   + person.getEmail() 
                                                   + "," 
                                                   + person.getBirthDate() 
                                                   + "," 
                                                   + person.getCreatedDate() 
                                                   + "," 
                                                   + person.getAddressId()
                                                   + "," 
                                                   + address.getStreet()
                                                   + "," 
                                                   + address.getCity()
                                                   + "," 
                                                   + address.getPincode();
                } else {

                    PreparedStatement statement = (PreparedStatement) conn.prepareStatement(joinQuery);
                    ResultSet result = statement.executeQuery();
                    result.next();
                    person.setId(result.getLong("id"));
                    resultRecord = person.getId() + "," 
                                                  + person.getName() 
                                                  + "," 
                                                  + person.getEmail() 
                                                  + "," 
                                                  + person.getBirthDate() 
                                                  + "," 
                                                  + person.getCreatedDate(); 
                }
        } catch (Exception exception) {
            throw new RuntimeException("ID cannot be empty");
        }
        return resultRecord;
    }

    public String readAllPerson(String tableName, boolean includeAddress, Connection conn) {

        StringBuilder sb = new StringBuilder();
        String resultRecord = null;
        String resultant = null;
        List<String> resultRecords = new ArrayList<>();

        try {

            sb.append("SELECT id, name, email, birth_date, created_date, address_id FROM " + tableName);

            if (includeAddress) {

                PreparedStatement statement = (PreparedStatement) conn.prepareStatement(sb.toString());
                ResultSet result = statement.executeQuery();
                while (result.next()) {

                    resultRecord = person.getId() + person.getName() 
                                                  + person.getEmail() 
                                                  + person.getBirthDate()
                                                  + person.getCreatedDate()
                                                  + person.getAddressId()
                                                  + address.getStreet()
                                                  + address.getCity()
                                                  + address.getPincode();
                    resultRecords.add(resultRecord);
                    resultant = resultRecords.toString();
                }
            } else {

                PreparedStatement statement = (PreparedStatement) conn.prepareStatement(sb.toString());
                ResultSet result = statement.executeQuery();
                while (result.next()) {

                    resultRecord = person.getId() + person.getName() 
                                                  + person.getEmail() 
                                                  + person.getBirthDate()
                                                  + person.getCreatedDate()
                                                  + person.getAddressId();
                    resultRecords.add(resultRecord);
                    resultant = resultRecords.toString();
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException("Table Not found");
        }
        return resultant;
    }

    public int deletePerson(long id, Connection conn) {

        StringBuilder sb = new StringBuilder();
        int rowsDeleted = 0;

        try {

            long deletedId = addressService.deleteAddress(id, conn);
            sb.append("DELETE FROM person WHERE id = ");
            sb.append(deletedId);
            PreparedStatement statement = (PreparedStatement) conn.prepareStatement(sb.toString());
            rowsDeleted = statement.executeUpdate();
        } catch (Exception exception) {
            throw new RuntimeException("Cannot delete without condition");
        }
        return rowsDeleted;
    }
}
