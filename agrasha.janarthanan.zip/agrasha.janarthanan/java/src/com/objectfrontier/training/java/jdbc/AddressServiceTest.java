package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class AddressServiceTest {

    AddressService addressService;
    ConnectionManager txn = new ConnectionManager();
    Connection conn = txn.openConnection("jdbc:mysql://pc1620:3306/agrasha_janarthanan?useSSL=false&user=agrasha_janarthanan&password=demo");

    @BeforeClass
    private void initialize() {
        addressService = new AddressService();
    }

//    positive test case to insert a record
    @Test(dataProvider = "testCreateRecord_positiveDP")
    private void testCreateRecord_positive(Address address, long expectedResult) throws SQLException {

        try{

            long actualResult = addressService.createAddress(address, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
                Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testCreateRecord_positiveDP() {

        return new Object[][] {
            {new Address ("Mint street", "Madras", 600235), 1},
            {new Address ("Car street", "Tiruvannamalai", 606601), 2}
        };
    }

//    negative test case to insert a record
    @Test(dataProvider = "testCreateRecord_negativeDP")
    private void testCreateRecord_negative(Address address) {

        try{

            addressService.createAddress(address,conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Pincode cannot be null"
                    + "");
        }
    }

    @DataProvider
    private Object[][] testCreateRecord_negativeDP() {

        return new Object[][] {
            {new Address ("Mint street", "Madras", 0)}
        };
    }

//    positive case to update a record
    @Test(dataProvider = "testUpdateRecord_positiveDP")
    private void testUpdateRecord_positive(long id, int expectedResult) {

        try {

            int actualResult = addressService.updateAddress(id, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testUpdateRecord_positiveDP() throws SQLException {

        return new Object[][] {
            {1, 1},
            {2, 0}
        };
    }

//    negative case to update a record
    @Test
    private void testUpdateRecord_negative() {

        try {
            addressService.updateAddress(0, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Cannot update without id");
        }
    }

//    positive case to read a record using id
    @Test(dataProvider = "testReadRecord_positiveDP")
    private void testReadRecord_positive(long id, String expectedResult) {

        try {

            String actualResult = addressService.readAddress(id, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testReadRecord_positiveDP() {

        return new Object[][] {
            {1, "1,Mint street,Madras,600235"}
        };
    }

//    negative case to read a record using id
    @Test
    private void testReadRecord_negative() {

        try {

            addressService.readAddress(0, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "ID cannot be empty");
        }
    }

//  positive case to read all record using id
    @Test(dataProvider = "testReadAllRecord_positiveDP")
    private void testReadAllRecord_positive(String tableName, String expectedResult) {

      try {

          String actualResult = addressService.readAllAddress(tableName, conn);
          Assert.assertEquals(actualResult, expectedResult);
          conn.commit();
      } catch (Exception e) {
          Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
      }
    }

    @DataProvider
    private Object[][] testReadAllRecord_positiveDP() {

      return new Object[][] {
          {"address", "[1Mint streetMadras600235]"}
      };
    }

//  negative case to read all record using id
    @Test
    private void testReadAllRecord_negative() {

        try {

            addressService.readAllAddress(null, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
      } catch (Exception e) {
          Assert.assertEquals(e.getMessage(), "Table Not Exists");
      }
    }

//    positive case to delete a record
    @Test(dataProvider = "testDeleteRecord_positiveDP")
    private void testDeleteRecord_positive(long id, long expectedResult) {

        try {

            long actualResult = addressService.deleteAddress(id, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testDeleteRecord_positiveDP() throws SQLException{
        return new Object[][] {
            {2, 2}
        };
    }

//    negative case to delete a record
    @Test
    private void testDeleteRecord_negative() {

        try {

            addressService.deleteAddress(0, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Id cannot be null");
        }
    }

    @AfterClass
    private void closeConnection() {
        txn.closeConnection();
    }
}
