package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.text.ParseException;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class PersonServiceTest {

    PersonService personService;
    ConnectionManager txn = new ConnectionManager();
    Connection conn = txn.openConnection("jdbc:mysql://pc1620:3306/agrasha_janarthanan?useSSL=false&user=agrasha_janarthanan&password=demo");

    @BeforeClass
    private void initialize() {
        personService = new PersonService();
    }

    @Test(dataProvider = "testCreateRecord_positiveDP")
    private void testCreateRecord_positive(Person person, Address address, int expectedResult) {

        try {

            int actualResult = personService.createPerson(person, address, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testCreateRecord_positiveDP() throws ParseException {
        return new Object[][] { 
                                { new Person ("agi", "agi@gmail.com", Date.valueOf("08-08-1996"), 1 ), new Address ("Mint street", "Chennai", 600345), 1},
                                { new Person ("agrasha", "agrasha@gmail.com",Date.valueOf("09-08-1996"), 2), new Address ("Car street", "Tiruvannamalai", 606601), 2}
        };
    }

    @Test(dataProvider = "testCreateRecord_negativeDP")
    private void testCreateRecord_negative(Person person, Address address) {

        try {

            personService.createPerson(person, address, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Email already exists");
        }
    }

    @DataProvider
    private Object[][] testCreateRecord_negativeDP() throws ParseException {
        return new Object[][] { 
                                { new Person ("agrasha", "agrasha@gmail.com", Date.valueOf("08-08-1996"), 2)
                                  , new Address ("Car street", "Tiruvannamalai", 606601)
                                }
        };
    }

    @Test(dataProvider = "testUpdateRecord_positiveDP")
    private void testUpdateRecord_positive(String condition, int expectedResult) {

        try {

            int actualResult = personService.updatePerson(condition, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testUpdateRecord_positiveDP() {
        return new Object[][] { 
                                {"city = Chennai", 1}
                              };
    }

    @Test
    private void testUpdateRecord_negative() {

        try {

            personService.updatePerson("", conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Cannot update without condition");
        }
    }

    @Test(dataProvider = "testReadRecord_positiveDP")
    private void testReadRecord_positive(long id, boolean includeAddress, String expectedResult) {

        try {

            String actualResult = personService.readPerson(id, includeAddress, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testReadRecord_positiveDP() {
        return new Object[][] { {1, true, "agrasha,agi@gmail.com,08-08-1996,Mint street,Chennai,600345"},
                                {2, true, "agrasha,agrasha@gmail.com, 09-08-1996,Car street,Tiruvannamalai,606601"}
        };
    }

    @Test
    private void testReadRecord_negative() {

        try {

            personService.readPerson(0, true, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "ID cannot be empty");
        }
    }

    @Test(dataProvider = "testReadAllRecords_positiveDP")
    private void testReadAllRecords_positive(String tableName, boolean includeAddress, String expectedResult) {
        try {

            String actualResult = personService.readAllPerson(tableName, includeAddress, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testReadAllRecords_positiveDP() {
        return new Object[][] { {"person", true, }
            
        };
    }

    @Test
    private void testReadAllRecords_negative() {

        try {

            personService.readAllPerson("myPerson", false, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Table Not found");
        }
    }

    @Test(dataProvider = "testDeleteRecord_positiveDP")
    private void testDeleteRecord_positive(long id, int expectedResult) {
        try {

            long actualResult = personService.deletePerson(id, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is \" + expectedResult + e");
        }
    }

    @DataProvider
    private Object[][] testDeleteRecord_positiveDP() {
        return new Object[][] { {1, 0},
                                {2, 0}
        };
    }

    @Test
    private void testDeleteRecord_negative() {

        try {

            personService.deletePerson(0, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Cannot delete without condition");
        }
    }

    @AfterClass
    private void closeConnection() {
        txn.closeConnection();
    }
}
