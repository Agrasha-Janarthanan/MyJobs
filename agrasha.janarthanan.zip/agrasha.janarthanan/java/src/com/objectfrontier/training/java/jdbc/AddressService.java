package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;

public class AddressService {

    public int createAddress(Address address, Connection conn) throws Exception {

        StringBuilder sb = new StringBuilder();
        int generatedKey = 0;
            if (address.pincode == 0) {
                throw new RuntimeException("Pincode cannot be null");
            }
    
            sb.append("INSERT INTO address (street, city, pincode)");
            sb.append("VALUES (?, ?, ?)");
            PreparedStatement statement = (PreparedStatement) conn.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, address.street);
            statement.setString(2, address.city);
            statement.setInt(3, address.pincode);
            statement.executeUpdate();
            ResultSet generatedKeys = statement.getGeneratedKeys();
            if ((generatedKeys != null) && (generatedKeys.next())) {
                generatedKey = generatedKeys.getInt(1);
            }
        return generatedKey; 
    }

    public int updateAddress(long id, Connection conn) throws SQLException {

        StringBuilder sb = new StringBuilder();
        int rowsUpdated = 0;

        if (id == 0) {
            throw new RuntimeException("Cannot update without id");
        }
            sb.append("UPDATE address SET city = 'Chennai' WHERE id = ");
            sb.append(id);
            PreparedStatement statement = (PreparedStatement) conn.prepareStatement(sb.toString());
            rowsUpdated = statement.executeUpdate();
        return rowsUpdated;
    }

    public String readAddress(long id, Connection conn) throws Exception {

        if (id == 0) {
            throw new RuntimeException("ID cannot be empty");
        }

        String query = "SELECT id, street, city, pincode FROM address WHERE id = " + id;
        PreparedStatement statement = (PreparedStatement) conn.prepareStatement(query);
        ResultSet result = statement.executeQuery();
        result.next();
        Address address = new Address();
        address.setId(result.getLong("id"));
        address.setStreet(result.getString("street"));
        address.setCity(result.getString("city"));
        address.setPincode(result.getInt("pincode"));
        String resultRecord = address.getId() + "," 
                                              + address.getStreet() 
                                              + "," 
                                              + address.getCity() 
                                              + "," 
                                              + address.getPincode();
        return resultRecord;
    }

    public String readAllAddress(String tableName, Connection conn) throws Exception {

        if (tableName == null) {
            throw new RuntimeException("Table Not Exists");
        }

        StringBuilder sb = new StringBuilder();
        List<String> resultRecords = new ArrayList<>();
        String resultant = null;
        sb.append("SELECT id, street, city, pincode FROM ");
        sb.append(tableName);
        PreparedStatement statement = (PreparedStatement) conn.prepareStatement(sb.toString());
        ResultSet result = statement.executeQuery();

        while (result.next()) {

            Address address = new Address();
            address.setId(result.getLong("id"));
            address.setStreet(result.getString("street"));
            address.setCity(result.getString("city"));
            address.setPincode(result.getInt("pincode"));
            String resultRecord = address.getId() + address.getStreet() + address.getCity() + address.getPincode();
            resultRecords.add(resultRecord);
            resultant = resultRecords.toString();
        }
        return resultant;
    }

    public long deleteAddress(long id, Connection conn) throws SQLException {

        StringBuilder sb = new StringBuilder();
        if (id == 0) {
            throw new RuntimeException("Id cannot be null");
        }
        sb.append("DELETE FROM address WHERE id = " + id);
        PreparedStatement statement = (PreparedStatement) conn.prepareStatement(sb.toString());

        statement.executeUpdate();
        return id;
    }
}
