package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.ofs.training.Person.Sex;;

public class AverageAgeCalculator {

    public double calculateAverageAgeToDouble(List<Person> personList) {

        List<Person> roster = Person.createRoster();
        double averageAge = roster.stream()
                                  .filter(personList -> person.getGender() == Person.Sex.MALE)
                                  .mapToInt(Person::getAge)
                                  .average()
                                  .getAsDouble();
        return averageAge;
    }

    public int calculateAverageAgeToInt(List<Person> person) {

        List<Person> roster = Person.createRoster();
        int averageAge = roster.stream()
                               .filter(person -> person.getGender() == Person.Sex.MALE)
                               .mapToInt(Person::getAge)
                               .average()
                               .getAsInt();
        return averageAge;
    }

    public static void main(String[] args) {
        AverageAgeCalculator calculator = new AverageAgeCalculator();
        calculator.run();
    }

    public void run() {

        double averageAgeAsDouble = calculateAverageAgeToDouble(List<Person> people);
        int averageAgeAsInt = calculateAverageAgeToInt(List<Person> people);
        System.out.println(averageAgeAsDouble);
        System.out.println(averageAgeAsInt);
    }
}