package com.ofs.training;

// class ClassFileViewer {
public class ClassFileViewer {

    // static void execute() {
    public static void main(String[] args) throws Exception {

        // ClassFileViewer currentProgram = getCurrentProgram();
        ClassFileViewer currentProgram = new ClassFileViewer();

        // String currentClass = currentProgram.getClass() + ".java";
        String currentClass = currentProgram.getClass().getName() + ".java";

        // Console console = getConsole()........
        // console.print(currentClass);
        String[] cmdArray = new String[2];
        // cmdArray[0] = "start";
        cmdArray[0] = "notepad.exe";
        cmdArray[1] = currentClass;
        Process process = Runtime.getRuntime().exec(cmdArray,null);
    }
}
