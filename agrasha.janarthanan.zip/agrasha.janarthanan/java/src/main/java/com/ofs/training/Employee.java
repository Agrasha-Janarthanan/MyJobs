package com.ofs.training;

import java.util.ArrayList;

public class Employee {

    private static int count;
    private int id;
    private String name;

    Employee(String name) {
        this.id = ++count;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Employee id=" + id + " name=" + name + "\n";
    }

    public static void main(String[] args) {

        ArrayList<Employee> employeeDetails = new ArrayList<>();

        employeeDetails.add(new Employee ("Jai"));
        employeeDetails.add(new Employee ("Viya"));
        employeeDetails.add(new Employee ("Tamil"));
        employeeDetails.add(new Employee ("Kayal"));
        employeeDetails.add(new Employee ("Venba"));
        employeeDetails.add(new Employee ("Riya"));
        employeeDetails.add(new Employee ("Yalini"));
        employeeDetails.add(new Employee ("Mughil"));
        employeeDetails.add(new Employee ("Ayshu"));
        employeeDetails.add(new Employee ("Surya"));
        System.out.println(employeeDetails);
        System.out.println(employeeDetails);
    }
}
