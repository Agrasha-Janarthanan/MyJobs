package com.ofs.training;

// class StringConcatenator {
public class StringConcatenator {

    // static void main(String[] args) {
    public static void main(String[] args) {

        String hi = "Hi, ";
        String mom = "mom.";

        // Console console = getConsole();
        // console.print(concatenateByMethod(hi,mom));
        System.out.println(hi.concat(mom));

        // console.print(concatenateByOperator(hi,mom));
        System.out.println(hi+mom);
    }
}
