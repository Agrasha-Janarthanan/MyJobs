package com.ofs.training;

public class MultipleAdder {

    private static final String ERR_NOT_ENOUGH_VALUES = "Requires more than one input";

    public int add(String[] numbers) {

        int totalValue = numbers.length;
        int sum = 0;

        if (totalValue < 2) {
            throw new RuntimeException(ERR_NOT_ENOUGH_VALUES);
        } else {
            for (int index = 0; index < totalValue; index++) {
                sum += Integer.valueOf(numbers[index]).intValue();
            }
        }
        return sum;
    }

    public static void main(String[] args) {

        String[] values = args;
        MultipleAdder integerAdder = new MultipleAdder();
        int result = integerAdder.add(values);
        System.out.println("Sum of the given values are : " + result);
    }
}
