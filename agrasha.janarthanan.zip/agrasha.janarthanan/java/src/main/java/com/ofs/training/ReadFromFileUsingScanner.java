package com.ofs.training;

import java.io.File;
import java.util.Scanner;

public class ReadFromFileUsingScanner {

    public void readFile(File inputFile) throws Exception{

        Scanner sc = new Scanner(inputFile);
        while (sc.hasNextLine())
            System.out.println(sc.nextLine());
        sc.close();
    }

    public static void main(String[] args) {

        ReadFromFileUsingScanner readFromFile = new ReadFromFileUsingScanner();
        readFromFile.run();
    }

    public void run() {

        File file = new File("test.txt");
        readFromFile.readFile(file);
    }
}
