package com.ofs.training;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class ReadFileUsingReader {

    InputStream inputStream       = new FileInputStream("input.txt");
    Reader inputStreamReader = new InputStreamReader(inputStream);

    int data = inputStreamReader.read();
    while(data != -1) {
        char theChar = (char) data;
        data = inputStreamReader.read();
        System.out.print(data);
    }

    inputStreamReader.close();
}
