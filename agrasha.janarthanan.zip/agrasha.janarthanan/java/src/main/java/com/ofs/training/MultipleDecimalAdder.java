package com.ofs.training;

public class MultipleDecimalAdder {

    public static void main(String[] args) {

        int count = args.length;

        if(count < 2) {

            System.out.println("Requires more than one input");
        } else {

            Float sum = 0.0f;
            for(int index = 0; index < count; index++) {

                sum += Float.valueOf(args[index]).floatValue();
            }

            System.out.println("The Sum of the given values : " + sum);
        }
    }
}
