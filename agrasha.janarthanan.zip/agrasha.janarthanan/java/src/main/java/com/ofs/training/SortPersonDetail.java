package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;

public class SortPersonDetail {

    public void sortPersonByAge(List<Person> personList) {
        List<Person> roster = personList.sort((r1, r2) -> r1.getAge().compareTo(r2.getAge()));
        roster.forEach((roster) -> System.out.println(roster));
    }

    public static void main(String[] args) {

        SortPersonDetail sortPerson = new SortPersonDetail();
        sortPerson.run();
    }

    public void run() {
        List<Person> people = Person.createRoster();
        sortPerson.sortPersonByAge(people);
    }
}
