package com.ofs.training;

public class ExceptionExample {

    public static void main(String[] args) {

        int number = 10;
        int divider = 0;
        int result;

        try {
            if (divider != 0) {
                result = number / divider;
                System.out.println("The Result is: " + result);
            } else {
                throw new Exception("Divided by Zero");
            }
        } catch (Exception exp) {
            System.out.println("The divider is Zero");
        }
    }
}
