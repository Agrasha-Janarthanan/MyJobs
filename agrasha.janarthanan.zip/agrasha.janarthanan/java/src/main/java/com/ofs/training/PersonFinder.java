package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.ofs.training.Person.Sex;

public class PersonFinder {

    private static Stream<Person> extractStream(List<Person> personList) {
        return personList.stream()
                         .filter(person -> person.getGender() == Sex.MALE);
    }

    private static Person findFirstPerson(List<Person> personList) {
        Person people = extractStream(personList).findFirst()
                                                 .get();
        return people;
    }


    private static Person findLastPerson(List<Person> personList) {
        List<Person> people = personList.stream()
                                        .filter(person -> person.getGender() == Sex.MALE)
                                        .collect(Collectors.toList());
        return people.get(personList.size() - 1);
    }

    private static Person findRandomPerson(List<Person> personList) {
        Person people = extractStream(personList)
                                  .findAny()
                                  .get();
        return people;
    }

    public static void main(String[] args) {
        PersonFinder personFinder = new PersonFinder();
        personFinder.run();
    }

    private void run() {
        List<Person> roster = Person.createRoster();
        System.out.println(findFirstPerson(roster));
        System.out.println(findRandomPerson(roster));
        System.out.println(findLastPerson(roster));
    }
}
