package com.ofs.training;

import java.util.ArrayList;
import java.util.List;
 
public class PrintPersonDetail {

    public void printDetail(List<Person> personList) {

        Iterator<Person> itr=list.iterator();
        while(itr.hasNext())
        {
            System.out.println(itr.next());
        }
    }

    public static void main(String[] args) {
        PrintPersonDetail printPersonDetail = new PrintPersonDetail();
        printPersonDetail.run();
    }

    public void run() {
        printPersonDetail.printDetail(List<Person> person);
    }
}
