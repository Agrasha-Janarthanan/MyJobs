package com.ofs.training;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

// class MyJava
public class MyJava {

    // static void execute() {
    public static void main(String[] args) throws InstantiationException, 
                                                  IllegalAccessException, 
                                                  ClassNotFoundException, 
                                                  NoSuchMethodException, 
                                                  SecurityException, 
                                                  IllegalArgumentException, 
                                                  InvocationTargetException {

        // checkArgumentsLength();
        if(!(args.length == 1)) {

            System.out.println("More or less than one argument is not allowed");
            return;
        }

        // String fileName = getfileName();
        String fileName = args[0];

        // checkClassExecute();
        try {

            // Class className = convertToName(fileName);
            Class<?> myClassName = Class.forName(fileName); 

            // String method = "execute()";
            String myMethod = "main";

            // invoke(myMethod);
            Method myMainMethod = myClassName.getMethod(myMethod, String[].class);
            String[] arguments = null;
            myMainMethod.invoke(myClassName, (Object) arguments);
        } catch(ClassNotFoundException exception) {

            System.out.println(exception); 
        } catch(NoSuchMethodException exception) {

            System.out.println(exception); 
        }
    }
}
