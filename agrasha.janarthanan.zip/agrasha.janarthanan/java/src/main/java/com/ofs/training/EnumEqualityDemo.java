package com.ofs.training;

public class EnumEqualityDemo {

    enum Continent {
        ASIA,
        AFRICA,
        EUROPE,
        NORTH_AMERICA,
        SOUTH_AMERICA,
        ARTIC,
        ANTARTIC;
    }

    private static final String ERR_NO_VALUES = "No values found";
    private static final String ERR_NO_SIMILAR_VALUES = "No similar values found";

    public boolean checkValueEquality(Continent continent1,Continent continent2 ) {

        try {
            boolean result = continent1.equals(continent2);
            return result;
        } catch(Exception e) {

            throw new RuntimeException(ERR_NO_VALUES);
        }
    }

    public boolean checkObjectEquality(Continent continent1,Continent continent2 ) {

        if ((continent1 == null) | (continent2 == null)) {
            throw new RuntimeException(ERR_NO_SIMILAR_VALUES);
        }
        boolean equalityResult = (continent1 == continent2);
        return equalityResult;
    }

    public static void main(String[] args) {

        EnumEqualityDemo demo = new EnumEqualityDemo();
        Continent continent = Continent.ASIA;
        Continent westContinent = Continent.ASIA;

        boolean myResult = demo.checkValueEquality(continent,westContinent);
        boolean myEqualityResult = demo.checkObjectEquality(continent,westContinent);

        System.out.println(myResult);
        System.out.println(myEqualityResult);
        
    }
}
