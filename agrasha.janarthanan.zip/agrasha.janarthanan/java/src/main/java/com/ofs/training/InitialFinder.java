package com.ofs.training;

// class InitialFinder {
public class InitialFinder {

    private static final String ERR_NOT_A_STRING = "Unable to compute initial for empty string";

    //compute the initials of given name
    public String computeInitial(String userName){

        if (userName == "") {
            throw new RuntimeException(ERR_NOT_A_STRING);
        }

        // String name = fullname.getSubString();
        String[] names = userName.split(" ");

        StringBuilder sb =new StringBuilder();

        // String initial = name.getFirstLetter();
        System.out.println("The Initial of " + userName + " is :");
        for (int index = 0; index < names.length; index++) {
            char initial = names[index].charAt(0);
            sb.append(initial);
        }
        return sb.toString();
    }
    // static void execute() {
    public static void main(String[] args) {

        // String fullname = getName();
        String fullName = "Agrasha Janathanan";

        //Create object for the class
        InitialFinder myInitial = new InitialFinder();
        System.out.println(myInitial.computeInitial(fullName)); 
    }
}
