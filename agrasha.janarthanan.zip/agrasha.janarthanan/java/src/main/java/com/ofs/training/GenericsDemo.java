package com.ofs.training;

import java.util.ArrayList;

public class GenericsDemo {

    ArrayList<String> employeeList= new ArrayList<>();

    String employeeName = "anitha";
    employeeList.add(employeeName);
}
