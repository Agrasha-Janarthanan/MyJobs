package com.ofs.training;

// class Fibinocci {
public class Fibinocci {
    static int num1 = 0;
    static int num2 = 1;
    static int num3;

    // static void execute() {
    public static void main(String[] args) {

        // Console console = getConsole()....
        // console.print("Fibinocci using while loop");
        System.out.println("Fibinocci using while loop");

        // Fibinocci fibinocci = fibinocciGenerator();
        Fibinocci fibinocci = new Fibinocci();
        fibinocci.fibinocciGenerator();

        // console.print("Fibinocci using for loop");
        System.out.println("Fibinocci using for loop");

        // Fibinocci fibinocci = fibinocciSeries();
        Fibinocci myFibinocci = new Fibinocci();
        myFibinocci.fibinocciSeries();

        // console.print("Fibinocci using recursion");
        System.out.println("Fibinocci using recursion");

        // Fibinocci fibinocci = printFibinocci();
        Fibinocci fibinocciObject = new Fibinocci();
        System.out.println(num1);
        System.out.println(num2);
        fibinocciObject.printFibinocci(10);
    }

    public void fibinocciGenerator() {

        int firstNum = 0;
        int secondNum = 1;
        int count = 10;
        int position = 0;
        int nextNum;

        System.out.println(firstNum);
        System.out.println(secondNum);

        while (position < count) {
            nextNum = firstNum + secondNum;
            System.out.println(nextNum);
            firstNum = secondNum;
            secondNum = nextNum;
            position++;
        }
    }

    public void fibinocciSeries() {

        int number1 = 0;
        int number2 = 1;
        int limit = 10;
        int result;

        System.out.println(number1);
        System.out.println(number2);

        for (int index = 2; index < limit; index++) {
            result = number1 + number2;
            System.out.println(result);
            number1 = number2;
            number2 = result;
        }
    }

    public void printFibinocci(int bound) {

        if (bound > 0) {
            num3 = num1 + num2;
            System.out.println(num3);
            num1 = num2;
            num2 = num3;
            printFibinocci(bound - 1);
        }
    }
}
