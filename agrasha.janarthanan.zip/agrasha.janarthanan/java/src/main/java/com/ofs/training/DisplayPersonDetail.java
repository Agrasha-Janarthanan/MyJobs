package com.ofs.training;

import java.util.ArrayList;
import java.util.List;
 
public class DisplayPersonDetail {

    public void displayDetail(List<Person> personList) {
        for (String str : personList) {
            System.out.println(str);
        }
    }

    public static void main(String[] args) {
        DisplayPersonDetail displayPersonDetail = new DisplayPersonDetail();
        displayPersonDetail.run();
    }

    public void run() {
        List<Person> person= person.createRoster(); 
        displayPersonDetail.displayDetail(List<Person> person);
    }
}
