package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;

public class SortPerson {

    public void sortByAge(List<Person> personList) {

        List<Person> person = personList.stream()
                                        .sorted(Comparator.reverseOrder())
                                        .collect(Collectors.toList());
        person.forEach((person) -> System.out.println(roster));
    }

    public static void main(String[] args) {

        SortPerson sortPerson = new SortPerson();
        sortPerson.run();
    }

    public void run() {

        List<Person> roster = roster.createRoster();
        sortPerson.sortByAge(roster);
    }
}
