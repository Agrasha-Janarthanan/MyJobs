package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;

public class PersonDetail {


    private static List<String> displayDetails(List<Person> people) {

        List<String> minimalPerson = people.stream()
                                           .map(person -> (person.getName(), person.getEmail()))
                                           .collect(Collectors.toList());
        return minimalPerson;
    }

    public static void main(String[] args) {

        PersonDetail personDetail = new PersonDetail();
        personDetail.run();
    }

    private void run() {

        List<Person> roster = Person.createRoster();
        List<String> minimalPersonDetail = PersonDetail.displayDetails(roster);
        log(minimalPersonDetail);
    }

    private void log(List<String> minimalPersonDetail) {
        System.out.format("Person Details %n Name : %s", minimalPersonDetail);
    }
}
