package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class MultipleAdderTest {

    MultipleAdder multipleAdder;
    
    @BeforeClass
    private void initialize() {
            
        multipleAdder = new MultipleAdder();
    }
    
    @Test(dataProvider = "testAdd_positiveDP")
    private void testAdd_positive(String[] numbers, int expectedSum) {
        
        try {
            
            int actualSum = multipleAdder.add(numbers);
            Assert.assertEquals(expectedSum, actualSum, "Given Input : " + numbers);
        } catch(Exception e) {
            
            Assert.fail("Unexpected result for input"
                        + numbers
                        + "Expected result"
                        + expectedSum
                        + e
                       );
        }    
    }

    @Test(dataProvider = "testAdd_negativeDP")
    private void testAdd_negative1(String[] numbers) {
        
        try {
            
            multipleAdder.add(numbers);
            Assert.fail("Exception is expected");
        } catch(Exception e) {
            
            Assert.assertEquals(e.getMessage(),"Requires more than one input");
        }
    }

    @DataProvider
    private Object[][] testAdd_positiveDP() {
        return new Object[][] {
                                { new String[] {"5", "10", "15"} ,30},
                                { new String[] {"15", "10", "15"} ,40},
        };
    }
    
    @DataProvider
    private Object[][] testAdd_negativeDP() {
        return new Object[][] {
                                { new String[] {"10"}},
                                { new String[] {""}},
        };
    }

    
    @AfterClass
    private void afterClass() {

    }  
}
