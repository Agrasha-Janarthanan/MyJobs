package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class StringArraySorterTest {
    
    StringArraySorter arraySorter;
    
    @BeforeClass
    private void initialize() {
        
        arraySorter = new StringArraySorter();
    }

    @Test (dataProvider = "testStringSort_positiveDP")
    private void testStringSort_positive1(String[] cities, String[] expectedOutput) {
        
        try {
            
            String[] actualOutput = arraySorter.stringSort(cities);
            Assert.assertEquals(actualOutput, expectedOutput, "Given Input" + cities);
        } catch (Exception e) {
            
            Assert.fail("Unexpected exception for input "
                        + cities
                        + "Expected result is "
                        + expectedOutput
                        + ".",
                        e);
        }
     }
    
    @Test(dataProvider = "testStringUpperCaseConvert_positiveDP")
    private void testStringUpperCaseConvert_positive(String[] sortedArray, String[] expectedOutput) {

        try {
        
            String[] actualOutput = arraySorter.stringUpperCaseConvert(sortedArray);
            Assert.assertEquals(actualOutput, expectedOutput, "Given Input" + sortedArray);
        } catch (Exception e) {
            
            Assert.fail("Unexpected exception for input "
                    + sortedArray
                    + "Expected result is "
                    + expectedOutput
                    + ".",
                    e);
        }
    }
    
    @Test
    private void testStringSort_negative() {
        
        try {

            arraySorter.stringSort(null);
            Assert.fail("Expected an exception");
        } catch (Exception e) {
            
            Assert.assertEquals(e.getMessage(), "The Input String is null");            
        }
    }
    
    @Test
    private void testStringUpperCaseConvert_negative() {

        try {

            arraySorter.stringUpperCaseConvert(null);
            Assert.fail("Expected an exception");
        } catch (Exception e) {
            
            Assert.assertEquals(e.getMessage(), "The Input String is null");            
        }
    }
    
    @DataProvider
    private Object[][] testStringSort_positiveDP() {
        return new Object[][] {
                                { new String [] { "Madurai",
                                                  "Thanjavur",
                                                  "TRICHY",
                                                  "Karur",
                                                  "Erode",
                                                  "trichy",
                                                  "Salem" 
                                                 },
                                   new String[]  { "Erode",
                                                   "Karur",
                                                   "Madurai",  
                                                   "Salem",
                                                   "Thanjavur",
                                                   "TRICHY",
                                                   "trichy"
                                                 }
                                },
                                {  new String[] { "Rameshwaram",
                                                  "Tiruvannamalai",
                                                  "Kanchipuram",
                                                  "Chidambaram",
                                                  "KAASI", 
                                                },
                                   new String[] { "Chidambaram",
                                                  "KAASI", 
                                                  "Kanchipuram",
                                                  "Rameshwaram",
                                                  "Tiruvannamalai",
                                                }
                                }
        };
    }
    
    @DataProvider
    private Object[][] testStringUpperCaseConvert_positiveDP() {
        return new Object[][] {
                                { new String[]  { "Erode",
                                                  "Karur",
                                                  "Madurai",
                                                  "Salem",
                                                  "Thanjavur",
                                                  "TRICHY",
                                                  "trichy"
                                                 },           
                                   new String[]  { "ERODE",
                                                   "Karur",
                                                   "MADURAI",
                                                   "Salem",
                                                   "THANJAVUR",
                                                   "TRICHY",
                                                   "TRICHY"
                                                 }
                                },
                                {  new String[] { "Chidambaram",
                                                  "KAASI", 
                                                  "Kanchipuram",
                                                  "Rameshwaram",
                                                  "Tiruvannamalai",
                                               },
                                   new String[] { "CHIDAMBARAM",
                                                  "KAASI", 
                                                  "KANCHIPURAM",
                                                  "Rameshwaram",
                                                  "TIRUVANNAMALAI",
                                                 }
                                }
        };
    }
    
    @AfterClass
    private void afterClass() {
        
    }
}
