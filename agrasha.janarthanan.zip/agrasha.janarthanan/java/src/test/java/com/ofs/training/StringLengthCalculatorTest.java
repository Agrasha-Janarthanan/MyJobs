package com.ofs.training;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

@Test
public class StringLengthCalculatorTest {
    
    StringLengthCalculator myCalculator = new StringLengthCalculator();
    
    @BeforeClass
    private void init() {
        myCalculator = new StringLengthCalculator();
    }
    
    @Test
    private void testStringOperation_positive() {
        
    }
    
    @Test
    private void testStringLength_positive() {
        
    }
    
    @Test
    private void testStringOperation_negative() {
        
    }
    
    @Test
    private void testStringLength_negative() {
        
    }

    @AfterClass
    private void afterClass() {
        
    }
}
