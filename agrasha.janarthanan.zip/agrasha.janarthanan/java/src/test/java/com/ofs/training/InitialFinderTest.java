package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class InitialFinderTest {
	
	InitialFinder myInitial;
	
	@BeforeClass
	private void initialize() {
		
		myInitial = new InitialFinder();
	}
	
	@Test
	private void testComputeInitial_positive(String name, String expectedOutput) {

        try {
            String actualOutput = myInitial.computeInitial(name);
            Assert.assertEquals(actualOutput, expectedOutput, "Given input " + name);
        } catch (Exception e) {
            Assert.fail("Unexpected exception for input "
                        + name
                        + "Expected result is "
                        + expectedOutput
                        + e);
        }
    }
	
	@DataProvider
    private Object[][] testComputeInitial_PositiveDP() {
        return new String[][] {
                                {"Lalitha Janarthanan", "LJ"},
                                {"Agrasha", "A"}
                              };
	}	 
	@Test
	private void testComputeInitial_negative1() {
				
		try {
			myInitial.computeInitial("");
			Assert.fail("Expected an exception");
		} catch (Exception e) {
			
			Assert.assertEquals(e.getMessage(),"Unable to compute initial for empty string");
		}
	}
}
