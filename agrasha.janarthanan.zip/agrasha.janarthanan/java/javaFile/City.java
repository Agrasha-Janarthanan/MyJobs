import java.util.Arrays;

class City {

    public static void main(String[] args) {

        String[] corporation = { "Madurai",
                                 "Thanjavur",
                                 "TRICHY",
                                 "Karur",
                                 "Erode",
                                 "trichy",
                                 "Salem" };

        Arrays.sort(corporation, String.CASE_INSENSITIVE_ORDER);

        for (int index = 0; index < corporation.length ; index++) {
            System.out.println(corporation[index]);
        }

        for (int position = 0; position < corporation.length ; position++) {
            if (position % 2 == 0) {
                System.out.println("Even Indexed Strings" + corporation[position].toUpperCase());
            }
        }
    }
}
