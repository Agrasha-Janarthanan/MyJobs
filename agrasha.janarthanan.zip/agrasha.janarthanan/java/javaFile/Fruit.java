import java.util.Arrays;

class Fruit {

    public static void main(String ... args) {

        System.out.println("No.of Fruits" + args.length);

        for (String fruitName : args) {
            System.out.println("Displaying the names of fruits " + fruitName);
        }
    }
}
