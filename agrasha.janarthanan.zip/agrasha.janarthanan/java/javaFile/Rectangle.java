public class Rectangle {

    static int width;
    static int height;

    int area(int length, int breadth) {

        int area = length * breadth;
        return area;
    }

    public static void main(String[] args) {

        Rectangle myRect = new Rectangle();
        myRect.width = 40;
        myRect.height = 50;

        System.out.println("myRect's area is " + myRect.area(myRect.width,myRect.height));
    }
}
