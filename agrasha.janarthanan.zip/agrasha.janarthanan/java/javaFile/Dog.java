class Animal{
	int legs;
	Animal(){
		this.legs = 2;
	}
	public void run(int legs){
		System.out.println("Animal runs with " + legs + " legs");
	}
}

class Dog extends Animal{
	String breed;
	void myBreed(String breed){
		System.out.println("Dog of breed " + breed + " with " + legs + " legs");
	}
	public static void main (String [] args){
		Dog sam = new Dog();
		sam.run(4);
		sam.myBreed("Retriver");
	}
}



