//class MyJavaP
public class MyJavaP {

	//static void execute() {
	public static void main(String[] args) {
		
		//checkArgumentsLength();
		if(!(args.length == 1)){
			
			System.out.println("More or less than one package is not allowed");
			return;
		}
		
		//String package = getPackage();
		String myPackage = args[0];
		System.out.println(myPackage);
		
		//Class class = getClass();
		String[] myString = myPackage.split(".",0);
		System.out.println(myString);
		int index = myString.length - 1;
		System.out.println(index);
		String myClass = myString[index];
		System.out.println(myClass);
	}

}
