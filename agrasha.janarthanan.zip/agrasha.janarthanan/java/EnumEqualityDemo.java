class EnumEqualityDemo {

    enum Continent {
        ASIA,
        AFRICA,
        EUROPE,
        NORTH_AMERICA,
        SOUTH_AMERICA,
        ARTIC,
        ANTARTIC;
    }
    enum FourContinent {
        ASIA,
        AFRICA,
        EUROPE,
        AMERICA;
    }

    public static void main(String[] args) {

        Continent continent = Continent.ASIA;
        Continent westContinent = Continent.ASIA;
        FourContinent first = FourContinent.ASIA;

        System.out.println(continent.equals(first));
        System.out.println(continent.equals(westContinent));

        boolean myContinent = (continent == westContinent);
        System.out.println(myContinent);
    }
}
