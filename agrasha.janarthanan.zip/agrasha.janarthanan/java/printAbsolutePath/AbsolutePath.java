import java.io.File;

class AbsolutePath {

    public void getClassName(){

        File file = new File(this.getClass().getSimpleName());
        String filePath = file.getAbsolutePath();

        System.out.println("This is the absolute path: " + filePath);
    }

    public static void main(String[] args) {

        AbsolutePath path = new AbsolutePath();
        path.getClassName();
    }
}
