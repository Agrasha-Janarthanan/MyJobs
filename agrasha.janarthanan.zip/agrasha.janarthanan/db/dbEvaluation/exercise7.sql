CREATE VIEW edu_student_fee AS 
									 SELECT roll_number, stu_name, semfee.cdept_id, semester
									 		  , amount, paid_year, paid_status
									 FROM edu_semester_fee AS semfee
									 JOIN edu_student AS stu ON semfee.stud_id = stu.stu_id;

SELECT * FROM edu_student_fee;

UPDATE edu_student_fee SET paid_status = "paid" , paid_year = 2018 
							  WHERE roll_number = "ueacs003";

UPDATE edu_student_fee SET paid_status = "paid" , paid_year = 2018 
							  WHERE roll_number 
							  IN ( "nitcs01", "vitec04", "sbuft04", "sbuft05" 
							       "srmte01", "srmte05") ;
 