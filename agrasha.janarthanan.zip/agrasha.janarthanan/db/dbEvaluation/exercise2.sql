CREATE VIEW edu_dept_list AS 
								  SELECT dept_id, dept_name
								  FROM edu_department AS dept
								  JOIN edu_college_department AS cdept ON dept.dept_code = cdept.udept_code;
 
SELECT   roll_number, stu_name, gender, stu_dob, stu_email, stu_phone
         , stu_address, college_name, dept_name, city
         FROM edu_student AS stu
         JOIN edu_college AS coll ON stu.college_id = coll.id
         JOIN edu_university AS univ ON univ.code = coll.univ_code
         JOIN edu_dept_list AS dept ON stu.cdept_id = dept.dept_id
         JOIN edu_semester_result AS semres ON stu.stu_id = semres.stud_id
         WHERE semester=8 AND univ.code = "u003";
