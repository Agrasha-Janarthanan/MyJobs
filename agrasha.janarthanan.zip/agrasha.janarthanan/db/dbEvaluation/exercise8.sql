SELECT desig_name, rank, college_name, dept_name, `code`, `name`
       FROM edu_designation AS desig
       JOIN edu_employee AS emp ON desig.id NOT IN (emp.desig_id)
       JOIN edu_college AS coll ON emp.cdept_id = coll.
		 JOIN edu_university AS univ ON coll.univ_code = univ.code
		 JOIN edu_department AS dept ON univ.code = dept.univ_code
		 WHERE emp.desig_id NOT IN (desig.id);     
		 

SELECT * FROM edu_employee;
SELECT * FROM edu_designation;
SELECT * FROM edu_professor_syllabus;	
SELECT * FROM edu_department;
SELECT * FROM edu_college;
SELECT * FROM edu_college_department;
SELECT * FROM edu_syllabus;

SELECT syllabus_code, syllabus_name, syll.cdept_id
		 , dept_name, college_name, `name`
		 FROM edu_syllabus AS syll
		 JOIN edu_college_department AS cdept ON cdept.dept_id = syll.cdept_id	
		 RIGHT JOIN edu_department AS dept ON dept.dept_code = cdept.udept_code
		 RIGHT JOIN edu_college AS coll ON coll.id = cdept.college_id
		 JOIN edu_university AS univ ON univ.code = coll.univ_code
		 JOIN edu_employee AS emp ON emp.cdept_id = cdept.dept_id		

SELECT * FROM edu_employee as emp  JOIN edu_college_department as cd ON cd.dept_id=emp.cdept_id
											  RIGHT JOIN edu_college as col ON col.id=emp.college_id	
                                   RIGHT  JOIN edu_department as dep ON dep.dept_code=cd.udept_code
                                   
SELECT * FROM edu_designation as desig  
          JOIN edu_employee AS emp 
			 JOIN edu_college_department as cd ON cd.dept_id=emp.cdept_id 
			 RIGHT JOIN edu_college as col ON col.id=emp.college_id	
          RIGHT  JOIN edu_department as dep ON dep.dept_code=cd.udept_code
		                                




		 
