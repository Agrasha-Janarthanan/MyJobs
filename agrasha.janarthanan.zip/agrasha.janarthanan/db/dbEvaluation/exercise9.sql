 SELECT SUM(amount) , paid_status, univ.name	
		 FROM edu_semester_fee AS semfee
		 JOIN edu_student AS stud ON stud.stu_id = semfee.stud_id
		 JOIN edu_college AS coll ON coll.id = stud.college_id 
		 JOIN edu_university AS univ ON univ.code = coll.univ_code 	 
		 WHERE  univ_code = "u001" AND semester = 2
		 GROUP BY paid_status HAVING SUM(amount);
		 
SELECT SUM(amount) AS collected_fee, univ.name
		 FROM edu_semester_fee AS semfee
		 JOIN edu_student AS stud ON stud.stu_id = semfee.stud_id
		 JOIN edu_college AS coll ON coll.id = stud.college_id 
		 JOIN edu_university AS univ ON univ.code = coll.univ_code 
		 WHERE paid_status = "paid" AND univ_code = "u001";

SELECT SUM(amount) AS collected_fee,  univ.name
		 FROM edu_semester_fee AS semfee
		 JOIN edu_student AS stud ON stud.stu_id = semfee.stud_id
		 JOIN edu_college AS coll ON coll.id = stud.college_id 
		 JOIN edu_university AS univ ON univ.code = coll.univ_code 
		 WHERE paid_status = "paid" AND univ_code = "u002";
		 
SELECT SUM(amount) AS collected_fee,  univ.name
		 FROM edu_semester_fee AS semfee
		 JOIN edu_student AS stud ON stud.stu_id = semfee.stud_id
		 JOIN edu_college AS coll ON coll.id = stud.college_id 
		 JOIN edu_university AS univ ON univ.code = coll.univ_code 
		 WHERE paid_status = "paid" AND univ_code = "u003";
		 
SELECT SUM(amount) AS collected_fee,  univ.name
		 FROM edu_semester_fee AS semfee
		 JOIN edu_student AS stud ON stud.stu_id = semfee.stud_id
		 JOIN edu_college AS coll ON coll.id = stud.college_id 
		 JOIN edu_university AS univ ON univ.code = coll.univ_code 
		 WHERE paid_status = "paid" AND univ_code = "u004";
		 
SELECT SUM(amount) AS collected_fee, univ.name
		 FROM edu_semester_fee AS semfee
		 JOIN edu_student AS stud ON stud.stu_id = semfee.stud_id
		 JOIN edu_college AS coll ON coll.id = stud.college_id 
		 JOIN edu_university AS univ ON univ.code = coll.univ_code 
		 WHERE paid_status = "paid" AND univ_code = "u005";