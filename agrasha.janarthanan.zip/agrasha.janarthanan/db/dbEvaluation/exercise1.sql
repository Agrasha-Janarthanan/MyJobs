CREATE VIEW edu_college_details AS
										  SELECT  college_code, college_name, `name`, city, state
										          , year_opened, dept_name, emp_name
										  FROM edu_college AS coll 
										  JOIN edu_university AS univ ON coll.univ_code = univ.code
										  JOIN edu_department AS dept ON coll.univ_code = dept.univ_code
										  JOIN edu_employee AS emp ON coll.id = emp.college_id AND desig_id=3
										  WHERE dept_name LIKE "Com%" OR dept_name LIKE  "Info%";
												  
SELECT * FROM edu_college_details;										        