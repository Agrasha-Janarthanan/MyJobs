CREATE TABLE edu_university ( `code` CHAR(4)  NOT NULL  PRIMARY KEY
										, `name` VARCHAR(100) NOT NULL
									);
CREATE TABLE edu_designation ( id INT AUTO_INCREMENT PRIMARY KEY
										 , `desig_name` VARCHAR(30) NOT NULL
										 , `rank` CHAR(1) NOT NULL
										);
CREATE TABLE edu_department ( `dept_code` CHAR(4) NOT NULL PRIMARY KEY 
										, `dept_name` VARCHAR(50) NOT NULL
										, `univ_code` CHAR(4) NOT NULL
										,KEY univ_code_fk (`univ_code`)
										,CONSTRAINT university_department_fk FOREIGN KEY (univ_code) 
										 REFERENCES edu_university (`code`)
										);
CREATE TABLE edu_college ( id INT AUTO_INCREMENT PRIMARY KEY
									, `college_code` CHAR(4) NOT NULL
									, `college_name` VARCHAR(100) NOT NULL
									, `univ_code` CHAR(4) 
									, `city` VARCHAR(50) NOT NULL
									, `state` VARCHAR(50) NOT NULL
									, `year_opened` YEAR(4) NOT NULL
									, CONSTRAINT university_college_fk FOREIGN KEY (univ_code) 
   								  REFERENCES edu_university (`code`)
								);
CREATE TABLE edu_college_department( dept_id INT AUTO_INCREMENT PRIMARY KEY
												 , `udept_code` CHAR(4) NOT NULL
												 , college_id INT NOT NULL
												 , KEY udept_code_fk (`udept_code`)
												 , CONSTRAINT department_collegedept_fk FOREIGN KEY (udept_code) 
   											   REFERENCES edu_department (`dept_code`)
   											 , KEY college_id_fk (college_id)
   											 , CONSTRAINT college_collegedept_fk FOREIGN KEY (college_id)
   											   REFERENCES edu_college (id)
												);
CREATE TABLE edu_syllabus ( id INT AUTO_INCREMENT PRIMARY KEY
									 , cdept_id INT
									 , syllabus_code CHAR(4) NOT NULL
									 , `syllabus_name` VARCHAR(100) NOT NULL
									 , KEY cdept_id_fk (cdept_id)
									 , CONSTRAINT collegedept_syllabus_fk FOREIGN KEY (cdept_id)
									   REFERENCES edu_college_department (dept_id)
									);
CREATE TABLE edu_employee ( id INT AUTO_INCREMENT PRIMARY KEY
									 , `emp_name` VARCHAR(100) NOT NULL
									 , emp_dob DATE NOT NULL
									 , `emp_email` VARCHAR(50) NOT NULL
									 , emp_phone BIGINT NOT NULL
									 , college_id INT NOT NULL
									 , cdept_id INT NOT NULL
									 , desig_id INT NOT NULL
   								 , CONSTRAINT employee_college_fk FOREIGN KEY (college_id)
   								   REFERENCES edu_college (id)									 
									 , CONSTRAINT employee_collegedept_fk FOREIGN KEY (cdept_id)
									   REFERENCES edu_college_department (dept_id)
									 , KEY desig_id_fk (desig_id)
									 , CONSTRAINT employee_designation_fk FOREIGN KEY (desig_id)
									   REFERENCES edu_designation (id)
									);
									
CREATE TABLE edu_professor_syllabus ( emp_id INT 
												  , syllabus_id INT
												  , semester TINYINT NOT NULL
												  , KEY emp_id_fk (emp_id)
			  									  , CONSTRAINT professorsyll_employee_fk FOREIGN KEY (emp_id)
												    REFERENCES edu_employee (id)
												  , KEY syllabus_id_fk (syllabus_id)
			   								  , CONSTRAINT professorsyll_syllabus_fk FOREIGN KEY (syllabus_id)
            								    REFERENCES edu_syllabus (id) 
                                    );
									
CREATE TABLE edu_student ( stu_id INT AUTO_INCREMENT PRIMARY KEY
									, roll_number CHAR(8) NOT NULL
									, stu_name VARCHAR(100) NOT NULL
									, stu_dob DATE NOT NULL
									, gender CHAR(1) NOT NULL
									, stu_email VARCHAR(50) NOT NULL
									, stu_phone BIGINT NOT NULL
									, stu_address VARCHAR(200) NOT NULL
									, acaemic_year  YEAR(4) NOT NULL
									, cdept_id INT NOT NULL
									, college_id INT NOT NULL
									, CONSTRAINT student_collegedept_fk FOREIGN KEY (cdept_id)
									  REFERENCES edu_college_department (dept_id)
									, CONSTRAINT student_college_fk FOREIGN KEY (college_id)
   								  REFERENCES edu_college (id)
								);

CREATE TABLE edu_semester_fee ( cdept_id INT NOT NULL
										  , stud_id INT NOT NULL
										  , semester TINYINT NOT NULL
										  , amount DOUBLE(18,2) 
										  , paid_year YEAR(4)
										  , paid_status VARCHAR(10) NOT NULL
										  , CONSTRAINT semesterfee_collegedept_fk FOREIGN KEY (cdept_id)
		 								    REFERENCES edu_college_department (dept_id)
		 								  , KEY stud_id_fk (stud_id)
										  , CONSTRAINT semesterfee_student_fk FOREIGN KEY (stud_id)
									       REFERENCES edu_student (stu_id) 
										);

CREATE TABLE edu_semester_result ( stud_id INT NOT NULL
											  , syllabus_id INT NOT NULL
											  , semester TINYINT NOT NULL
											  , grade VARCHAR(2) NOT NULL
											  , credits FLOAT(4,2) NOT NULL
											  , result_date DATE NOT NULL
											  , CONSTRAINT semesterres_student_fk FOREIGN KEY (stud_id)
									          REFERENCES edu_student (stu_id) 
											  , CONSTRAINT semesterres_syllabus_fk FOREIGN KEY (syllabus_id)
            								 REFERENCES edu_syllabus (id) 
											);																				