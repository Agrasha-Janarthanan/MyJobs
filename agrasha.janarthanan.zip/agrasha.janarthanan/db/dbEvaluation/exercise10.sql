SELECT stu_id, roll_number, stu_name, gender, academic_year
		 , dept_name, semester, grade, credits AS GPA
		 FROM edu_student AS stud
		 JOIN edu_semester_result AS semres ON semres.stud_id = stud.stu_id
		 JOIN edu_syllabus AS syll ON syll.id = semres.syllabus_id
		 JOIN edu_college_department AS cdept ON syll.cdept_id = cdept.dept_id
		 JOIN edu_department AS dept ON dept.dept_code = cdept.udept_code
		 WHERE credits > 8 AND semester = 6 ;
		 
SELECT stu_id, roll_number, stu_name, gender, academic_year
		 , dept_name, semester, grade, credits AS GPA
		 FROM edu_student AS stud
		 JOIN edu_semester_result AS semres ON semres.stud_id = stud.stu_id
		 JOIN edu_syllabus AS syll ON syll.id = semres.syllabus_id
		 JOIN edu_college_department AS cdept ON syll.cdept_id = cdept.dept_id
		 JOIN edu_department AS dept ON dept.dept_code = cdept.udept_code
		 WHERE credits > 5 AND semester = 8 ;