SELECT emp.id, emp_name, emp_dob, emp_email
		 , emp_phone, college_code, college_name
		 , dept.univ_code, city, state, dept_name                
		 , desig_name                              
	    FROM edu_employee AS emp
 		 JOIN edu_college AS coll ON emp.college_id = coll.id
		 JOIN edu_college_department AS cdept ON emp.cdept_id = cdept.dept_id
		 JOIN edu_department AS dept ON cdept.udept_code = dept.dept_code
		 JOIN edu_designation AS desig ON emp.desig_id = desig.id
		 WHERE coll.univ_code = "u001" ORDER BY college_name, desig_id ASC;