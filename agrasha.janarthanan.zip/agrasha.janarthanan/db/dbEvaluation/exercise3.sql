SELECT roll_number, stu_name, gender, stu_dob, stu_email, stu_phone
       , stu_address, college_name, dept_name, emp.emp_name AS hod_name
	    FROM edu_student AS stu
	    JOIN edu_college_department AS cdept ON stu.cdept_id = cdept.dept_id
	    JOIN edu_college AS coll ON coll.id = cdept.college_id  
	    JOIN edu_university AS univ ON univ.code = coll.univ_code
		 JOIN edu_department AS dept ON dept.dept_code = cdept.udept_code  
	    JOIN edu_employee AS emp ON emp.cdept_id = cdept.dept_id 
		 JOIN edu_designation AS desig ON emp.desig_id = desig.id 
	    WHERE desig_id = 4 LIMIT 20 ;
