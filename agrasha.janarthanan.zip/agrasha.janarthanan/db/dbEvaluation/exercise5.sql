SELECT stu_id, roll_number, stu_name, gender, academic_year
		 , college_name, syllabus_name, semester, grade, credits AS GPA
		 FROM edu_student AS stud 
		 JOIN edu_college AS coll ON stud.college_id = coll.id
		 JOIN edu_syllabus AS syll ON stud.stu_id = syll.id
		 JOIN edu_semester_result AS semres ON stud.stu_id = semres.stud_id 	 
		 ORDER BY `college_name`, semester ASC LIMIT 10,20;