INSERT INTO edu_student ( roll_number, stu_name, stu_dob, gender, stu_email, stu_phone
                          , stu_address, academic_year, cdept_id, college_id)
VALUES		( 'ueacs006', 'Prabu', '1997-08-12', 'M', 'prabu12@gmail.com', 9635656589
				  , '26,big street, Tiruvannamalai 606601', 2017, 1, 1),
				( 'nitcs006', 'Seetha', '1996-08-08', 'F', 'seetha08@gmail.com', 9632325890
				  , '9/102, Temple street, Trichy 602312', 2017, 10, 4),
				( 'vitec006', 'Shanmugam', '1997-10-18', 'M', 'shanmugam18@gmail.com', 9875632014
				  , '55, mint street, Paris Corner, Chennai 632002', 2017, 17, 7);
				    

INSERT INTO edu_semester_fee ( cdept_id, stud_id, semester, amount, paid_status)
VALUES      ( 1, 51, 02, 35000, "unpaid"),
				( 10, 52, 02, 37000, "unpaid"),
				( 17, 53, 02, 40000, "unpaid");




SELECT * FROM edu_semester_fee;