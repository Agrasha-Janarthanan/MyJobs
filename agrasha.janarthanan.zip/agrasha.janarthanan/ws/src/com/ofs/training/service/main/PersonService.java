package com.ofs.training.service.main;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class PersonService {

    AddressService addressService = new AddressService();

    private void validate(Person person, Connection conn) throws Exception{

        List<Error> errors = new ArrayList<Error>();

        if (isEmpty(person.getFirstName())) {
            errors.add(Error.INVALID_FIRSTNAME);
        }

        if (isEmpty(person.getLastName())) {
            errors.add(Error.INVALID_LASTNAME);
        }

        if (isEmpty(person.getEmail())) {
            errors.add(Error.INVALID_EMAIL);
        }

        if (person.getBirthDate() == null) {
            errors.add(Error.INVALID_BIRTHDATE);
        }

        try {
            validateName(person, conn);
        } catch (AppException e) {
            errors.addAll(e.getErrorCodes());
        }

        try {
            validateEmail(person, conn);
        } catch (AppException e) {
            errors.addAll(e.getErrorCodes());
        }

        if (errors.size() > 0) {
            throw new AppException(errors);
        }
    }

    private boolean isEmpty(String value) {
        return Objects.isNull(value) || "".equals(value);
    }

    private void validateName(Person person, Connection conn) throws Exception{

        try {
            String query = "SELECT COUNT(id) FROM person WHERE first_name = ? AND last_name = ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            ResultSet executeQuery = statement.executeQuery();
            executeQuery.next();
            int count = executeQuery.getInt(1);
            if (count > 0) {
                List<Error> errors = new ArrayList<>();
                errors.add(Error.DUPLICATE_NAME);
                throw new AppException(errors);
            }
        } catch (SQLException exception) {
             throw new AppException(Error.DATABASE_ERROR, exception.getCause());
        }
    }

    private void validateEmail(Person person, Connection conn) throws Exception {

        try {
            String query = "SELECT COUNT(id) FROM person WHERE email = ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, person.getEmail());
            ResultSet executeQuery = statement.executeQuery();
            executeQuery.next();
            int count = executeQuery.getInt(1);
            if (count > 0) {
                List<Error> errors = new ArrayList<>();
                errors.add(Error.DUPLICATE_EMAIL);
                throw new AppException(errors);
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }

    private void validateId(long id, Connection conn) throws Exception {

        if (id == 0) {
            List<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_ID);
            throw new AppException(errors);
        }
    }

    private void constructPerson(Person person, ResultSet result) throws Exception {

        try {
            person.setId         (result.getLong("id"));
            person.setFirstName  (result.getString("first_name"));
            person.setLastName   (result.getString("last_name"));
            person.setEmail      (result.getString("email"));
            person.setBirthDate  (result.getDate("birth_date"));
        } catch (SQLException e) {
            person.setId         (result.getLong("id"));
            person.setFirstName  (result.getString("first_name"));
            person.setLastName   (result.getString("last_name"));
            person.setEmail      (result.getString("email"));
            person.setBirthDate  (result.getDate("birth_date"));
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }


    private void setValue(Person person, PreparedStatement statement) throws AppException {

        try {
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setString(3, person.getEmail());
            statement.setDate  (4, person.getBirthDate());
        } catch (Exception e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }

    public Person create(Person person, Connection conn) throws Exception {

        long generatedKey = 0;

        String insertQuery = new StringBuilder().append("INSERT INTO person (first_name   ")
                                                .append("                   , last_name   ")
                                                .append("                   , email       ")
                                                .append("                   , birth_date  ")
                                                .append("                   , address_id) ")
                                                .append("VALUES (?, ?, ?, ?, ?)           ")
                                                .toString();

        try {
            validate(person, conn);

            PreparedStatement statement = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
            Address address = addressService.create(person.getAddress(), conn);
            setValue(person, statement);
            person.setAddress  (address);
            statement.setLong  (5, person.getAddress().id);
            statement.executeUpdate();

            ResultSet generatedKeys = statement.getGeneratedKeys();
            if ((generatedKeys != null) && (generatedKeys.next())) {
                generatedKey = generatedKeys.getLong(1);
            }
            person.setId(generatedKey);
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return person; 
    }

    public Person update(Person person, Connection conn) throws Exception {

        String query = new StringBuilder().append("UPDATE person          ")
                                          .append("   SET first_name = ?  ")
                                          .append("       , last_name = ? ")
                                          .append("       , email = ?     ")
                                          .append("       , birth_date = ?")
                                          .append("       , address_id = ?")
                                          .append(" WHERE id = ?          ").toString();

        try {
            validateId(person.getId(), conn);

            PreparedStatement statement = conn.prepareStatement(query);
            Address address = addressService.update(person.getAddress(), conn);
            setValue(person, statement);
            person.setAddress  (address);
            statement.setLong  (5, person.getAddress().getId());
            statement.setLong  (6, person.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return person;
    }

    public Person read(long id, boolean includeAddress, Connection connection) throws Exception {

        validateId(id, connection);
        Person person = new Person();

        try {
                String readQuery = new StringBuilder().append("SELECT id             ")
                                                      .append("     , first_name     ")
                                                      .append("     , last_name      ")
                                                      .append("     , email          ")
                                                      .append("     , birth_date     ")
                                                      .append("     , created_date   ")
                                                      .append("     , address_id     ")
                                                      .append("FROM person           ")
                                                      .append("WHERE id = ?          ").toString();

            PreparedStatement statement = connection.prepareStatement(readQuery);
            statement.setLong(1, id);
            Address address = null;
            ResultSet rs = statement.executeQuery();
            rs.next();
            person.setId(rs.getLong("id"));
            person.setFirstName(rs.getString("first_name"));
            person.setLastName(rs.getString("last_name"));
            person.setEmail(rs.getString("email"));
            person.setBirthDate(rs.getDate("birth_date"));
            long addressId = rs.getLong("address_id");
            if (includeAddress) {
                address = addressService.read(addressId, connection);
            }
            person.setAddress(address);
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        connection.close();
        // constructPerson(result, rs);
        return person;
    }

    public List<Person> readAll(boolean includeAddress, Connection conn) throws Exception {

        String readAllQuery = new StringBuilder().append("SELECT id             ")
                                                 .append("       , first_name   ")
                                                 .append("       , last_name    ")
                                                 .append("       , email        ")
                                                 .append("       , birth_date   ")
                                                 .append("       , created_date ")
                                                 .append("       , address_id   ")
                                                 .append("  FROM person         ").toString();
        List<Person> resultRecord = new ArrayList<>();
        Person person;

        try {

                ArrayList<Address> addresses = addressService.readAll(conn);
                Map<Long, Address> addressMapper = new HashMap<>();
                for (Address address : addresses) {
                    addressMapper.put(address.getId(), address);
                }
                PreparedStatement statement = conn.prepareStatement(readAllQuery);
                ResultSet result = statement.executeQuery();

                while (result.next()) {
                    person = new Person();
                    constructPerson(person, result);

                    if (includeAddress) {
                        Address address = new Address();
                        address.setId(result.getLong("address_id"));
                        person.setAddress(address);
                        person.setAddress(addressMapper.get(person.getAddress().getId()));
                    }
                    resultRecord.add(person);
                }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return resultRecord;
    }

    public void delete(Person person, Connection conn) throws Exception {

        String deleteQuery = new StringBuilder().append("DELETE FROM person ")
                                                .append("WHERE id = ?       ").toString();

        try {
            validateId(person.getId(),conn);
            PreparedStatement statement = conn.prepareStatement(deleteQuery.toString());
            statement.setLong(1, person.getId());
            statement.executeUpdate();
            addressService.delete(person.getAddress(), conn);
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }
}
