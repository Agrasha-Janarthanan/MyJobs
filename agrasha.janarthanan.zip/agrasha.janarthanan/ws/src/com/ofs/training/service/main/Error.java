package com.ofs.training.service.main;


public enum Error{

    INVALID_ID             (101, "Id cannot be null"                 ),
    DUPLICATE_ID           (102, "Id does not exists"                ),
    INVALID_STREET         (201, "Street cannot be empty or null"    ),
    INVALID_CITY           (202, "City cannot be empty or null"      ),
    INVALID_POSTALCODE     (203, "PostalCode cannot be null"         ),
    INVALID_INPUT          (204, "Input cannot be null"              ),
    DATABASE_ERROR         (301, "Invalid SQL Query"                 ),
    INVALID_FIRSTNAME      (401, "First Name cannot be empty or null"),
    INVALID_LASTNAME       (402, "Last Name cannot be empty or null" ),
    DUPLICATE_NAME         (403, "Name already exists"               ),
    INVALID_EMAIL          (404, "Email cannot be empty or null"     ),
    DUPLICATE_EMAIL        (405, "Email already exists"              ),
    INVALID_BIRTHDATE      (406, "Birth date cannot be empty or null"),
    UNKNOWN_ERROR          (501, "unknown error"                     ),
    LOAD_JSON_ERROR        (502, "Unable to load Json data"          ),
    STORE_JSON_ERROR       (503, "Unable to store Json data"         ),
    SERVLET_EXCEPTION      (601, "Exception in servlet"              ),
    IO_EXCEPTION           (602, "Input cannot be processed"         ),
    NUMBER_FORMAT_EXCEPTION(603, "input is not a number"             ),
    INVALID_URL_EXCEPTION  (604, "Invalid URL"                       );

    int errorCode;
    String errorDescription;

    private Error(int errorCode, String errorDescription) {
        this.errorCode = errorCode;
        this.errorDescription = errorDescription;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorDescription;
    }

    @Override
    public String toString() {
        return errorCode + " : " + errorDescription;
    }
}
