package com.ofs.training.service.main;

import java.sql.Connection;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class ConnectionManager {

    static Connection conn ;
    private static HikariDataSource ds;

    static {
        HikariConfig config = new HikariConfig("resources/ConnectionProperties.properties");
        ds = new HikariDataSource(config);
    }

    public static Connection openConnection() {

        try {
            conn = ds.getConnection();
            conn.setAutoCommit(false);
        } catch (Exception exception) {
            throw new RuntimeException("Invalid Connection");
        }
        return conn;
    }

    public static void releaseConnection(boolean doCommit) {

        try {
            if (doCommit) {
                conn.commit();
                conn.close();
            } else {
                conn.rollback();
                conn.close();
            }
        } catch (Exception exception) {
            throw new RuntimeException("Connection is not open");
        } 
    }
}
