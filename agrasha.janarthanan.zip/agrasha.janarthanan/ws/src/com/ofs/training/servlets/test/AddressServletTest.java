package com.ofs.training.servlets.test;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.Error;
import com.ofs.training.servlets.plugin.HttpMethod;
import com.ofs.training.servlets.plugin.JsonUtil;
import com.ofs.training.servlets.plugin.RequestHelper;
import com.ofs.training.servlets.plugin.Response;

public class AddressServletTest {

    RequestHelper helper;
    @BeforeClass
    public void setUp() {

        helper = new RequestHelper();
    }

    @Test(dataProvider = "testCreate_positiveDP")
    public void testCreate_positive(Address input) throws Exception {

        String uri = "http://localhost:8080/ws/address";
        Response response = helper.setMethod(HttpMethod.PUT)
                                  .setInput(input)
                                  .requestObject(uri);
        String actualAddressJson = response.getContent();
        Address actual = JsonUtil.toObject(actualAddressJson, Address.class);

        input.setId(actual.getId());
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testCreate_positiveDP() {

        Address address = new Address();
        address.setStreet("PQR street");
        address.setCity("Cbe");
        address.setPostalCode(698547);
        return new Object[][] {
                                {address}
                              };
    }

    @Test(dataProvider = "testUpdate_positiveDP")
    public void testUpdate_positive(Address input) throws Exception {

        String uri = "http://localhost:8080/ws/address?id=1";
        Response response = helper.setMethod(HttpMethod.POST)
                                .setInput(input)
                                .requestObject(uri);
        String actualAddressJson = response.getContent();
        Address actual = null;
        actual = JsonUtil.toObject(actualAddressJson, Address.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        Address address = new Address();
        address.setId(1);
        address.setStreet("car street");
        address.setCity("tvm");
        address.setPostalCode(606601);
        return new Object[][] {
                                {address}
                              };
    }

    @Test(dataProvider = "testRead_negativeDP")
    public void testUpdate_negative(String uri, Error expected) throws Exception {

        Response response = helper.setMethod(HttpMethod.POST)
                                  .requestObject(uri);

        String actualAddressJson = response.getContent();
        List<?> actual =JsonUtil.toObject(actualAddressJson, List.class);
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testUpdate_negativeDP() {

        return new Object[][] {
                                {"http://localhost:8080/ws/address?id", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=abc", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=7.20", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=abc&street=&city=&postalCode=", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=7.20", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=7.20", Error.INVALID_URL_EXCEPTION},
                              };
    }

    @Test(dataProvider = "testDelete_positiveDP")
    public void testDelete_positive(Address input) throws Exception {

        String uri = "http://localhost:8080/ws/address?id=1";
        Response response = helper.setMethod(HttpMethod.DELETE)
                                  .requestObject(uri);

        String actualAddressJson = response.getContent();
        Address actual = null;
        actual = JsonUtil.toObject(actualAddressJson, Address.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {

        Address address = new Address();
        address.setId(1);
        address.setStreet("car street");
        address.setCity("tvm");
        address.setPostalCode(606601);
        return new Object[][] {
                                {address}
                              };
    }

    @Test(dataProvider = "testDelete_negativeDP")
    public void testDelete_negative(String uri, Error expected) throws Exception {

        Response response = helper.setMethod(HttpMethod.DELETE)
                                  .requestObject(uri);

        String actualAddressJson = response.getContent();
        List<?> actual =JsonUtil.toObject(actualAddressJson, List.class);
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testDelete_negativeDP() {

        return new Object[][] {
                                {"http://localhost:8080/ws/address?id", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=abc", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=7.20", Error.INVALID_URL_EXCEPTION}
                              };
    }

    @Test(dataProvider = "testRead_positiveDP")
    public void testRead_positive(Address input) throws Exception {

        String uri = "http://localhost:8080/ws/address?id=2";
        Response response = helper.setMethod(HttpMethod.GET)
                                  .requestObject(uri);

        String actualAddressJson = response.getContent();
        Address actual = null;
        actual = JsonUtil.toObject(actualAddressJson, Address.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {

        Address address = new Address();
        address.setId(2);
        address.setStreet("abc street");
        address.setCity("chennai");
        address.setPostalCode(600001);
        return new Object[][] {
                                {address}
                              };
    }

    @Test(dataProvider = "testRead_negativeDP")
    public void testRead_negative(String uri, Error expected) throws Exception {

        Response response = helper.setMethod(HttpMethod.GET)
                                  .requestObject(uri);

        String actualAddressJson = response.getContent();
        List<?> actual =JsonUtil.toObject(actualAddressJson, List.class);
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {

        return new Object[][] {
                                {"http://localhost:8080/ws/address?id", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=abc", Error.INVALID_URL_EXCEPTION},
                                {"http://localhost:8080/ws/address?id=7.20", Error.INVALID_URL_EXCEPTION}
                              };
    }

    @Test(dataProvider = "testReadAll_positiveDP")
    public void testReadAll_positive(List<Address> input) throws Exception {

        String uri = "http://localhost:8080/ws/address";
        Response readAddresses = helper.setMethod(HttpMethod.GET)
                                     .requestObject(uri);
        List<?> actual = new ArrayList<>();
        String actualAddressJson = readAddresses.getContent();
        actual = JsonUtil.toObject(actualAddressJson, List.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {

        List<Address> addresses = new ArrayList<>();
        addresses.add(new Address(1, "car street", "tvm", 606601));
        addresses.add(new Address(2, "abc street", "chennai", 600001));
        addresses.add(new Address(3, "PQR street", "Cbe", 698547));
        return new Object[][] {
                                {addresses}
                              };
    }

    @Test(dataProvider = "testSearch_positiveDP")
    public void testSearch_positive(List<Address> input, String[] fields, String searchInput) throws Exception {

        StringBuilder uri = new StringBuilder("http://localhost:8080/ws/address?searchInput=").append(searchInput)
                                                                                              .append("&searchField=");
        for (String field : fields) {
            uri.append(field);
            uri.append(",");
        }
        uri.substring(0, uri.length() - 1);
        Response readAddresses = helper.setMethod(HttpMethod.GET)
                                       .requestObject(uri.toString());
        List<?> actual = new ArrayList<>();
        String actualAddressJson = readAddresses.getContent();
        actual = JsonUtil.toObject(actualAddressJson, List.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input)); 
    }

    @DataProvider
    private Object[][] testSearch_positiveDP() {

        List<Address> addresses = new ArrayList<>();
        addresses.add(new Address(2, "abc street", "chennai", 600001));
        String[] field = {"city", "street"};
        String searchInput = "abc";
        return new Object[][] {
                                {addresses, field, searchInput}
                              };
    }

    @Test(dataProvider = "testSearch_negativeDP")
    public void testSearch_negative(String uri, List<Error> expected, String errorMessage) throws Exception {

        Response response = helper.setMethod(HttpMethod.GET)
                                  .requestObject(uri);

        String actualAddressJson = response.getContent();
        List<?> actual =JsonUtil.toObject(actualAddressJson, List.class);
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testSearch_negativeDP() {

        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_URL_EXCEPTION);
        return new Object[][] {
                                {"http://localhost:8080/ws/address?searchInput=&searchField=", errors},
                                {"http://localhost:8080/ws/address?searchInput=", errors},
                                {"http://localhost:8080/ws/address?searchInput=7.2&searchField=", errors},
                                {"http://localhost:8080/ws/address?searchField=", errors},
                              };
    }
}
