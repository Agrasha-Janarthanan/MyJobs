package com.ofs.training.servlets.test;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.Error;
import com.ofs.training.service.main.Person;
import com.ofs.training.servlets.plugin.HttpMethod;
import com.ofs.training.servlets.plugin.JsonUtil;
import com.ofs.training.servlets.plugin.RequestHelper;
import com.ofs.training.servlets.plugin.Response;

public class PersonServletTest {

    RequestHelper helper;

    @BeforeClass
    public void setUp() {
        helper = new RequestHelper();
    }

    @Test(dataProvider = "testCreate_positiveDP")
    public void testCreate_positive(String uri, Person input) throws Exception {

        Response response = helper.setMethod(HttpMethod.PUT)
                                  .setInput(input)
                                  .requestObject(uri);

        String actualPersonJson = response.getContent();
        Person person = JsonUtil.toObject(actualPersonJson, Person.class);
        input.setId(person.getId());
        Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testCreate_positiveDP() {

        String uri = "http://localhost:8080/ws/person";
        Address address = new Address(1, "pqr street", "Palam", 606601);
        Person person = new Person("Emily", "Blunt", "emBlu@123", Date.valueOf("1990-09-09"), address);
        Address anotherAddress = new Address(2, "car street", "tvm", 606601);
        Person anotherPerson = new Person("Ayshu", "Devi", "g@gmail.com", Date.valueOf("1996-08-08"), anotherAddress);
        return new Object[][] {
                                {uri, person},
                                {uri, anotherPerson}
                              };
    }

    @Test(dataProvider = "testUpdate_positiveDP")
    public void testUpdate_positive(String uri, Person input) throws Exception {

        Response response = helper.setMethod(HttpMethod.POST)
                                  .setInput(input)
                                  .requestObject(uri);

        String actualPersonJson = response.getContent();
        Person actual = JsonUtil.toObject(actualPersonJson, Person.class); 
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        String uri = "http://localhost:8080/ws/person?id=1";
        Address anotherAddress = new Address(2, "car street", "tvm", 606601);
        Person person = new Person();
        person.setId(2);
        person.setFirstName("Ayshu");
        person.setLastName("Ezhil");
        person.setEmail("g@gmail.com");
        person.setBirthDate(Date.valueOf("1996-08-08"));
        person.setAddress(anotherAddress);
        return new Object[][] {
                                {uri, person}
                              };
    }

    @Test(dataProvider = "testDelete_positiveDP")
    public void testDelete_positive(String uri, Person input) throws Exception {

        Response response = helper.setMethod(HttpMethod.DELETE)
                                  .requestObject(uri);

        String actualPersonJson = response.getContent();
        Person actual = JsonUtil.toObject(actualPersonJson, Person.class); 
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {

        String uri = "http://localhost:8080/ws/person?id=1";
        Address address = new Address(1, "pqr street", "Palam", 606601);
        Person person = new Person(1, "Emily", "Blunt", "emBlu@123", Date.valueOf("1990-09-09"), address);
        return new Object[][] {
                                {uri, person}
                              };
    }

    @Test(dataProvider = "testDelete_negativeDP")
    public void testDelete_negative(String uri, List<Error> expected) throws Exception {

        Response response = helper.setMethod(HttpMethod.DELETE)
                                  .requestObject(uri);

        String actualAddressJson = response.getContent();
        List<?> actual =JsonUtil.toObject(actualAddressJson, List.class);
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testDelete_negativeDP() {

        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_URL_EXCEPTION);
        return new Object[][] {
                                {"http://localhost:8080/ws/person?id", errors},
                                {"http://localhost:8080/ws/person?id=", errors},
                                {"http://localhost:8080/ws/person?id=1adg", errors}
                              };
    }

    @Test(dataProvider = "testRead_positiveDP")
    public void testRead_positive(String uri, Person input) throws Exception {

        Response response = helper.setMethod(HttpMethod.GET)
                                  .requestObject(uri);

        String actualPersonJson = response.getContent();
        Person actual = JsonUtil.toObject(actualPersonJson, Person.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {

        String uri = "http://localhost:8080/ws/person?id=1&includeAddress=true";
        Address address = new Address(1, "pqr street", "Palam", 606601);
        Person person = new Person(1, "Emily", "Blunt", "emBlu@123", Date.valueOf("1990-09-09"), address);
        return new Object[][] {
                                {uri, person}
                              };
    }

    @Test(dataProvider = "testRead_negativeDP")
    public void testRead_negative(String uri, List<Error> expected) throws Exception {

        Response response = helper.setMethod(HttpMethod.GET)
                                  .requestObject(uri);

        String actualPersonJson = response.getContent();
        List<?> actual =JsonUtil.toObject(actualPersonJson, List.class);
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {

        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_URL_EXCEPTION);
        return new Object[][] {
                                {"http://localhost:8080/ws/person?id", errors},
                                {"http://localhost:8080/ws/person?id=", errors},
                                {"http://localhost:8080/ws/person?id=abc", errors},
                                {"http://localhost:8080/ws/person?id=7.20", errors}
                              };
    }

    @Test(dataProvider = "testReadAll_positiveDP")
    public void testReadAll_positive(String uri, List<Person> input) throws Exception {

        Response readPersons = helper.setMethod(HttpMethod.GET)
                                     .requestObject(uri);
        List<?> actual = new ArrayList<>();
        String actualPersonJson = readPersons.getContent();
        actual = JsonUtil.toObject(actualPersonJson, List.class);
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {

        String uri = "http://localhost:8080/ws/person?includeAddress=true";
        List<Person> persons = new ArrayList<>();
        persons.add(new Person(1, "Emily", "Blunt", "emBlu@123", Date.valueOf("1990-09-09"), new Address(1, "pqr street", "Palam", 606601)));
        persons.add(new Person(2, "Ayshu", "Ezhil", "g@gmail.com", Date.valueOf("1996-08-08"), new Address(2, "car street", "tvm", 606601)));

        return new Object[][] {
                                {uri, persons}
                              };
    }
}
