package com.ofs.training.servlets.test;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.Person;
import com.ofs.training.servlets.plugin.HttpMethod;
import com.ofs.training.servlets.plugin.JsonUtil;
import com.ofs.training.servlets.plugin.RequestHelper;
import com.ofs.training.servlets.plugin.Response;

public class PersonServletTest {
    RequestHelper helper;
    @BeforeClass
    public void setUp() {

        helper = new RequestHelper();
    }

    @Test(dataProvider = "testCreate_positiveDP")
    public void testCreatePositive(Person input) throws Exception {

        
        String uri = "http://localhost:8080/ws/person";
        Response response = helper.setMethod(HttpMethod.PUT)
                                .setInput(input)
                                .requestObject(uri);

        String actualPersonJson = response.getContent();
        Person person = JsonUtil.toObject(actualPersonJson, Person.class);
        input.setId(person.getId());
        Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testCreate_positiveDP() {

        Address address = new Address();
        address.setStreet("pqr street");
        address.setCity("Palam");
        address.setPostalCode(606601);
        Person person = new Person();
        person.setFirstName("Sam");
        person.setLastName("Arnold");
        person.setEmail("samarm@123");
        person.setBirthDate(Date.valueOf("1990-09-09"));
        person.setAddress(address);
        return new Object[][] {
                                {person}
                              };
    }

    @Test(dataProvider = "testUpdate_positiveDP")
    public void testUpdate(Person input) throws Exception {

        String uri = "http://localhost:8080/ws/person?id=1";
        Person updated = helper.setMethod(HttpMethod.POST)
                                .setInput(input)
                                .requestObject(uri, Person.class);

        Assert.assertEquals(JsonUtil.toJson(updated), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        Person person = new Person();
        person.setId(1);
        person.setFirstName("Ayshu");
        person.setLastName("Devi");
        person.setEmail("g@gmail.com");
        person.setBirthDate(Date.valueOf("1996-08-08"));
        return new Object[][] {
                                {person}
                              };
    }

    @Test(dataProvider = "testDelete_positiveDP")
    public void testDelete(Person input) throws Exception {

        String uri = "http://localhost:8080/ws/person";
        Person deleted = helper.setMethod(HttpMethod.DELETE)
                                .setInput(input)
                                .requestObject(uri, Person.class);

        Assert.assertEquals(JsonUtil.toJson(deleted), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {

        Person person = new Person();
        person.setId(1);
        return new Object[][] {
                                {person}
                              };
    }

    @Test(dataProvider = "testRead_positiveDP")
    public void testRead_positive(Person input) throws Exception {

        String uri = "http://localhost:8080/ws/person?id=1";
        Person readAddress = helper.setMethod(HttpMethod.GET)
                                    .setInput(input)
                                    .requestObject(uri, Person.class);

        Assert.assertEquals(JsonUtil.toJson(readAddress), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {

        Address address = new Address();
        address.setId(1);
        address.setStreet("car street");
        address.setCity("tvm");
        address.setPostalCode(606601);
        Person person = new Person();
        person.setId(1);
        person.setFirstName("Ayshu");
        person.setLastName("Devi");
        person.setEmail("g@gmail.com");
        person.setBirthDate(Date.valueOf("1996-08-08"));
        person.setAddress(address);
        return new Object[][] {
                                {person}
                              };
    }

    @Test(dataProvider = "testReadAll_positiveDP")
    public void testReadAll_positive(List<Person> input) throws Exception {

        String uri = "http://localhost:8080/ws/person";
        List<?> readPersons = helper.setMethod(HttpMethod.GET)
                                     .requestObject(uri, List.class);
        Assert.assertEquals(JsonUtil.toJson(readPersons), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {

        List<Person> persons = new ArrayList<>();
        persons.add(new Person(1, "Ayshu", "Devi", "g@gmail.com", Date.valueOf("1996-08-08"), new Address(1, "car street", "tvm", 606601)));
        persons.add(new Person(2, "Sam", "Arnold", "samarm@123", Date.valueOf("1990-09-09"), new Address(3, "pqr street", "Palam", 606601)));

        return new Object[][] {
                                {persons}
                              };
    }
}
