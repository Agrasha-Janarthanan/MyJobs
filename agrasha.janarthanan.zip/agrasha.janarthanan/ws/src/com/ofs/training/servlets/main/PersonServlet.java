package com.ofs.training.servlets.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.ConnectionManager;
import com.ofs.training.service.main.Person;
import com.ofs.training.service.main.PersonService;
import com.ofs.training.servlets.plugin.JsonUtil;

public class PersonServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private void setValue(Person person, String firstName, String lastName, String email, Date date, Address address) {

        person.setFirstName(firstName);
        person.setLastName(lastName);
        person.setEmail(email);
        person.setBirthDate(date);
        person.setAddress(address);
    }

    private void setAddressValue(Address address, String street, String city, int postalCode) {

        address.setStreet(street);
        address.setCity(city);
        address.setPostalCode(postalCode);
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PersonService ps = new PersonService();
        Connection connection = ConnectionManager.openConnection();
        Person person = new Person();
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String birthDate = request.getParameter("birthDate");
        System.out.println("Date is " + birthDate);
        Date date = Date.valueOf(LocalDate.parse(birthDate, DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        String street = request.getParameter("street");
        String city = request.getParameter("city");
        int postalCode = Integer.parseInt(request.getParameter("postalCode"));
        Address address = new Address();
        setAddressValue(address, street, city, postalCode);
        person.setAddress(address);
        setValue(person, firstName, lastName, email, date, address);
        try {
            person = ps.create(person, connection);
            ConnectionManager.releaseConnection(true);
        } catch (Exception e) {
            e.printStackTrace();
            ConnectionManager.releaseConnection(false);
        }
        PrintWriter out = response.getWriter();
        out.write(JsonUtil.toJson(person));
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PersonService ps = new PersonService();
        Connection connection = ConnectionManager.openConnection();
        Person person = new Person();
        int id = Integer.parseInt(request.getParameter("id"));
        person.setId(id);
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String birthDate = request.getParameter("birthDate");
        Date date = Date.valueOf(LocalDate.parse(birthDate, DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        String street = request.getParameter("street");
        String city = request.getParameter("city");
        int postalCode = Integer.parseInt(request.getParameter("postalCode"));
        Address address = new Address();
        int addressId = Integer.parseInt(request.getParameter("addressId"));
        address.setId(addressId);
        setAddressValue(address, street, city, postalCode);
        person.setAddress(address);
        setValue(person, firstName, lastName, email, date, address);
        try {
            person = ps.update(person, connection);
            ConnectionManager.releaseConnection(true);
        } catch (Exception e) {
            e.printStackTrace();
            ConnectionManager.releaseConnection(false);
        }
        PrintWriter out = response.getWriter();
        out.write(JsonUtil.toJson(person));
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PersonService ps = new PersonService();
        Connection connection = ConnectionManager.openConnection();
        List<Person> result = new ArrayList<>();
        Person person = new Person();
        String personId = request.getParameter("id");
        boolean includeAddress = Boolean.parseBoolean(request.getParameter("includeAddress"));
        PrintWriter out = response.getWriter();


        if (Objects.isNull(personId)) {
            try {
                result = ps.readAll(includeAddress, connection);
                ConnectionManager.releaseConnection(true);
            } catch (Exception e) {
                e.printStackTrace();
                ConnectionManager.releaseConnection(false);
            }
            out.write(JsonUtil.toJson(result)); 
        } else {
            try {
                long id = Long.parseLong(personId);
                person.setId(id);
                person = ps.read(id, includeAddress, connection);
                ConnectionManager.releaseConnection(true);
            } catch (Exception e) {
                e.printStackTrace();
                ConnectionManager.releaseConnection(false);
            }
            out.write(JsonUtil.toJson(person));
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PersonService ps = new PersonService();
        Connection connection = ConnectionManager.openConnection();
        Person person = new Person();
        int id = Integer.parseInt(request.getParameter("id"));
        person.setId(id);
        try {
            ps.delete(person, connection);
            ConnectionManager.releaseConnection(true);
        } catch (Exception e) {
            e.printStackTrace();
            ConnectionManager.releaseConnection(false);
        }
    }
}
