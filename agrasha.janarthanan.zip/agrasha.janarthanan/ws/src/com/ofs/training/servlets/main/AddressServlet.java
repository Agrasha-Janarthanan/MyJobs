package com.ofs.training.servlets.main;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.AddressService;
import com.ofs.training.service.main.ConnectionManager;
import com.ofs.training.service.main.Error;
import com.ofs.training.servlets.plugin.JsonUtil;

public class AddressServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    AddressService as = new AddressService();

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Connection connection = ConnectionManager.openConnection();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String addressJson = String.join("", jsonLines);

        Address address = JsonUtil.toObject(addressJson, Address.class);
        PrintWriter out = response.getWriter();

        try {
            address = as.create(address, connection);
            out.write(JsonUtil.toJson(address));
            ConnectionManager.releaseConnection(true);
        } catch (Exception e) {
            ConnectionManager.releaseConnection(false);
            out.write(e.toString());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json");
        Connection connection = ConnectionManager.openConnection();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList()); //or use readLine() Method while while block
        String addressJson = String.join("", jsonLines); //or use readLine() Method while while block

        Address address = JsonUtil.toObject(addressJson, Address.class);
        PrintWriter out = response.getWriter();

        try {
            address = as.update(address, connection);
            out.write(JsonUtil.toJson(address));
            ConnectionManager.releaseConnection(true);
        } catch (Exception e) {
            ConnectionManager.releaseConnection(false);
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Address> result = new ArrayList<>();
        response.setContentType("application/json");
        Connection connection = ConnectionManager.openConnection();
        Address address = new Address();
        String addressId = request.getParameter("id");
        String searchInput = request.getParameter("searchInput");
        String searchField = request.getParameter("searchField");
        List<Error> errorCodes = new ArrayList<>();

        PrintWriter out = response.getWriter();

        try {
            if ((searchField != null) || (searchInput != null)) {
                String[] fields = searchField.split(",");
                result = as.search(fields, searchInput, connection);
                out.write(JsonUtil.toJson(result));
            } else {
                if (Objects.isNull(addressId)) {
                    result = as.readAll(connection);
                    out.write(JsonUtil.toJson(result));
                } else {
                    long id = Long.parseLong(addressId);
                    address.setId(id);
                    address = as.read(id, connection);
                    out.write(JsonUtil.toJson(address));
                }
            }
            ConnectionManager.releaseConnection(true);
        } catch (Exception e) {
            ConnectionManager.releaseConnection(false);
            errorCodes.add(Error.INVALID_URL_EXCEPTION);
            out.write(JsonUtil.toJson(errorCodes));
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json");
        Connection connection = ConnectionManager.openConnection();
        Address address = new Address();
        long id = Long.parseLong(request.getParameter("id"));
        address.setId(id);
        PrintWriter out = response.getWriter();
        try {
            Address deletedAddress = as.delete(address, connection);
            out.write(JsonUtil.toJson(deletedAddress));
            ConnectionManager.releaseConnection(true);
        } catch (Exception e) {
            ConnectionManager.releaseConnection(false);
            e.printStackTrace();
        }
    }
}
