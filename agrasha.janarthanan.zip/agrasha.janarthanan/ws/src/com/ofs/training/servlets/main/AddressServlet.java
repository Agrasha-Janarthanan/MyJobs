package com.ofs.training.servlets.main;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ofs.training.service.main.Address;
import com.ofs.training.service.main.AddressService;
import com.ofs.training.service.main.ConnectionManager;

public class AddressServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private void setAddressValue(Address address, String street, String city, int postalCode) {

        address.setStreet(street);
        address.setCity(city);
        address.setPostalCode(postalCode);
    }

    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        AddressService as = new AddressService();
        ConnectionManager connectionManager = new ConnectionManager();
        Connection connection = connectionManager.openConnection();
        String street = request.getParameter("street");
        String city = request.getParameter("city");
        int postalCode = Integer.parseInt(request.getParameter("postalCode"));
        Address address = new Address();
        setAddressValue(address, street, city, postalCode);
        try {
            address = as.create(address, connection);
        } catch (Exception e) {
            e.printStackTrace();
        }
        PrintWriter out = response.getWriter();
        out.write(address.toString());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        AddressService as = new AddressService();
        ConnectionManager connectionManager = new ConnectionManager();
        Connection connection = connectionManager.openConnection();
        String street = request.getParameter("street");
        String city = request.getParameter("city");
        int postalCode = Integer.parseInt(request.getParameter("postalCode"));
        Address address = new Address();
        int addressId = Integer.parseInt(request.getParameter("addressId"));
        address.setId(addressId);
        setAddressValue(address, street, city, postalCode);
        try {
            address = as.update(address, connection);
        } catch (Exception e) {
            e.printStackTrace();
        }
        PrintWriter out = response.getWriter();
        out.write(address.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Address> result = new ArrayList<>();
        response.setContentType("text/html");
        AddressService as = new AddressService();
        ConnectionManager connectionManager = new ConnectionManager();
        Connection connection = connectionManager.openConnection();
        Address address = new Address();
        int id = Integer.parseInt(request.getParameter("id"));
        address.setId(id);

        PrintWriter out = response.getWriter();

        if (Objects.isNull(id)) {
            try {
                result = as.readAll(connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
            out.write(result.toString());
        } else {
            try {
                address = as.read(address, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
            out.write(address.toString());
        }
    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        AddressService as = new AddressService();
        ConnectionManager connectionManager = new ConnectionManager();
        Connection connection = connectionManager.openConnection();
        Address address = new Address();
        int id = Integer.parseInt(request.getParameter("id"));
        address.setId(id);
        try {
            as.delete(address, connection);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
