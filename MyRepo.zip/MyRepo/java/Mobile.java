import java.io.File;

class Mobile {

    public static void main(String[] args) {

        File file = new File("Mobile.class");
        String filePath = file.getAbsolutePath();

        System.out.println("This is the absolute path of the class file" + filePath);
    }
}
