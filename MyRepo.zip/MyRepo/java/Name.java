import java.util.Arrays;

class Name {

    public static void main(String[] args) {

        String student1 = new String("Priya");
        String student2 = new String("Priya");

        if (student1.equals(student2)) {
            System.out.println("The name exists");
        }

        if (student1 == student2) {
            System.out.println("equal");
        }
    }
}
