// class EnumEquality {
class EnumEquality {

    enum Rainbow {
        VIOLET,
        INDIGO,
        BLUE,
        GREEN,
        YELLOW,
        ORANGE,
        RED;
    }
    enum Color {
        RED,
        GREEN,
        BLUE,
        YELLOW;
    }

    // static void execute() {
    public static void main(String[] args) {

        // Rainbow rainbow = RED;
        Rainbow rainbow = Rainbow.RED;

        // Rainbow rainbowColor = GREEN;
        Rainbow rainbowColor = Rainbow.GREEN;

        // Color color = RED;
        Color color = COlor.RED;

        // compareEnum(rainbow, rainbowColor);
        System.out.println(rainbow.equals(rainbowColor));

        // compareEnum(rainbow, color);
        System.out.println(rainbow.equals(color));

        // Console console = getConsole();
        // console.print(rainbow == rainbowColor);
        System.out.println(rainbow == rainbowColor);

        console.print(rainbow == Color);
        System.out.println(rainbow == Color);
    }
}
