// class StringLengthCalculator {
public class StringLengthCalculator {

    // static void execut() {
    public static void main(String[] args) {

        // String myString = "Was it a car or a cat I saw?";
        String myString = new String("Was it a car or a cat I saw?");

        String mySubString = myString.substring(9,12);

        int myLength = mySubString.length();

        // Console console = getConsole()...;
        // console.print(mySubString);
        System.out.println("Sub String : " + mySubString);

        // console.print(length);
        System.out.println("Length of the sub string: " + myLength);
    }
}
