public interface SomethingIsWrong {

        void aMethod(int aValue);
    }

public class InterfaceDemo implements SomethingIsWrong {

        void aMethod(int aValue) {

            System.out.println("Hi Mom");
        }

    public void static main(String[] args) {

        InterfaceDemo myInterface = new myInterface();
        myInterface.aMethod(10);
    }
}
