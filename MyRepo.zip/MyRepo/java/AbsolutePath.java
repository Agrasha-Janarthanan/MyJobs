import java.io.File;

class AbsolutePath {

    public static void main(String[] args) {

        File file = new File("");
        String filePath = file.getAbsolutePath();

        System.out.println("This is the absolute path: " + filePath);
    }
}
