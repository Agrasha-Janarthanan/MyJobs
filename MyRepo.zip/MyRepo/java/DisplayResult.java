class DisplayResult {

    public void calculate(int num1, int num2) {

        int num3;
        num3 = num1 / num2;
        System.out.println("Result:" + num3 + " of type " + int.class.getName());
    }

    public void calculate(double num1, int num2) {

        double num3;
        num3 = num1 / num2;
        System.out.println("Result:" + num3 + " of type " + double.class.getName());
    }

    public void calculate(char num1, int num2) {

        int num3;
        num3 = num1 / num2;
        System.out.println("Result:" + num3 + " of type " + int.class.getName());
    }

    public void calculate(double num1, double num2) {

        double num3;
        num3 = num1 / num2;
        System.out.println("Result:" + num3 + " of type " + double.class.getName());
    }

    public void calculateRem(double num1, double num2) {

        double num3;
        num3 = num1 % num2;
        System.out.println("Result:" + num3 + " of type " + double.class.getName());
    }

    public void calculateRem(int num1, int num2) {

        int num3;
        num3 = num1 % num2;
        System.out.println("Result:" + num3 + " of type " + int.class.getName());
    }

    public static void main(String[] args) {

        Result result = new Result();
        Result result1 = new Result();
        Result result2 = new Result();
        Result result3 = new Result();
        Result result4 = new Result();
        Result result5 = new Result();

        result.calculate(100, 24);
        result1.calculate(100.10, 20);
        result2.calculate('Z', 2);
        result3.calculate(10.5, 0.5);
        result4.calculateRem(12.4, 5.5);
        result5.calculateRem(100, 56);
    }
}
