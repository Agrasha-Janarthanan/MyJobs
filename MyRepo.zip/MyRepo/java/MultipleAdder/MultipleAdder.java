class MultipleAdder {

    public static void main(String[] args) {

        int totalValue = args.length;

        if(totalValue < 2) {

            System.out.println("Requires more than one input");
        } else {

            int sum = 0;
            for(int index = 0; index < totalValue; index++) {

                sum += Integer.valueOf(args[index]).intValue();
            }

            System.out.println("The Sum of the given values : " + sum);
        }
    }
}
