// class StringOperation {
public class StringOperation {

    // static void execute() {
    public static void main(String[] args) {

        String hannah = new String("Did Hannah see bees? Hannah did.");
        int stringLength = hannah.length();
        char stringChar = hannah.charAt(12);

        // char myChar = hannah.findChar();
        char myChar = hannah.charAt(15);

        // Console console = getConsole()...;
        // console.print(stringLength);
        System.out.println(stringLength);

        // console.print(stringChar);
        System.out.println(stringChar);

        // console.print(myChar);
        System.out.println(myChar);
    }
}
