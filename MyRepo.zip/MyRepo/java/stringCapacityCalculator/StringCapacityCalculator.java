// class StringCapacityCalculator {
public class StringCapacityCalculator {

    // static void execute() {
    public static void main(String[] args) {

        StringBuilder sb = new StringBuilder("Able was I ere I saw Elba.");
        StringCapacityCalculator calculator = new StringCapacityCalculator();

        // int capacity = calculateCapicity(sb);
        int capacity = sb.capacity();
        int length = sb.length();
        int initialCapacity = calculator.calculateCapacity(capacity,length);

        // Console console = getConsole()...
        // console.print(capacity);
        System.out.println(initialCapacity);
    }
    
    int calculateCapacity(int value, int size) {
        
        int result = value - size;
        return result;
    }
}
