class Animal{
	int legs;
	Animal(){
		this.legs = 2;
	}
	public void run(int legs){
		System.out.println("Animal runs with " + legs + " legs");
	}
}

class Dog{
	public static void main (String [] args){
		Animal sam = new Animal();
		sam.run(4);
	}
}



