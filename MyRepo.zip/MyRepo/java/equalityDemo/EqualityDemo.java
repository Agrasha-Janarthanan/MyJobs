// class EqualityDemo {
public class EqualityDemo {

    static void execute() {
    public static void main(String[] args) {

        // String firstName = "Agrasha";
        String firstName = "Agrasha";

        // String lastName = "Janarthanan";
        String lastName = "Janarthanan";

        // EqualityDemo myDemo = checkEquality(firstName, lastName);
        System.out.println(firstName.equals(lastName));

        // Console console = getConsole()...
        // console.print(firstName == lastName);
        System.out.println(firstName == lastName);
    }
}
