public class EvaluateExpression {

    public static void main(String[] args) {

        boolean result = Integer.valueOf(1).equals(Long.valueOf(1));
        System.out.println(result);
    }
}

// OUTPUT
    // false
    // since,both the types differs