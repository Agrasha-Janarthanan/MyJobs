class Store {

    public static int boolFlags(int stock) {

        int i = 0;

        if (stock <= i) {
            return (i);
        } else {
            return 1;
        }
    }

    public static void main(String[] args) {

        System.out.println(boolFlags(1));
        System.out.println(boolFlags(10));
        System.out.println(boolFlags(50));
        System.out.println(boolFlags(0));
    }
}
