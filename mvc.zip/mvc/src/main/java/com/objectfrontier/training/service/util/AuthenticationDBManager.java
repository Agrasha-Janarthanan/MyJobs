package com.objectfrontier.training.service.util;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.objectfrontier.training.service.DAO.AuthenticationDAO;
import com.objectfrontier.training.service.entity.model.LoginCredentials;

/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */
@Repository
public class AuthenticationDBManager implements AuthenticationDAO {


    public AuthenticationDBManager() {
    }

    @Override
    public LoginCredentials getCredentials(String email) {
        String query = new StringBuilder().append("SELECT pass                   ")
                                          .append("FROM person_credentials        ")
                                          .append("WHERE email = ?                ")
                                          .toString();
        ResultSetProcessor<LoginCredentials, ResultSet> readCredentials = (resultSet) -> {

            LoginCredentials personDTO = LoginCredentials.create();
            while (resultSet.next()) {
                personDTO = personDTO.setPassword(resultSet.getString("pass"));
            }
            return personDTO.setEmail(email).setAdmin(isAdmin(email));
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, email);
            return readCredentials.applyOn(query, parameters, false, 0);
        } catch (Exception e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public boolean isAdmin(String email) {

        String query = new StringBuilder().append("SELECT count(email)              ")
                                          .append("FROM person_admin                ")
                                          .append("WHERE email = ?                  ")
                                          .toString();
        ResultSetProcessor<Boolean, ResultSet> adminCheck = (resultSet) -> {

            while (resultSet.next()) {
                if (resultSet.getInt(1) > 0) {
                    return true;
                }
            }
            return false;
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, email);
            return adminCheck.applyOn(query, parameters, false, 0);
        } catch (Exception e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }
}
