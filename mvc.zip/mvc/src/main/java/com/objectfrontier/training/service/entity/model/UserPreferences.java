package com.objectfrontier.training.service.entity.model;

/**
 * @author Lokesh.
 * @since Nov 20, 2018
 */
public class UserPreferences {

    private String email;
    
    public UserPreferences() {
        super();
        // TODO Auto-generated constructor stub
    }
    public static UserPreferences create() { return new UserPreferences(); }
    public UserPreferences setEmail(String email) { this.email = email; return this; }
}
