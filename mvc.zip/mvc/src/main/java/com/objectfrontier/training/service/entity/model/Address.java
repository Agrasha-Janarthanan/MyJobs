package com.objectfrontier.training.service.entity.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Lokesh.
 * @since Dec 27, 2018
 */

@Entity
@Table(name="scv_address")
public class Address {

    @Id
    @Column(name="id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long id;

    @Column(name="street")
    private String street;
    @Column(name="city")
    private String city;
    @Column(name="postal_code")
    private long postalCode;


    public Address(String street, String city, long postalCode) {
        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
    }

    public Address() {
    }

    public long getId() {
        return id;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public long getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(Long postalCode) {
        this.postalCode = postalCode;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return String.format("Address [id=%s, street=%s, city=%s, postalCode=%s]", id, street, city, postalCode);
    }
}
