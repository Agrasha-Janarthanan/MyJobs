package com.objectfrontier.training.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.objectfrontier.training.service.AuthenticationService;
import com.objectfrontier.training.service.entity.model.LoginCredentials;
import com.objectfrontier.training.service.util.AppException;
import com.objectfrontier.training.service.util.AppStatusCode;
import com.objectfrontier.training.service.util.BeanUtil;
import com.objectfrontier.training.service.util.Error;

/**
 * @author Lokesh.
 * @since Dec 26, 2018
 */
@RequestMapping("/login")
@Controller
public class LoginServlet extends BaseServlet {

    @Autowired
    @Qualifier("authenticationService")
    private AuthenticationService authenticationService;

    { initLog(getClass()); }

    @RequestMapping(
            method = RequestMethod.POST,
            params = { "user", "pass" }
            )
    void login(@RequestParam("user") String user,
                               @RequestParam("pass") String password,
                               HttpServletRequest req,
                               HttpServletResponse resp) {
        HttpSession session = req.getSession(false);
        authenticationService = BeanUtil.getBean(AuthenticationService.class);
        
        log(String.format("Logging in user : %s", user));
        log(password);
        log("AuthenticationService is" + authenticationService);

        if (!authenticationService.authenticate(user, password)) {
            log("Authentication failed. Invalid credentials", "error");
            throw new AppException(Error.INVALID_PASSWORD);
        }

        log(String.format("User %s Logged In", user));
        LoginCredentials personDTO = authenticationService.getCredentials(user);
        session.setAttribute("userDetails", personDTO);
        resp.setStatus(AppStatusCode.SUCCESS_NO_RESPONSE_BODY.getStatusCode());
    }

}
