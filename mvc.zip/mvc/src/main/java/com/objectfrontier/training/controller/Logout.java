package com.objectfrontier.training.controller;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.objectfrontier.training.service.util.AppStatusCode;

@Controller
@RequestMapping("/logout.html")
public class Logout extends BaseServlet {

    { initLog(getClass()); }

    @RequestMapping(method = RequestMethod.GET)
    @ResponseBody void logout(HttpServletRequest req,
                              HttpServletResponse res) {

        if (Objects.isNull(req.getSession(false))) {
            res.setStatus(AppStatusCode.SUCCESS_NO_RESPONSE_BODY.getStatusCode());
            return;
        }
    }
    
}
