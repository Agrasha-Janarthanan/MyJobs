package com.objectfrontier.training.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.entity.model.Address;
import com.objectfrontier.training.service.util.BeanUtil;

/**
 * @author Lokesh.
 * @since Dec 26, 2018
 */
@Controller
@RequestMapping("/address")
public class AddressServlet extends BaseServlet {
    
    @Autowired
    @Qualifier("addressService")
    AddressService addressService;
    
    public void setAddressService(AddressService addressService) {
        this.addressService = addressService;
    }
    
    public AddressServlet() throws IOException {
    }

    { 
        initLog(getClass());
    }

    @RequestMapping(
            method = RequestMethod.GET,
            params = { "action", "id" }
            )
    @ResponseBody Address read(@RequestParam("id") long id,
                               @RequestParam("action") String action) {
        addressService = BeanUtil.getBean(AddressService.class);
        return addressService.read(id);
    }
    
    @RequestMapping(
            method = RequestMethod.GET,
            params = { "action", "searchFields", "searchText" }
            )
    @ResponseBody List<Address> search(@RequestParam("searchFields") String searchFields,
                                       @RequestParam("searchText") String searchText,
                                       @RequestParam("action") String action) {
        addressService = BeanUtil.getBean(AddressService.class);
        String[] fields = searchFields.split(",");
        return addressService.search(fields, "%" + searchText + "%");
    }
    
    @RequestMapping(
            method = RequestMethod.GET,
            params = { "action" }
            )
    @ResponseBody List<Address> readAll(@RequestParam("action") String action) {
        addressService = BeanUtil.getBean(AddressService.class);
        return addressService.readAll();
    }
    
    @RequestMapping(
            method = RequestMethod.POST,
            params = { "action" }
            )
    @ResponseBody Address doPost(@RequestParam("action") String action,
                                       @RequestBody Address address) {
        addressService = BeanUtil.getBean(AddressService.class);
        if (action.equals("update")) { return addressService.update(address); }
        return addressService.delete(address);
    }
    
    @RequestMapping(
            method = RequestMethod.PUT,
            params = { "action" }
            )
    @ResponseBody Address doPut(@RequestBody Address address) {
        addressService = BeanUtil.getBean(AddressService.class);
        return addressService.create(address);
    }
}
