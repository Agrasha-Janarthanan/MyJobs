package com.objectfrontier.training.filters;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.util.ConnectionManager;
import com.objectfrontier.training.service.util.DataSource;
import com.objectfrontier.training.service.util.Logger;

/**
 * @author Lokesh.
 * @since Nov 22, 2018
 */
public class TransactionFilter extends BaseFilter {

    private HttpSession session;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        super.init(filterConfig);
        initLog(getClass());
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        preFilter(req, res);
        try {    
            chain.doFilter(request, response);
            commit(req, true);
        } catch (Exception e) {
            log(e.toString());
            log(e.getStackTrace());
            commit(req, false);
        }
    }

    @Override
    protected void preFilter(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (request.getRequestURI().endsWith("logout.html")) { return; }
        this.session = request.getSession(false);

        log("Assigning a Connection%n");
        log("Connection is : " + DataSource.getConnection());
        ConnectionManager.init(DataSource.getConnection());;
        ConnectionManager.autoCommit(false);
        if (!request.getRequestURI().contains("address")) {
            session.setAttribute("addressService", new AddressService());
        }

        log(String.format("Intilising transaction %s", request.getParameter("action")));
        
    }


    protected void commit(HttpServletRequest request, boolean status)
            throws ServletException, IOException {
        if (request.getRequestURI().endsWith("logout.html")) { return; }
        
        if (status) {
            ConnectionManager.commit();
            log("Transaction successful%n");
            ConnectionManager.close();
            return;
        } 

        ConnectionManager.rollBack();
        Logger.log("Transation Failed");
        ConnectionManager.close();
    }

    @Override
    protected void postFilter(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        
    }

    
}
