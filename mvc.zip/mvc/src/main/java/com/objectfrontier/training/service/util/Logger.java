package com.objectfrontier.training.service.util;

public class Logger {

    public static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }

    public static void log(Throwable t) {
        t.printStackTrace(System.err);
    }
}
