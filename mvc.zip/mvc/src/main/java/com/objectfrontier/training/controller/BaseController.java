package com.objectfrontier.training.controller;

import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

public class BaseController {

    private static final long serialVersionUID = 1L;
    private Logger log = Logger.getLogger(BaseController.class);

    {
        log.info("Initialize servlet: " + getClass().getSimpleName());
    }
    
    protected void initLog(Class clazz) {
        this.log = Logger.getLogger(clazz);
    }
    
    public void log(String data) {
        log.info(data);
    }

    public void log(String data, String logType) {

        if (logType.equals("error")) {
            log.error(data);
            return;
        }
        log.info(data);
    }

    public void log(StackTraceElement[] stackTraceElements) {
        Arrays.stream(stackTraceElements)
              .forEach(stackTraceElement -> log.error(stackTraceElement));
    }

}
