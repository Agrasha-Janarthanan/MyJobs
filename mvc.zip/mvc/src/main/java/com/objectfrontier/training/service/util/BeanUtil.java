package com.objectfrontier.training.service.util;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.objectfrontier.training.config.AppConfig;

public class BeanUtil {

    private static AbstractApplicationContext context = 
            new AnnotationConfigApplicationContext(AppConfig.class);

    public BeanUtil() {}
    
    public static <T> T getBean(Class<T> clazz) {
        return context.getBean(clazz);
    }
}
    