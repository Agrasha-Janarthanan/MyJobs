package com.objectfrontier.training.filters;

import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.service.entity.model.LoginCredentials;
import com.objectfrontier.training.service.entity.model.Result;
import com.objectfrontier.training.service.util.AppError;
import com.objectfrontier.training.service.util.AppException;
import com.objectfrontier.training.service.util.AppStatusCode;
import com.objectfrontier.training.service.util.Error;
import com.objectfrontier.training.service.util.JsonUtil;
import com.objectfrontier.training.service.util.Logger;

public class AuthorizationFilter extends BaseFilter {

    private String[] normalUserRoles = new String[] { "read", "readAll", "search", "indexedReadAll" };
    private String check;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

        super.init(filterConfig);

        initLog(getClass());

        StringBuilder sBuilder = new StringBuilder();
        Arrays.stream(normalUserRoles).forEach(role -> sBuilder.append(role));
        this.check = sBuilder.toString();
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);
        boolean isAdmin = false;
        LoginCredentials userDetails = null;

        if (Objects.nonNull(session)) { userDetails = (LoginCredentials) session.getAttribute("userDetails"); }
        if (Objects.nonNull(userDetails)) { isAdmin = userDetails.isAdmin(); }

        if (Objects.isNull(userDetails) || req.getRequestURI().endsWith("logout.html")) {
            chain.doFilter(request, response);
        } else if (isAdmin || (check.indexOf(request.getParameter("action")) > -1 )) {
            chain.doFilter(request, response);
        } else {
            res.setStatus(AppStatusCode.FORBIDDEN.getStatusCode());
            log("unauthorised action detected");
            log("Terminating the request");

            throw new AppException(Error.INVALID_OPERATION_REQUEST);
        }
    }

    @Override
    protected void preFilter(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void postFilter(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

}
