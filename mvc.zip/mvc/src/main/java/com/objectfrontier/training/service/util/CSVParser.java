package com.objectfrontier.training.service.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Deque;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import javax.xml.crypto.Data;

import com.objectfrontier.training.service.entity.model.Address;
import com.objectfrontier.training.service.entity.model.Person;

/**
 * @author Lokesh.
 * @since Oct 15, 2018
 */

public class CSVParser {

    private String personFile;
    private List<Person> persons;
    private Map<Long, Address> addresses;
    private String addressFile;

    public CSVParser() {
    }

    public CSVParser(String addressFile) {
        this.addressFile = addressFile;
    }

    public CSVParser(String personFile, String addressFile) {
        this.personFile = personFile;
        this.addressFile = addressFile;
        this.addresses = csvToAddressMap();
        this.persons = csvToPersonList();
    }

    private Map<Long, Address> csvToAddressMap() {
        try (InputStream fileStream = getClass().getResourceAsStream(addressFile)) {
            BufferedReader csvStream = new BufferedReader(new InputStreamReader(fileStream));
            HashMap<Long, Address> addressMap = new HashMap<>();

            csvStream.lines()
                     .map(this::addressMapper)
                     .forEach(address -> addressMap.put(address.getId(), address));
            return addressMap;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private List<Person> csvToPersonList() {

        try (InputStream fileStream = getClass().getResourceAsStream(this.personFile)) {
            BufferedReader csvStream = new BufferedReader(new InputStreamReader(fileStream));
            return csvStream.lines()
                            .map(this::personMapper)
                            .collect(Collectors.toCollection(ArrayList::new));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private List<Address> csvToAddressList() {

        try (InputStream fileStream = getClass().getResourceAsStream(this.addressFile)) {
            BufferedReader csvStream = new BufferedReader(new InputStreamReader(fileStream));
            return csvStream.lines()
                            .map(this::addressMapper)
                            .collect(Collectors.toCollection(ArrayList::new));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private Address addressMapper(String csvRecord) {
        String[] tokens = csvRecord.split(",");
        Address address = new Address();

        address.setId(Long.parseLong(tokens[0] == "" ? "0" : tokens[0]));
        address.setStreet(tokens[1] == "" ? null : tokens[1]);
        address.setCity(tokens[2] == "" ? null : tokens[2]);
        address.setPostalCode((tokens[3] == "" ? 0 : Long.parseLong(tokens[3])));

        return address;
    }

    private Person personMapper(String csvRecord) {
        String[] tokens = csvRecord.split(",");
        Person person = new Person();
        int count = 0;
        String token;

            if (tokens.length > 5) {
                person.setId(Long.parseLong((token = tokens[count++]) == "" ? "0" : token));
                person.setFirstName((token = tokens[count++]) == "" ? null : token);
            } else {
                person.setFirstName((token = tokens[count++]) == "" ? null : token);
            }
            person.setLastName((token = tokens[count++]) == "" ? null : token);
            person.setEmail((token = tokens[count++]) == "" ? null : token);
            token = tokens[count++];
            if (token == "") {
                person.setBirthDate(null);
            } else {
                person.setBirthDate(LocalDate.parse(token,
                        DateTimeFormatter.ofPattern("dd-MM-yyyy")));
            }
            Long id = Long.parseLong((token = tokens[count++]) == "" ? "0" : token);
            if (addresses.containsKey(id)) {
                person.setAddress(addresses.get(id));
        }
        return person;
    }

    public List<Person> getPersons() {
        return persons;
    }

    public List<Address> getAddresses() {
        return csvToAddressList();
    }

    public List<Person> getPersons(int limit, int offset) {
        return persons.subList(offset, offset + limit);
    }
    
    public List<Address> getAddresses(int limit, int offset) {
        return csvToAddressList().subList(offset, offset + limit);
    }
}
