package com.objectfrontier.training.service.util;

public interface Service {

}
