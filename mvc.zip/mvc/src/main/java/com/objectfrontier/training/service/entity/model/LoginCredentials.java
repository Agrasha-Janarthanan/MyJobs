package com.objectfrontier.training.service.entity.model;

/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */
public class LoginCredentials {

    private String email;
    private String password;
    private boolean isAdmin;
    private String[] roles;

    private LoginCredentials() {};

    public static LoginCredentials create() { return new LoginCredentials(); }

    public LoginCredentials setEmail(String email) { this.email = email; return this; }
    public LoginCredentials setPassword(String pasString) { this.password = pasString; return this; }
    public LoginCredentials setAdmin(boolean status) { this.isAdmin = status; return this; }
    public LoginCredentials setRoles(String[] roles) { this.roles =  roles; return this; }

    public String getEmail() { return this.email; }
    public String getPassword() { return this.password; }
    public boolean isAdmin() { return this.isAdmin; }
    public String[] getRoles() { return this.roles; }
}
