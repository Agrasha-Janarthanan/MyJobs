package com.objectfrontier.training.service.util;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public interface ResultSetProcessor<V, T> {

    public default V getResultSet(String query, List<?> parameters)
            throws SQLException {
        int statementIndex = 1;

        try (PreparedStatement preparedStatement = ConnectionManager.createStatement(query)) {
            if (parameters != null && parameters.size() > 0) {
                for (Object item : parameters) {
                    preparedStatement.setObject(statementIndex, item);
                    statementIndex++;
                }
            }
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return operation((T) resultSet);
            }
        }

    }

    public default V getResult(String query, List<?> parameters, int autoGenerateKey) throws SQLException {
        int statementIndex = 1;
        if (autoGenerateKey != Statement.RETURN_GENERATED_KEYS) {
            try (PreparedStatement preparedStatement = ConnectionManager.createStatement(query)) {
                if (parameters != null && parameters.size() > 0) {
                    for (Object item : parameters) {
                        preparedStatement.setObject(statementIndex, item);
                        statementIndex++;
                    }
                }
                return operation((T) (Object) (preparedStatement.executeUpdate()));
            }
        }
        try (PreparedStatement preparedStatement = ConnectionManager.createStatement(query, autoGenerateKey)) {
            if (parameters != null && parameters.size() > 0) {
                for (Object item : parameters) {
                    preparedStatement.setObject(statementIndex, item);
                    statementIndex++;
                }
            }
            preparedStatement.executeUpdate();
            try (ResultSet resultSet = preparedStatement.getGeneratedKeys()) {
//                resultSet.next();
                return operation((T) resultSet);
            }
        }
    }

    public default V applyOn(String query, List<?> parameters,
            boolean isUpdateQuery, int returnGeneratedkey) throws SQLException {

        if (!isUpdateQuery) {
            return getResultSet(query, parameters);
        }
        return getResult(query, parameters, returnGeneratedkey);
    }

    V operation(T result) throws SQLException;
}
