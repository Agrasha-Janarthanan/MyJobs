package com.ofs.training.controller;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import com.ofs.training.service.AddressService;

import com.ofs.training.model.Address;
import com.ofs.training.util.ConnectionManager;
import com.ofs.training.util.JsonUtil;

public class AddressServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    AddressService addressService;
    @Autowired
    public void setAddressService(AddressService addrService) {
        addressService = addrService;
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Connection connection = ConnectionManager.openConnection();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String addressJson = String.join("", jsonLines);

        Address address = JsonUtil.toObject(addressJson, Address.class);
        PrintWriter out = response.getWriter();

        address = addressService.create(address, connection);
        out.write(JsonUtil.toJson(address));
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json");
        Connection connection = ConnectionManager.openConnection();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String addressJson = String.join("", jsonLines);

        Address address = JsonUtil.toObject(addressJson, Address.class);
        PrintWriter out = response.getWriter();

        address = addressService.update(address, connection);
        out.write(JsonUtil.toJson(address));
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Address> result = new ArrayList<>();
        response.setContentType("application/json");
        Connection connection = ConnectionManager.openConnection();
        String addressId = request.getParameter("id");
        String searchInput = request.getParameter("searchInput");
        String searchField = request.getParameter("searchField");

        PrintWriter out = response.getWriter();

        if ((searchField != null) || (searchInput != null)) {
            String[] fields = searchField.split(",");
            result = addressService.search(fields, searchInput, connection);
            out.write(JsonUtil.toJson(result));
        } else {
            if (Objects.isNull(addressId)) {
                result = addressService.readAll(connection);
                out.write(JsonUtil.toJson(result));
            } else {
                long id = Long.parseLong(addressId);
                Address address = addressService.read(id, connection);
                out.write(JsonUtil.toJson(address));
            }
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json");
        Connection connection = ConnectionManager.openConnection();
        String addressId = request.getParameter("id");
        PrintWriter out = response.getWriter();

        long id = Long.parseLong(addressId);
        Address deletedAddress = addressService.delete(id, connection);
        out.write(JsonUtil.toJson(deletedAddress));
    }
}
