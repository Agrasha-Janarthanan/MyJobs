package com.ofs.training.service;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;

import com.ofs.training.util.QueryManager;
import com.ofs.training.util.AppException;
import com.ofs.training.util.Error;
import com.ofs.training.model.Address;
import com.ofs.training.model.Person;

public class PersonService {

    AddressService addressService;
    @Autowired
    public void setAddrService(AddressService addrService) {
        addressService = addrService;
    }

    Person person;
    @Autowired
    public void setPerson(Person perzon) {
        person = perzon;
    }

    Address address;
    @Autowired
    public void setAddress(Address addr) {
        address = addr;
    }

    public AddressService getAddressService() {
        return addressService;
    }

    public void setAddressService(AddressService addressService) {
        this.addressService = addressService;
    }

    private void validate(Person person, Connection conn) {

        List<Error> errors = new ArrayList<Error>();

        if (isEmpty(person.getFirstName())) {
            errors.add(Error.INVALID_FIRSTNAME);
        }

        if (isEmpty(person.getLastName())) {
            errors.add(Error.INVALID_LASTNAME);
        }

        if (isEmpty(person.getEmail())) {
            errors.add(Error.INVALID_EMAIL);
        }

        if (person.getBirthDate() == null) {
            errors.add(Error.INVALID_BIRTHDATE);
        }

        try {
            validateName(person, conn);
        } catch (AppException e) {
            errors.addAll(e.getErrorCodes());
        }

        try {
            validateEmail(person, conn);
        } catch (AppException e) {
            errors.addAll(e.getErrorCodes());
        }

        if (errors.size() > 0) {
            throw new AppException(errors);
        }
    }

    private boolean isEmpty(String value) {
        return Objects.isNull(value) || "".equals(value);
    }

    private void validateName(Person person, Connection conn) {

        try {
            String query = QueryManager.COUNT_PERSON_BY_NAME;
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            ResultSet executeQuery = statement.executeQuery();
            executeQuery.next();
            int count = executeQuery.getInt(1);
            if (count > 0) {
                List<Error> errors = new ArrayList<>();
                errors.add(Error.DUPLICATE_NAME);
                throw new AppException(errors);
            }
        } catch (SQLException exception) {
             throw new AppException(Error.DATABASE_ERROR, exception.getCause());
        }
    }

    private void validateEmail(Person person, Connection conn) {

        try {
            String query = QueryManager.COUNT_PERSON_BY_EMAIL;
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, person.getEmail());
            ResultSet executeQuery = statement.executeQuery();
            executeQuery.next();
            int count = executeQuery.getInt(1);
            if (count > 0) {
                List<Error> errors = new ArrayList<>();
                errors.add(Error.DUPLICATE_EMAIL);
                throw new AppException(errors);
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }

    private void validateId(long id, Connection conn) {

        if (id == 0) {
            List<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_ID);
            throw new AppException(errors);
        }
    }

    private void constructPerson(Person person, ResultSet result) {

        try {
            person.setId         (result.getLong("id"));
            person.setFirstName  (result.getString("first_name"));
            person.setLastName   (result.getString("last_name"));
            person.setEmail      (result.getString("email"));
            person.setBirthDate  (result.getDate("birth_date"));
            person.setPassword   (result.getString("password"));
            person.setAdmin      (result.getBoolean("isAdmin"));
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }


    private void setValue(Person person, PreparedStatement statement) {

        try {
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setString(3, person.getEmail());
            statement.setDate(4, person.getBirthDate());
            statement.setString(5, person.getPassword());
            statement.setBoolean(6, person.isAdmin());
        } catch (Exception e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }

    public Person create(Person person, Connection conn) {

        long generatedKey = 0;

        String insertQuery = QueryManager.CREATE_PERSON;
        try {
            validate(person, conn);

            PreparedStatement statement = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
            Address address = addressService.create(person.getAddress(), conn);
            setValue(person, statement);
            person.setAddress  (address);
            statement.setLong  (7, person.getAddress().getId());
            statement.executeUpdate();

            ResultSet generatedKeys = statement.getGeneratedKeys();
            if ((generatedKeys != null) && (generatedKeys.next())) {
                generatedKey = generatedKeys.getLong(1);
            }
            person.setId(generatedKey);
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return person; 
    }

    public Person update(Person person, Connection conn) {

        String query = QueryManager.UPDATE_PERSON;

        try {
            validateId(person.getId(), conn);

            PreparedStatement statement = conn.prepareStatement(query);
            Address address = addressService.update(person.getAddress(), conn);
            setValue(person, statement);
            person.setAddress  (address);
            statement.setLong  (7, person.getAddress().getId());
            statement.setLong  (8, person.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return person;
    }

    public Person read(long id, boolean includeAddress, Connection connection) {

        String readQuery = QueryManager.READ_PERSON;
        try {

            validateId(id, connection);
            PreparedStatement statement = connection.prepareStatement(readQuery);
            statement.setLong(1, id);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) { 
                constructPerson(person, rs);
                if (includeAddress) {
                    address.setId(rs.getLong("address_id"));
                    Address readAddress = addressService.read(address.getId(), connection);
                    person.setAddress(readAddress);
                }
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return person;
    }

    public List<Person> readAll(boolean includeAddress, Connection conn) {

        String readAllQuery = QueryManager.READALL_PERSON;
        List<Person> resultRecord = new ArrayList<>();

        try {

                ArrayList<Address> addresses = addressService.readAll(conn);
                Map<Long, Address> addressMapper = new HashMap<>();
                for (Address address : addresses) {
                    addressMapper.put(address.getId(), address);
                }
                PreparedStatement statement = conn.prepareStatement(readAllQuery);
                ResultSet result = statement.executeQuery();

                while (result.next()) {
                    constructPerson(person, result);

                    if (includeAddress) {
                        address.setId(result.getLong("address_id"));
                        person.setAddress(address);
                        person.setAddress(addressMapper.get(person.getAddress().getId()));
                    }
                    resultRecord.add(person);
                }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return resultRecord;
    }

    public Person delete(long id, Connection conn) {

        String deleteQuery = QueryManager.DELETE_PERSON;

        try {
            validateId(id,conn);
            boolean includeAddress = true;
            Person person = read(id, includeAddress, conn);
            PreparedStatement statement = conn.prepareStatement(deleteQuery.toString());
            statement.setLong(1, id);
            statement.executeUpdate();
            addressService.delete(person.getAddress().getId(), conn);
            return person;
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }
}
