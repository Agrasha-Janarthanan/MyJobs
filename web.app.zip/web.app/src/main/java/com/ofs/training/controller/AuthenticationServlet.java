package com.ofs.training.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Objects;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ofs.training.model.Person;
import com.ofs.training.service.AuthenticationService;
import com.ofs.training.util.AppException;
import com.ofs.training.util.ConnectionManager;
import com.ofs.training.util.Error;
import com.ofs.training.util.JsonUtil;

public class AuthenticationServlet extends HttpServlet{


    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        AuthenticationService loginService = new AuthenticationService();
        Connection con = ConnectionManager.openConnection();
        PrintWriter out = response.getWriter();

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Person person = loginService.login(email, password, con);
        HttpSession session = request.getSession();
        String sessionId = request.getRequestedSessionId();
        Cookie setCookie = new Cookie("Set-Cookie", sessionId);
        response.addCookie(setCookie);
        session.setAttribute("person", person);
        out.write(JsonUtil.toJson(sessionId));
        ConnectionManager.releaseConnection(true);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        if (! Objects.isNull(session)) {
            session.invalidate();
        } else {
            throw new AppException(Error.INVALID_REQUEST);
        }
    }
}
