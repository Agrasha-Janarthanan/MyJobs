package com.ofs.training.util;

import java.sql.Connection;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class ConnectionManager {

    static Connection conn ;
    private static HikariDataSource ds;

    static {
        HikariConfig config = new HikariConfig("resources/ConnectionProperties.properties");
        config.setAutoCommit(false);
        ds = new HikariDataSource(config);
    }


    // inintialise ThreadLocal
    private static ThreadLocal<Connection> threadLocal = new ThreadLocal<Connection>();
    
    // set connection to thread
    public void initConnection() throws Exception {
        Connection connection = ds.getConnection();
        threadLocal.set(connection);
    }

    
    // get connection from thread
    public static Connection openConnection() {

        return threadLocal.get();
    }

    // remove thread
    public void remove() {

        threadLocal.remove();
    }

    public static void releaseConnection(boolean doCommit) {

        try {
            if (doCommit) {
                conn.commit();
                conn.close();
            } else {
                conn.rollback();
                conn.close();
            }
        } catch (Exception exception) {
            throw new AppException(Error.CONNECTION_ERROR);
        } 
    }
}
