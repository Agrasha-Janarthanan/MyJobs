package com.ofs.training.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ofs.training.controller.AddressServlet;
import com.ofs.training.controller.PersonServlet;
import com.ofs.training.model.Address;
import com.ofs.training.model.Person;
import com.ofs.training.service.AddressService;
import com.ofs.training.service.PersonService;

public class BeanFactory {

    static ApplicationContext application = new ClassPathXmlApplicationContext("applicationContext.xml");

    public static Address getAddress() {
        return (Address) application.getBean("address");
    }

    public static Person getPerson() {
        return (Person) application.getBean("person");
    }

    public static AddressService getAddressService() {
        return (AddressService) application.getBean("addressService");
    }

    public static PersonService getPersonService() {
        return (PersonService) application.getBean("personService");
    }

    public static AddressServlet getAddressServlet() {
        return (AddressServlet) application.getBean("addressServlet");
    }

    public static PersonServlet getPersonServlet() {
        return (PersonServlet) application.getBean("personServlet");
    }
}
