package com.ofs.training.controller;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import com.ofs.training.service.PersonService;
import com.ofs.training.util.ConnectionManager;
import com.ofs.training.model.Person;
import com.ofs.training.util.JsonUtil;

public class PersonServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    PersonService personService;
    @Autowired
    public void setPersonService(PersonService perzonService) {
        personService = perzonService;
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Connection connection = ConnectionManager.openConnection();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String personJson = String.join("", jsonLines);

        Person person = JsonUtil.toObject(personJson, Person.class);
        PrintWriter out = response.getWriter();
        person = personService.create(person, connection);
        out.write(JsonUtil.toJson(person));
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        Connection connection = ConnectionManager.openConnection();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String personJson = String.join("", jsonLines);

        Person person= JsonUtil.toObject(personJson, Person.class);
        PrintWriter out = response.getWriter();
        person = personService.update(person, connection);
        out.write(JsonUtil.toJson(person));
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Person> result = new ArrayList<>();
        response.setContentType("application/json");
        Connection connection = ConnectionManager.openConnection();
        Person person = new Person();
        String personId = request.getParameter("id");
        boolean includeAddress = Boolean.parseBoolean(request.getParameter("includeAddress"));
        PrintWriter out = response.getWriter();

        if (Objects.isNull(personId)) {
            result = personService.readAll(includeAddress, connection);
            out.write(JsonUtil.toJson(result)); 
        } else {
            long id = Long.parseLong(personId);
            person = personService.read(id, includeAddress, connection);
            out.write(JsonUtil.toJson(person));
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json");
        Connection connection = ConnectionManager.openConnection();
        String personId = request.getParameter("id");
        PrintWriter out = response.getWriter();
        long id = Long.parseLong(personId);
        Person deletedPerson = personService.delete(id, connection);
        out.write(JsonUtil.toJson(deletedPerson));
    }
}
