package com.ofs.training.util;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.ofs.training.controller.AddressServlet;
import com.ofs.training.controller.PersonServlet;
import com.ofs.training.model.Address;
import com.ofs.training.model.Person;
import com.ofs.training.service.AddressService;
import com.ofs.training.service.PersonService;

@Configuration
@ComponentScan(basePackages = { "com.ofs.training.service", "com.ofs.training.controller" })
public class DIConfig {

   @Bean
   public Person getPerson() {
       return new Person();
   }

   @Bean
   public Address getAddress() {
       return new Address();
   }

   @Bean
   public AddressService getAddressService() {
       return new AddressService();
   }

   @Bean
   public PersonService getPersonService() {
       return new PersonService();
   }

   @Bean
   public AddressServlet getAddressServlet() {
       return new AddressServlet();
   }

   @Bean
   public PersonServlet getPersonServlet() {
       return new PersonServlet();
   }
}