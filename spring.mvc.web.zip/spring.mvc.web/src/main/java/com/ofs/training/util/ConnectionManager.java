package com.ofs.training.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class ConnectionManager {

    private static HikariDataSource ds;

    // inintialise ThreadLocal
    private static ThreadLocal<Connection> threadLocal = new ThreadLocal<Connection>();

    static {
        try {
            InputStream inputStream = ConnectionManager.class.getClassLoader()
                                                       .getResourceAsStream("ConnectionProperties.properties");
            Properties properties = new Properties();
            properties.load(inputStream);
            HikariConfig config = new HikariConfig(properties);
            config.setAutoCommit(false);
            ds = new HikariDataSource(config);
        } catch (IOException e) {
            e.getMessage();
        }
    }


    // set connection to thread
    public static void initConnection() throws Exception {
        Connection connection = ds.getConnection();
        threadLocal.set(connection);
    }

    // get connection from thread
    public static Connection openConnection() {
        Connection connection = threadLocal.get();
        return connection;
    }

    // remove thread
    public void remove() {
        threadLocal.remove();
    }

    public static void releaseConnection(boolean doCommit) {

        Connection conn = openConnection();
        try {
            if (doCommit) {
                conn.commit();
                conn.close();
            } else {
                conn.rollback();
                conn.close();
            }
        } catch (Exception exception) {
            throw new AppException(Error.CONNECTION_ERROR);
        }
    }
}
