package com.ofs.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ofs.training.service.PersonService;
import com.ofs.training.model.Person;
import com.ofs.training.util.BeanUtil;

@Controller
@RequestMapping("/person")
public class PersonController {
    
    @Autowired
    @Qualifier("personService")
    PersonService personService;

    @RequestMapping(
            method = RequestMethod.GET,
            params = { "action=read"},
            produces = "application/json"
            )
    @ResponseBody Person read(@RequestParam("id") long id,
                              @RequestParam("addStatus") boolean status) {
        personService = BeanUtil.getBean(PersonService.class);
        return personService.read(id, status);
    }

    @RequestMapping(
            method = RequestMethod.GET,
            params = { "action=readAll" },
            produces = "application/json"
            )
    @ResponseBody List<Person> readAll(@RequestParam("includeAddress") boolean includeAddress) {
        personService = BeanUtil.getBean(PersonService.class);
        List<Person> persons = personService.readAll(includeAddress);
        return persons;
    }

    @RequestMapping(
            method = RequestMethod.POST
            )
    @ResponseBody Person doPost(@RequestParam("id") long id,
                                @RequestBody Person person) {
        personService = BeanUtil.getBean(PersonService.class);
        return personService.update(person);
    }

    @RequestMapping(
            method = RequestMethod.DELETE
            )
    @ResponseBody void doDelete(@RequestParam("id") long id,
                                @RequestBody Person person) {
        personService = BeanUtil.getBean(PersonService.class);
        personService.delete(id);
    }

    @RequestMapping(
            method = RequestMethod.PUT
            )
    @ResponseBody Person doPut(@RequestBody Person person) {
        personService = BeanUtil.getBean(PersonService.class);
        return personService.create(person);
    }
    
}
